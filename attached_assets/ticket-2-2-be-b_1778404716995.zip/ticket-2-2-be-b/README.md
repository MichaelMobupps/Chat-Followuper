# Ticket 2.2-BE-B — Apollo cascade

Backend bundle. Stage B of the prospector discovery pipeline. Takes a `ResolvedCompany` (output of 2.2-BE-A's /resolve-company) and runs the Apollo API cascade to find the org and its contacts.

## What this ships

Three new endpoints, all `requireAuth`, all rate-limited, all writing to `action_logs`:

```
POST /api/prospector/find-org
  { resolved: ResolvedCompany }
  → 200: { org, strategy, upgradedToParent, attempts }
  → 429: { error: "rate_limit_exceeded", message, retryAfterSeconds }
  → 503: { error: "apollo_not_configured" | "apollo_rate_limited", message, retryAfterSeconds? }
  → 504: { error: "find_org_timeout", message }
  → 502: { error: "find_org_failure", message }

POST /api/prospector/collect-contacts
  { org: ApolloOrg, resolved?: ResolvedCompany, targetContacts?: number }
  → 200: { contacts, phasesRun, rejected }
  → 429/503/504/502 same envelope as above

POST /api/prospector/discover-simple
  { resolved: ResolvedCompany, targetContacts?: number }
  → 200: { org, strategy, upgradedToParent, attempts, contacts, phasesRun, rejected }
  → 429/503/504/502 same envelope as above
```

`/find-org` and `/collect-contacts` exist for **per-stage debugging** when the orchestrated `/discover-simple` returns no contacts and you want to inspect exactly which stage failed. `/discover-simple` is the production happy path.

## Request body limits (security caps from audit)

| field | max | rationale |
|---|---|---|
| `companyName` | 500 chars | sanity |
| `parentCompany` | 500 chars | sanity |
| `corporateDomain` | 500 chars | sanity |
| `alternativeDomains[]` | 8 entries | cap Strategy 2 cost amplification (audit B2.1) |
| `searchQueries[]` | 5 entries | cap Strategy 4 cost amplification (audit B-NEW-1) |
| `targetContacts` | 1-50 | bounded contact enrichment cost |

Real `/resolve-company` outputs from Sonnet typically produce 0-3 alt domains and 3-5 search queries, well under these caps.

## Cascade logic — direct port from Python

`orgFinder.findOrg` runs 5 strategies in order, returning at first hit:
1. `domain_enrich` — `/organizations/enrich` on `corporate_domain` (most reliable)
2. `alt_domain_enrich` — same on each `alternativeDomains` entry, with name-mismatch guard (Emma fintech vs Emma Sleep)
3. `name_validated` — `/mixed_companies/search` by `companyName`, picked org must have a domain matching `corporate_domain` or alts
4. `query_validated` — same but iterating `searchQueries`
5. `parent_direct` — search by `parentCompany` name, no domain validation

After any hit (1-4), `_maybe_upgrade_to_parent` checks whether the parent company has more employees in Apollo and swaps to the parent if so. Large groups (SMBC Group, Grupo Dia, VK) have most contacts indexed under the parent.

`contactCollector.collectContacts` runs three phases:
- **Phase 1** — title-tiered: PRIMARY → SECONDARY → EXEC, up to 3 pages each
- **Phase 2** — broad search (no title filter), 2 pages, for regional companies with non-Western title patterns
- **Phase 2b** — micro-org permissive fallback: when total contacts is 0 AND org < 150 employees, accept any non-recruiting non-junior title

Each contact is enriched (Apollo people/match by ID, then by name+domain). Email validation rejects:
- Free-mail domains (gmail, yahoo, outlook, mail.ru, qq.com, etc.) — explicit list (audit C3.1)
- Emails not matching corporate domain or alt domains

Phase 3 (subsidiary expansion for holding companies) is **deferred to 2.2-BE-C** — depends on opusRescue cross-org search.

## Files

```
ticket-2-2-be-b/
├── apply.sh                                  # idempotent installer
├── README.md                                 # this file
├── new-files/
│   ├── artifacts/api-server/src/services/
│   │   ├── apolloProspector.ts               # HTTP client (rate limit, retries, key redaction)
│   │   ├── orgFinder.ts                      # 5-strategy cascade
│   │   └── contactCollector.ts               # tiered people search
│   └── tests/
│       ├── integration-2-2-be-b-stage-b.mjs  # 7 test groups
│       └── README.md
├── patches/
│   ├── patch-action-types.mjs                # adds 3 ACTION_TYPES keys
│   └── patch-prospector-route.mjs            # adds 3 route handlers
└── docs/
    └── manual-test-2-2-be-b.md               # 10-case real-Apollo walk
```

## Dependencies

- 2.1-BE (urlResolver) — already shipped green
- 2.2-BE-A (companyResolver, redactSecrets, sanitizeForStorage) — already shipped green
- `APOLLO_API_KEY` Replit Secret on workspace AND deploy
- `ANTHROPIC_API_KEY` (already set for 2.2-BE-A)

apply.sh fails fast if 2.1-BE or 2.2-BE-A artifacts are missing.

## Audit history (Godlike v2)

Full Godlike v2 audit. 27 checks per round (9 passes × 3 framings A=Technical, B=Security, C=End-User). Bad-mood critic re-engaged fresh each framing. Convergence: **3 consecutive clean rounds (Cycle 6 R1, R2, R3)**.

### Cycle 1 — 9 findings, all fixed

| ID | Severity | Framing | Finding | Fix |
|---|---|---|---|---|
| A1.1 | Medium | A:correctness | 429 on final attempt sleeps 60s then falls through to `return null` (silent waste) | Throw ApolloRateLimitError immediately on final attempt |
| A1.2 | Low | A:correctness | `await resp.text()` not in try/catch (malformed body throws) | Wrap in try/catch with fallback excerpt |
| A4.1 | Low | A:contract | `attempts[N].strategy` typed as `string`, should be union | Tighten to union literal |
| A6.1 | Low | A:security | `getApiKey()` only trims, doesn't reject keys with control chars | Reject keys matching `[\x00-\x1F\x7F-\x9F\s]` |
| B1.1 | Medium | B:security | `redactSecrets` only catches Anthropic patterns; Apollo key shape leaks through | Add `redactApolloKey()` helper, wire into all 3 catch handlers |
| B2.1 | Medium | B:security | `alternativeDomains` zod max=20 enables Strategy 2 cost amplification | Lower max to 8 |
| B3.1 | Medium | B:security | `fetch()` default `redirect: "follow"` leaks X-Api-Key on DNS hijack | Set `redirect: "error"` on Apollo fetches |
| C3.1 | Low | C:correctness | No explicit free-mail domain rejection | Port FREE_EMAIL_DOMAINS from Python prospector |
| C8.1 | Low | C:contract | 503 `apollo_rate_limited` body lacks retry seconds | Include `retryAfterSeconds` field in response body |

### Cycle 2 — 4 findings, all fixed

| ID | Severity | Framing | Finding | Fix |
|---|---|---|---|---|
| B-NEW-1 | Low | B:security | `searchQueries` max=10 also enables Strategy 4 cost amplification | Lower max to 5 |
| C-NEW-1 | Low | C:contract | `altDomains` max change is a public contract change | Documented in this README |
| A-NEW-1 | Low | A:security | BOM (U+FEFF) and zero-width chars (U+200B-200D) in env var bypass control-char filter | Extend `_CONTROL_OR_WS_OR_BOM` regex |
| A-NEW-2 | Low | A:style | `redactApolloKey` regexes compiled per call | Hoist to module-scope constants `_CONTROL_OR_WS_OR_BOM`, `_APOLLO_KEY_HEURISTIC`, `_UUID_SHAPE` |

### Cycle 3 — 1 finding, fixed

| ID | Severity | Framing | Finding | Fix |
|---|---|---|---|---|
| A-CYCLE3-1 | Low | A:doc | `apolloProspector.ts` jsdoc labels audit fixes "F1-F6" colliding with 2.2-BE-A's audit IDs | Replace with descriptive labels (Auth/Body sanitize/Timeout/Rate limit/429 storms/URL build/Key shape) |

### Cycle 4 — 3 findings, 2 fixed + 1 residual

| ID | Severity | Framing | Finding | Fix |
|---|---|---|---|---|
| A-CYCLE4-1 | Low | A:doc | jsdoc claimed "X-Api-Key header AND api_key query param" — code only sends header | Update jsdoc; explicit "header only" rationale |
| A-CYCLE4-2 | Low | A:defensive | `JSON.stringify` on body not try/caught (circular ref crashes) | RESIDUAL — internal callers pass plain objects only |
| A-CYCLE4-3 | Low | A:robustness | `_enforceGap` doesn't clamp negative `elapsed` if system clock skews backward | `Math.max(0, now - _lastCallAt)` |

### Cycle 5 — 2 findings, both fixed

| ID | Severity | Framing | Finding | Fix |
|---|---|---|---|---|
| A-CYCLE5-1 | Low | A:correctness | Strategy 2 doesn't dedup `altDomain` against `corporateDomain` — duplicate Apollo call | Dedup at cascade entry via `_seenDomains` Set |
| A-CYCLE5-2 | Low | A:correctness | `altDomains` not deduped against itself | Same fix covers both |

### Cycle 6 — 1 finding (residual), 3 consecutive CLEAN rounds → CONVERGENCE

| ID | Severity | Framing | Finding | Fix |
|---|---|---|---|---|
| A-CYCLE6-1 | Low | A:semantic | People without `id` field counted in `rejected.duplicate` — semantically misleading | RESIDUAL — `duplicate` documented to mean "skipped (duplicate or unprocessable)" |

**Round 1**: 1 justified residual, 0 unresolved.<br>
**Round 2**: 0 findings.<br>
**Round 3**: 0 findings.<br>
→ **GODLIKE CONVERGENCE**.

## Residual findings (justified, fundamentally unresolvable in this bundle)

| ID | Severity | Description | Justification |
|---|---|---|---|
| F-NEW-A | Low | Inner `findOrg` / `collectContacts` continue running after `/discover-simple` outer 300s timeout fires | Threading AbortSignal through every Apollo call site is a major refactor. Cost is bounded (~120s additional Apollo calls before forward progress halts on per-call 30s timeouts). Defer to dedicated cancellation hardening bundle. |
| F-A2.1 | Low | `apolloPost` `path` argument not validated against `..` segments | Internal callers only, all literal strings. URL constructor normalizes. Defense-in-depth only. |
| F-A7.1 | Low | `console.warn` lines from `apolloProspector` lack request IDs | Cross-request correlation available via `action_logs.executed_at + user_id`. Server stdout correlation acceptable as residual. |
| F-A8.1 | Low | `attempts[N].detail` is freeform string, used inconsistently | Cosmetic. Diagnostic field, not part of contract. |
| F-B5.1 | Low | 429 budget is process-wide; one user can exhaust the safety net for all | Priced into design — we don't babysit hostile users at Apollo's expense. Per-route per-user rate limits cap individual abuse. |
| F-B-NEW-2 | Info | `redactApolloKey` heuristic could enhance UUID/SHA-1/SHA-256 detection | False positive cost is acceptable (redacted hash in debug log). |
| F-C1.1 | Low | `attempts` array doesn't distinguish "Apollo returned 0 results" from "Apollo errored" | Workaround: check `action_log.errorDetail` or `metadata.error_class`. Refactor needs error-class threading from `apolloPost`. Defer to 2.2-BE-C orchestrator. |
| F-C7.1 | Low | `action_log.metadata` doesn't track Apollo credit consumption | Apollo response doesn't surface credit cost in headers; would require periodic `/credits/balance` polling. Future enhancement. |
| F12 (carried from 2.2-BE-A) | Low | In-memory rate limiter doesn't horizontally scale | Multi-instance Replit deployments would split user budgets. Move to Redis INCR+EXPIRE when needed. |

## Verification chain

```
✓ Brace balance: apolloProspector.ts 86/86, orgFinder.ts 99/99, contactCollector.ts 99/99
✓ TS strict compile: all four services (incl. companyResolver) compile clean, exit 0
✓ Patch chain: BE-2 → 2.1-BE → 2.2-BE-A → 2.2-BE-B applied successfully
✓ Idempotency: second apply.sh = SKIP/NOOP, evidence checks pass
✓ Action types: 5 ACTION_TYPES total
✓ Routes: 5 endpoints total, all auth-gated, all rate-limited, all write action_logs
```

## Ship instructions

### One-time prep

If `APOLLO_API_KEY` isn't already a Replit Secret:
1. Replit dashboard → Secrets
2. Add `APOLLO_API_KEY` with the Apollo dashboard key
3. Add to BOTH workspace and deploy environments
4. The key must NOT contain whitespace or control chars (audit fix A6.1 rejects malformed keys at runtime — endpoints return 503 apollo_not_configured if key fails validation)

### Apply

```bash
cd /tmp && rm -rf ticket-2-2-be-b && unzip -q ~/Downloads/ticket-2-2-be-b.zip
cd ~/your-Email-Folllowuper-workspace
bash /tmp/ticket-2-2-be-b/apply.sh
```

### Restart workflow

Backend bundle — workflow restart REQUIRED.

In Replit UI: **Stop** the api-server workflow, then **Run** it.

```bash
curl -s http://localhost:80/api/healthz   # expect {"status":"ok"}
```

### Test

```bash
cp /tmp/ticket-2-2-be-b/new-files/tests/integration-2-2-be-b-stage-b.mjs /tmp/
node /tmp/integration-2-2-be-b-stage-b.mjs
# expect: [PASS] all N passed
# or: SKIP_APOLLO_TESTS=1 node /tmp/integration-2-2-be-b-stage-b.mjs
```

If green: walk `docs/manual-test-2-2-be-b.md` for the real-Apollo cascade probes.

### Rollback

Backend-only patches; revert + delete + restart workflow.

```bash
git diff HEAD --name-only \
  | grep -E "(action_logs|prospector\.ts|apolloProspector|orgFinder|contactCollector)" \
  | xargs git checkout HEAD --
git status
# Then restart api-server workflow
```

## Cost notes

Apollo charges per credit. Typical usage:
- `/find-org` — 1-3 credits (cascade resolves in 1-2 strategies typically)
- `/collect-contacts` — 30-100 credits (one per enrichment)
- `/discover-simple` — 35-105 credits

Worst-case `/find-org` per-request (post-audit caps):
- Strategy 1: 1-2 calls
- Strategy 2: 8 alt domains × 2 = 16 calls max
- Strategy 3: 1 call
- Strategy 4: 5 queries × 1 = 5 calls
- Strategy 5: 1-2 calls
- Total: ~25 Apollo calls per `/find-org`

Process-wide 429 budget: at most 2 retry sleeps per 60s, so a stuck cascade can't burn more than ~5 minutes against Apollo before surfacing ApolloRateLimitError to the user.

## What's next (2.2-BE-C)

- `opusRescue` — escalation to opus when sonnet disambiguation fails
- `discoveryOrchestrator` — chains resolveCompany → findOrg → opusRescue → collectContacts with full LLM-validated retries
- Phase 3 subsidiary expansion (SMBC Nikko + SMBC Consumer Finance + parent merge)
- `/discover` endpoint — production-grade replacement for `/discover-simple`
