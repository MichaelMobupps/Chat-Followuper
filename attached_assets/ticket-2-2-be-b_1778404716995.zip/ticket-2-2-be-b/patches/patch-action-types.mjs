#!/usr/bin/env node
/**
 * Anchored, idempotent patch for lib/db/src/schema/action_logs.ts.
 * Adds three new ACTION_TYPES keys for 2.2-BE-B:
 *   - prospectorOrgFound: "prospector.org_found"
 *   - prospectorContactsCollected: "prospector.contacts_collected"
 *   - prospectorDiscoverSimple: "prospector.discover_simple"
 *
 * Anchored on the prospectorCompanyResolved line added in 2.2-BE-A.
 */
import fs from "node:fs";

const PATH = "lib/db/src/schema/action_logs.ts";

let src = fs.readFileSync(PATH, "utf8");
const before = src;
const log = (m) => console.log(`[patch-action-types] ${m}`);

const anchor = '  prospectorCompanyResolved: "prospector.company_resolved",';
const insert =
  '  prospectorCompanyResolved: "prospector.company_resolved",\n' +
  '  prospectorOrgFound: "prospector.org_found",\n' +
  '  prospectorContactsCollected: "prospector.contacts_collected",\n' +
  '  prospectorDiscoverSimple: "prospector.discover_simple",';

const presenceMarkers = [
  'prospectorOrgFound: "prospector.org_found"',
  'prospectorContactsCollected: "prospector.contacts_collected"',
  'prospectorDiscoverSimple: "prospector.discover_simple"',
];

const allPresent = presenceMarkers.every((m) => src.includes(m));
if (allPresent) {
  log("[SKIP] all 2.2-BE-B action types already present");
} else if (presenceMarkers.some((m) => src.includes(m))) {
  console.error(
    `[patch-action-types] [FAIL] partial state: some 2.2-BE-B keys present, others missing.`,
  );
  console.error(`       Manual review required — refusing to patch.`);
  process.exit(2);
} else if (!src.includes(anchor)) {
  console.error(
    `[patch-action-types] [FAIL] anchor not found: ${anchor}`,
  );
  console.error(
    "       Apply 2.2-BE-A first if not done — that's what introduces prospectorCompanyResolved.",
  );
  process.exit(2);
} else {
  src = src.replace(anchor, insert);
  log("[APPLY] added prospectorOrgFound, prospectorContactsCollected, prospectorDiscoverSimple");
}

if (src === before) {
  log("[NOOP] no changes");
} else {
  fs.writeFileSync(PATH, src);
  log("[DONE] action_logs.ts updated");
}

const finalSrc = fs.readFileSync(PATH, "utf8");
const evidence = {
  prospectorOrgFound: (
    finalSrc.match(/prospectorOrgFound: "prospector\.org_found"/g) || []
  ).length,
  prospectorContactsCollected: (
    finalSrc.match(/prospectorContactsCollected: "prospector\.contacts_collected"/g) || []
  ).length,
  prospectorDiscoverSimple: (
    finalSrc.match(/prospectorDiscoverSimple: "prospector\.discover_simple"/g) || []
  ).length,
  prospectorCompanyResolved_still_present: (
    finalSrc.match(/prospectorCompanyResolved: "prospector\.company_resolved"/g) || []
  ).length,
  prospectorUrlsResolved_still_present: (
    finalSrc.match(/prospectorUrlsResolved: "prospector\.urls_resolved"/g) || []
  ).length,
};
console.log("[patch-action-types] evidence:", JSON.stringify(evidence));
const expected = {
  prospectorOrgFound: 1,
  prospectorContactsCollected: 1,
  prospectorDiscoverSimple: 1,
  prospectorCompanyResolved_still_present: 1,
  prospectorUrlsResolved_still_present: 1,
};
for (const [k, v] of Object.entries(expected)) {
  if (evidence[k] !== v) {
    console.error(
      `[patch-action-types] [FAIL] evidence ${k}: got ${evidence[k]}, expected ${v}`,
    );
    process.exit(3);
  }
}
console.log("[patch-action-types] all evidence checks passed");
