#!/usr/bin/env node
/**
 * Anchored, idempotent patch for artifacts/api-server/src/routes/prospector.ts.
 * Adds three new endpoints for Ticket 2.2-BE-B:
 *
 *   POST /api/prospector/find-org            (resolved company → Apollo org)
 *   POST /api/prospector/collect-contacts    (Apollo org → contacts)
 *   POST /api/prospector/discover-simple     (resolved company → org + contacts)
 *
 * Audit pattern reuses 2.2-BE-A:
 *   - rate limiter (in-memory sliding window) — separate buckets per endpoint
 *     so org-find limits don't starve contact-collect, and vice versa
 *   - withTimeout outer wrapper to bound total handler time
 *   - sanitizeForStorage on all metadata fields written to action_logs
 *   - redactSecrets on errorDetail before action_log write
 *   - Auth via requireAuth (same as 2.1-BE/2.2-BE-A)
 *   - Zod .strict() body schemas
 */
import fs from "node:fs";

const PATH = "artifacts/api-server/src/routes/prospector.ts";

let src = fs.readFileSync(PATH, "utf8");
const before = src;
const log = (m) => console.log(`[patch-prospector-route] ${m}`);

// ─── Patch 1: import line ─────────────────────────────────────────────────

const importAnchor =
  'import {\n' +
  '  resolveCompany,\n' +
  '  redactSecrets,\n' +
  '  sanitizeForStorage,\n' +
  '  type ResolveCompanyInput,\n' +
  '  type ResolveCompanyResult,\n' +
  '} from "../services/companyResolver";';

const importInsert =
  importAnchor +
  '\n' +
  'import {\n' +
  '  findOrg,\n' +
  '  type ApolloOrg,\n' +
  '  type FindOrgResult,\n' +
  '} from "../services/orgFinder";\n' +
  'import {\n' +
  '  collectContacts,\n' +
  '  type ApolloContact,\n' +
  '  type CollectContactsResult,\n' +
  '} from "../services/contactCollector";\n' +
  'import {\n' +
  '  ApolloMissingApiKeyError,\n' +
  '  ApolloRateLimitError,\n' +
  '  redactApolloKey,\n' +
  '} from "../services/apolloProspector";\n' +
  'import type { ResolvedCompany } from "../services/companyResolver";';

if (src.includes('from "../services/orgFinder"')) {
  log("[SKIP] orgFinder import already present");
} else if (!src.includes(importAnchor)) {
  console.error(
    `[patch-prospector-route] [FAIL] import anchor not found.`,
  );
  console.error("       Apply 2.2-BE-A first if not done.");
  process.exit(2);
} else {
  src = src.replace(importAnchor, importInsert);
  log("[APPLY] added orgFinder/contactCollector/apolloProspector imports");
}

// ─── Patch 2: routes block ────────────────────────────────────────────────

const ROUTE_BLOCK = `// ─── Ticket 2.2-BE-B: /find-org, /collect-contacts, /discover-simple ──────
//
// Stage B of the prospector cascade. Takes the output of /resolve-company and
// drives Apollo to find the org and its contacts.
//
// Three endpoints to enable both the orchestrated flow (/discover-simple)
// AND the per-stage debug flow (/find-org and /collect-contacts run independently
// when the manual UI wants to inspect/fix one stage at a time).
//
// Cost: ~1-15 Apollo API calls per request (cascade depth-dependent).
//   Apollo charges per credit, not per call — typical /find-org: ~3 credits;
//   /collect-contacts: ~30-100 credits (one per person enrichment); /discover-
//   simple: sum of both.

const FIND_ORG_TIMEOUT_MS = 60_000;
const COLLECT_CONTACTS_TIMEOUT_MS = 240_000; // can be tens of Apollo calls
const DISCOVER_SIMPLE_TIMEOUT_MS = 300_000;

/** Per-user rate limits, separate buckets per endpoint so heavy contact
 *  collection doesn't starve light org lookups. */
const STAGE_B_RATE_WINDOW_MS = 60_000;
const FIND_ORG_RATE_MAX = 60;
const COLLECT_CONTACTS_RATE_MAX = 20;
const DISCOVER_SIMPLE_RATE_MAX = 20;

const STAGE_B_RATE_MAP_MAX_USERS = 5000;

// ─── Per-bucket rate limiter ─────────────────────────────────────────────
// Same pattern as 2.2-BE-A's checkResolveCompanyRateLimit, factored to support
// multiple named buckets. Single-process scope — see audit fix F12 in 2.2-BE-A
// for the horizontal-scaling upgrade path (Redis INCR+EXPIRE).

const _stageBRateMaps: Record<string, Map<string, number[]>> = {
  find_org: new Map(),
  collect_contacts: new Map(),
  discover_simple: new Map(),
};

function _sweepStageBExpired(bucket: string, now: number): void {
  const m = _stageBRateMaps[bucket];
  if (!m) return;
  const cutoff = now - STAGE_B_RATE_WINDOW_MS;
  for (const [uid, calls] of m) {
    if (calls.length === 0 || calls[calls.length - 1] <= cutoff) {
      m.delete(uid);
    }
  }
}

function checkStageBRateLimit(
  bucket: "find_org" | "collect_contacts" | "discover_simple",
  userId: string,
  maxCalls: number,
): { ok: boolean; resetMs: number } {
  const now = Date.now();
  const m = _stageBRateMaps[bucket];
  if (!m) {
    return { ok: true, resetMs: STAGE_B_RATE_WINDOW_MS };
  }
  if (m.size > STAGE_B_RATE_MAP_MAX_USERS) {
    _sweepStageBExpired(bucket, now);
  }
  const cutoff = now - STAGE_B_RATE_WINDOW_MS;
  const calls = m.get(userId) ?? [];
  const fresh = calls.filter((t) => t > cutoff);
  if (fresh.length >= maxCalls) {
    return { ok: false, resetMs: fresh[0] + STAGE_B_RATE_WINDOW_MS - now };
  }
  fresh.push(now);
  m.set(userId, fresh);
  return { ok: true, resetMs: STAGE_B_RATE_WINDOW_MS };
}

/** Local copy of 2.2-BE-A's withTimeout — different name to avoid TS merged
 *  declaration conflicts since both blocks are now in the same file. Same
 *  semantics: late rejection swallowed, timer cleared on settle. */
function withStageBTimeout<T>(p: Promise<T>, ms: number, label: string): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | null = null;
  const timeout = new Promise<never>((_, reject) => {
    timer = setTimeout(() => {
      reject(new Error(\`\${label} exceeded \${ms}ms outer timeout\`));
    }, ms);
  });
  p.catch(() => {
    /* swallow late rejection */
  });
  return Promise.race([p, timeout]).finally(() => {
    if (timer) clearTimeout(timer);
  }) as Promise<T>;
}

/** Resolved company body schema — used by /find-org and /discover-simple.
 *  Mirrors the ResolvedCompany interface from companyResolver.
 *
 *  Audit fix B2.1: alternativeDomains hard cap at 8 (down from 20). The Apollo
 *  cascade iterates ALL alt domains in Strategy 2 (1-2 calls each). With max 8
 *  we cap Strategy 2 cost at ~16 Apollo calls. Real /resolve-company outputs
 *  are typically 0-3 alt domains; this prevents authenticated-user cost
 *  amplification via hand-crafted bodies. */
const resolvedCompanyBodySchema = z.object({
  companyName: z.string().trim().min(1).max(500),
  parentCompany: z.string().trim().max(500).default(""),
  corporateDomain: z.string().trim().max(500).default(""),
  alternativeDomains: z.array(z.string().trim().max(500)).max(8).default([]),
  searchQueries: z.array(z.string().trim().max(500)).max(5).default([]),
  isMultinational: z.boolean().default(false),
  focusMarket: z.string().trim().max(200).default(""),
  primaryMarket: z.string().trim().max(200).default(""),
  reasoning: z.string().trim().max(2000).default(""),
});

/** ApolloOrg body schema — used by /collect-contacts. Caller must supply an
 *  org with at least an id OR domain — neither is meaningful alone. */
const apolloOrgBodySchema = z
  .object({
    id: z.string().trim().max(200).default(""),
    name: z.string().trim().max(500).default(""),
    domain: z.string().trim().max(500).default(""),
    industry: z.string().trim().max(500).default(""),
    estimatedNumEmployees: z.number().int().min(0).max(10_000_000).default(0),
    country: z.string().trim().max(200).default(""),
  })
  .refine((o) => Boolean(o.id || o.domain), {
    message: "ApolloOrg must have at least one of id or domain",
    path: ["id"],
  });

// ─── /find-org ────────────────────────────────────────────────────────────

const findOrgBodySchema = z
  .object({
    resolved: resolvedCompanyBodySchema,
  })
  .strict();

router.post(
  "/prospector/find-org",
  requireAuth,
  async (req: Request, res: Response): Promise<void> => {
    const user = req.user!;
    const start = Date.now();

    const rl = checkStageBRateLimit("find_org", user.id, FIND_ORG_RATE_MAX);
    if (!rl.ok) {
      const retryAfterSec = Math.ceil(rl.resetMs / 1000);
      try {
        await db.insert(actionLogsTable).values({
          userId: user.id,
          actionType: ACTION_TYPES.prospectorOrgFound,
          actionStatus: "blocked",
          durationMs: Date.now() - start,
          metadata: {
            error_class: "rate_limit",
            limit_per_window: FIND_ORG_RATE_MAX,
            window_seconds: STAGE_B_RATE_WINDOW_MS / 1000,
            retry_after_seconds: retryAfterSec,
          },
        });
      } catch {}
      res.setHeader("Retry-After", String(retryAfterSec));
      res.status(429).json({
        error: "rate_limit_exceeded",
        message: \`Too many /find-org calls. Limit \${FIND_ORG_RATE_MAX}/min. Retry in \${retryAfterSec}s.\`,
        retryAfterSeconds: retryAfterSec,
      });
      return;
    }

    let body: z.infer<typeof findOrgBodySchema>;
    try {
      body = findOrgBodySchema.parse(req.body);
    } catch (err) {
      if (err instanceof ZodError) {
        const mapped = zodErrorToHttp(err);
        res.status(mapped.status).json(mapped.body);
        return;
      }
      throw err;
    }

    const resolved: ResolvedCompany = body.resolved;

    let result: FindOrgResult;
    try {
      result = await withStageBTimeout(findOrg(resolved), FIND_ORG_TIMEOUT_MS, "findOrg");
    } catch (err) {
      const errMsg = err instanceof Error ? err.message : String(err);
      const isMissingKey = err instanceof ApolloMissingApiKeyError;
      const isRateLimit = err instanceof ApolloRateLimitError;
      const isTimeout = /timeout|timed out|aborted|outer timeout/i.test(errMsg);
      const safeErr = redactApolloKey(redactSecrets(errMsg)).slice(0, 500);

      try {
        await db.insert(actionLogsTable).values({
          userId: user.id,
          actionType: ACTION_TYPES.prospectorOrgFound,
          actionStatus: "failure",
          durationMs: Date.now() - start,
          errorDetail: safeErr,
          metadata: {
            company_name: sanitizeForStorage(resolved.companyName, 200),
            corporate_domain: sanitizeForStorage(resolved.corporateDomain, 200),
            error_class: isMissingKey
              ? "missing_apollo_key"
              : isRateLimit
                ? "apollo_rate_limit"
                : isTimeout
                  ? "timeout"
                  : "apollo_error",
          },
        });
      } catch {}

      const status = isMissingKey
        ? 503
        : isRateLimit
          ? 503
          : isTimeout
            ? 504
            : 502;
      const code = isMissingKey
        ? "apollo_not_configured"
        : isRateLimit
          ? "apollo_rate_limited"
          : isTimeout
            ? "find_org_timeout"
            : "find_org_failure";
      res.status(status).json({
        error: code,
        message: isMissingKey
          ? "Apollo is not configured on this server. Add APOLLO_API_KEY as a Replit Secret and restart api-server."
          : isRateLimit
            ? "Apollo rate limit hit. Try again in a minute."
            : isTimeout
              ? "Apollo cascade timed out."
              : "Org find failed against Apollo. Please retry, or contact support.",
        retryAfterSeconds:
          isRateLimit && err instanceof ApolloRateLimitError
            ? err.retryAfterSeconds
            : undefined,
      });
      return;
    }

    try {
      await db.insert(actionLogsTable).values({
        userId: user.id,
        actionType: ACTION_TYPES.prospectorOrgFound,
        actionStatus: result.org ? "success" : "skipped",
        durationMs: Date.now() - start,
        metadata: {
          company_name: sanitizeForStorage(resolved.companyName, 200),
          corporate_domain: sanitizeForStorage(resolved.corporateDomain, 200),
          parent_company: sanitizeForStorage(resolved.parentCompany, 200) || null,
          strategy: result.strategy,
          upgraded_to_parent: result.upgradedToParent,
          org_found: Boolean(result.org),
          org_name: result.org ? sanitizeForStorage(result.org.name, 200) : null,
          org_employees: result.org?.estimatedNumEmployees ?? null,
          attempt_count: result.attempts.length,
        },
      });
    } catch {}

    res.status(200).json({
      org: result.org,
      strategy: result.strategy,
      upgradedToParent: result.upgradedToParent,
      attempts: result.attempts,
    });
  },
);

// ─── /collect-contacts ────────────────────────────────────────────────────

const collectContactsBodySchema = z
  .object({
    org: apolloOrgBodySchema,
    resolved: resolvedCompanyBodySchema.nullable().optional(),
    targetContacts: z.number().int().min(1).max(50).optional(),
  })
  .strict();

router.post(
  "/prospector/collect-contacts",
  requireAuth,
  async (req: Request, res: Response): Promise<void> => {
    const user = req.user!;
    const start = Date.now();

    const rl = checkStageBRateLimit(
      "collect_contacts",
      user.id,
      COLLECT_CONTACTS_RATE_MAX,
    );
    if (!rl.ok) {
      const retryAfterSec = Math.ceil(rl.resetMs / 1000);
      try {
        await db.insert(actionLogsTable).values({
          userId: user.id,
          actionType: ACTION_TYPES.prospectorContactsCollected,
          actionStatus: "blocked",
          durationMs: Date.now() - start,
          metadata: {
            error_class: "rate_limit",
            limit_per_window: COLLECT_CONTACTS_RATE_MAX,
            window_seconds: STAGE_B_RATE_WINDOW_MS / 1000,
            retry_after_seconds: retryAfterSec,
          },
        });
      } catch {}
      res.setHeader("Retry-After", String(retryAfterSec));
      res.status(429).json({
        error: "rate_limit_exceeded",
        message: \`Too many /collect-contacts calls. Limit \${COLLECT_CONTACTS_RATE_MAX}/min. Retry in \${retryAfterSec}s.\`,
        retryAfterSeconds: retryAfterSec,
      });
      return;
    }

    let body: z.infer<typeof collectContactsBodySchema>;
    try {
      body = collectContactsBodySchema.parse(req.body);
    } catch (err) {
      if (err instanceof ZodError) {
        const mapped = zodErrorToHttp(err);
        res.status(mapped.status).json(mapped.body);
        return;
      }
      throw err;
    }

    const org: ApolloOrg = {
      id: body.org.id,
      name: body.org.name,
      domain: body.org.domain,
      industry: body.org.industry,
      estimatedNumEmployees: body.org.estimatedNumEmployees,
      country: body.org.country,
    };
    const resolved = body.resolved ?? null;
    const opts = body.targetContacts ? { targetContacts: body.targetContacts } : {};

    let result: CollectContactsResult;
    try {
      result = await withStageBTimeout(
        collectContacts(org, resolved, opts),
        COLLECT_CONTACTS_TIMEOUT_MS,
        "collectContacts",
      );
    } catch (err) {
      const errMsg = err instanceof Error ? err.message : String(err);
      const isMissingKey = err instanceof ApolloMissingApiKeyError;
      const isRateLimit = err instanceof ApolloRateLimitError;
      const isTimeout = /timeout|timed out|aborted|outer timeout/i.test(errMsg);
      const safeErr = redactApolloKey(redactSecrets(errMsg)).slice(0, 500);

      try {
        await db.insert(actionLogsTable).values({
          userId: user.id,
          actionType: ACTION_TYPES.prospectorContactsCollected,
          actionStatus: "failure",
          durationMs: Date.now() - start,
          errorDetail: safeErr,
          metadata: {
            org_id: sanitizeForStorage(org.id, 200),
            org_domain: sanitizeForStorage(org.domain, 200),
            error_class: isMissingKey
              ? "missing_apollo_key"
              : isRateLimit
                ? "apollo_rate_limit"
                : isTimeout
                  ? "timeout"
                  : "apollo_error",
          },
        });
      } catch {}

      const status = isMissingKey ? 503 : isRateLimit ? 503 : isTimeout ? 504 : 502;
      const code = isMissingKey
        ? "apollo_not_configured"
        : isRateLimit
          ? "apollo_rate_limited"
          : isTimeout
            ? "collect_contacts_timeout"
            : "collect_contacts_failure";
      res.status(status).json({
        error: code,
        message: isMissingKey
          ? "Apollo is not configured on this server. Add APOLLO_API_KEY."
          : isRateLimit
            ? "Apollo rate limit hit. Try again in a minute."
            : isTimeout
              ? "Apollo people-search cascade timed out."
              : "Contact collection failed against Apollo. Please retry.",
        retryAfterSeconds:
          isRateLimit && err instanceof ApolloRateLimitError
            ? err.retryAfterSeconds
            : undefined,
      });
      return;
    }

    try {
      await db.insert(actionLogsTable).values({
        userId: user.id,
        actionType: ACTION_TYPES.prospectorContactsCollected,
        actionStatus: result.contacts.length > 0 ? "success" : "skipped",
        durationMs: Date.now() - start,
        metadata: {
          org_id: sanitizeForStorage(org.id, 200),
          org_domain: sanitizeForStorage(org.domain, 200),
          org_employees: org.estimatedNumEmployees,
          contacts_returned: result.contacts.length,
          phases_run: result.phasesRun.map((p) => p.phase),
          rejected_no_email: result.rejected.noEmail,
          rejected_domain_mismatch: result.rejected.domainMismatch,
          rejected_title: result.rejected.titleRejected,
          rejected_duplicate: result.rejected.duplicate,
        },
      });
    } catch {}

    res.status(200).json({
      contacts: result.contacts,
      phasesRun: result.phasesRun,
      rejected: result.rejected,
    });
  },
);

// ─── /discover-simple ─────────────────────────────────────────────────────

const discoverSimpleBodySchema = z
  .object({
    resolved: resolvedCompanyBodySchema,
    targetContacts: z.number().int().min(1).max(50).optional(),
  })
  .strict();

router.post(
  "/prospector/discover-simple",
  requireAuth,
  async (req: Request, res: Response): Promise<void> => {
    const user = req.user!;
    const start = Date.now();

    const rl = checkStageBRateLimit(
      "discover_simple",
      user.id,
      DISCOVER_SIMPLE_RATE_MAX,
    );
    if (!rl.ok) {
      const retryAfterSec = Math.ceil(rl.resetMs / 1000);
      try {
        await db.insert(actionLogsTable).values({
          userId: user.id,
          actionType: ACTION_TYPES.prospectorDiscoverSimple,
          actionStatus: "blocked",
          durationMs: Date.now() - start,
          metadata: {
            error_class: "rate_limit",
            limit_per_window: DISCOVER_SIMPLE_RATE_MAX,
            window_seconds: STAGE_B_RATE_WINDOW_MS / 1000,
            retry_after_seconds: retryAfterSec,
          },
        });
      } catch {}
      res.setHeader("Retry-After", String(retryAfterSec));
      res.status(429).json({
        error: "rate_limit_exceeded",
        message: \`Too many /discover-simple calls. Limit \${DISCOVER_SIMPLE_RATE_MAX}/min. Retry in \${retryAfterSec}s.\`,
        retryAfterSeconds: retryAfterSec,
      });
      return;
    }

    let body: z.infer<typeof discoverSimpleBodySchema>;
    try {
      body = discoverSimpleBodySchema.parse(req.body);
    } catch (err) {
      if (err instanceof ZodError) {
        const mapped = zodErrorToHttp(err);
        res.status(mapped.status).json(mapped.body);
        return;
      }
      throw err;
    }

    const resolved: ResolvedCompany = body.resolved;
    const opts = body.targetContacts ? { targetContacts: body.targetContacts } : {};

    let orgResult: FindOrgResult;
    let contactsResult: CollectContactsResult | null = null;

    try {
      const work = (async () => {
        const orgRes = await findOrg(resolved);
        if (!orgRes.org) return { orgRes, contactsRes: null };
        const contactsRes = await collectContacts(orgRes.org, resolved, opts);
        return { orgRes, contactsRes };
      })();
      const out = await withStageBTimeout(work, DISCOVER_SIMPLE_TIMEOUT_MS, "discoverSimple");
      orgResult = out.orgRes;
      contactsResult = out.contactsRes;
    } catch (err) {
      const errMsg = err instanceof Error ? err.message : String(err);
      const isMissingKey = err instanceof ApolloMissingApiKeyError;
      const isRateLimit = err instanceof ApolloRateLimitError;
      const isTimeout = /timeout|timed out|aborted|outer timeout/i.test(errMsg);
      const safeErr = redactApolloKey(redactSecrets(errMsg)).slice(0, 500);

      try {
        await db.insert(actionLogsTable).values({
          userId: user.id,
          actionType: ACTION_TYPES.prospectorDiscoverSimple,
          actionStatus: "failure",
          durationMs: Date.now() - start,
          errorDetail: safeErr,
          metadata: {
            company_name: sanitizeForStorage(resolved.companyName, 200),
            error_class: isMissingKey
              ? "missing_apollo_key"
              : isRateLimit
                ? "apollo_rate_limit"
                : isTimeout
                  ? "timeout"
                  : "apollo_error",
          },
        });
      } catch {}

      const status = isMissingKey ? 503 : isRateLimit ? 503 : isTimeout ? 504 : 502;
      const code = isMissingKey
        ? "apollo_not_configured"
        : isRateLimit
          ? "apollo_rate_limited"
          : isTimeout
            ? "discover_simple_timeout"
            : "discover_simple_failure";
      res.status(status).json({
        error: code,
        message: isMissingKey
          ? "Apollo is not configured. Add APOLLO_API_KEY."
          : isRateLimit
            ? "Apollo rate limit hit."
            : isTimeout
              ? "Discovery timed out."
              : "Discovery failed.",
        retryAfterSeconds:
          isRateLimit && err instanceof ApolloRateLimitError
            ? err.retryAfterSeconds
            : undefined,
      });
      return;
    }

    try {
      await db.insert(actionLogsTable).values({
        userId: user.id,
        actionType: ACTION_TYPES.prospectorDiscoverSimple,
        actionStatus:
          orgResult.org && contactsResult && contactsResult.contacts.length > 0
            ? "success"
            : "skipped",
        durationMs: Date.now() - start,
        metadata: {
          company_name: sanitizeForStorage(resolved.companyName, 200),
          corporate_domain: sanitizeForStorage(resolved.corporateDomain, 200),
          strategy: orgResult.strategy,
          upgraded_to_parent: orgResult.upgradedToParent,
          org_found: Boolean(orgResult.org),
          org_name: orgResult.org ? sanitizeForStorage(orgResult.org.name, 200) : null,
          org_employees: orgResult.org?.estimatedNumEmployees ?? null,
          contacts_returned: contactsResult?.contacts.length ?? 0,
          phases_run: contactsResult?.phasesRun.map((p) => p.phase) ?? [],
        },
      });
    } catch {}

    res.status(200).json({
      org: orgResult.org,
      strategy: orgResult.strategy,
      upgradedToParent: orgResult.upgradedToParent,
      attempts: orgResult.attempts,
      contacts: contactsResult?.contacts ?? [],
      phasesRun: contactsResult?.phasesRun ?? [],
      rejected: contactsResult?.rejected ?? {
        noEmail: 0,
        domainMismatch: 0,
        titleRejected: 0,
        duplicate: 0,
      },
    });
  },
);

`;

const exportAnchor = "export default router;";

if (src.includes('"/prospector/find-org"')) {
  log("[SKIP] /find-org route already present");
} else if (!src.includes(exportAnchor)) {
  console.error(
    `[patch-prospector-route] [FAIL] export anchor not found.`,
  );
  process.exit(2);
} else {
  src = src.replace(exportAnchor, ROUTE_BLOCK + exportAnchor);
  log("[APPLY] added /find-org, /collect-contacts, /discover-simple route handlers");
}

if (src === before) {
  log("[NOOP] no changes");
} else {
  fs.writeFileSync(PATH, src);
  log("[DONE] prospector.ts updated");
}

const finalSrc = fs.readFileSync(PATH, "utf8");
const evidence = {
  orgFinder_import: (finalSrc.match(/from "\.\.\/services\/orgFinder"/g) || []).length,
  contactCollector_import: (finalSrc.match(/from "\.\.\/services\/contactCollector"/g) || []).length,
  apolloProspector_import: (finalSrc.match(/from "\.\.\/services\/apolloProspector"/g) || []).length,
  find_org_route: (finalSrc.match(/"\/prospector\/find-org"/g) || []).length,
  collect_contacts_route: (finalSrc.match(/"\/prospector\/collect-contacts"/g) || []).length,
  discover_simple_route: (finalSrc.match(/"\/prospector\/discover-simple"/g) || []).length,
  resolve_urls_still_present: (finalSrc.match(/"\/prospector\/resolve-urls"/g) || []).length,
  resolve_company_still_present: (finalSrc.match(/"\/prospector\/resolve-company"/g) || []).length,
  withStageBTimeout_present: (finalSrc.match(/withStageBTimeout/g) || []).length,
};
console.log("[patch-prospector-route] evidence:", JSON.stringify(evidence));
const minExpected = {
  orgFinder_import: 1,
  contactCollector_import: 1,
  apolloProspector_import: 1,
  find_org_route: 1,
  collect_contacts_route: 1,
  discover_simple_route: 1,
  resolve_urls_still_present: 1,
  resolve_company_still_present: 1,
  withStageBTimeout_present: 4, // 1 def + 3 callsites
};
for (const [k, v] of Object.entries(minExpected)) {
  if (evidence[k] < v) {
    console.error(
      `[patch-prospector-route] [FAIL] evidence ${k}: got ${evidence[k]}, expected >= ${v}`,
    );
    process.exit(3);
  }
}
console.log("[patch-prospector-route] all evidence checks passed");
