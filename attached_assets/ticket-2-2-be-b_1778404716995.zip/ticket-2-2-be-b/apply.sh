#!/usr/bin/env bash
# Ticket 2.2-BE-B — Apollo cascade (find-org + collect-contacts + discover-simple)
# Backend bundle. Idempotent. Safe to re-run.
set -euo pipefail

BUNDLE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
API_SRC="artifacts/api-server/src"
DB_SRC="lib/db/src"

if [ ! -d "$API_SRC" ]; then
  echo "[apply] FAIL: $API_SRC not found. Run from project root." >&2
  exit 2
fi

# Pre-flight: depends on 2.1-BE + 2.2-BE-A
for required in \
  "$API_SRC/services/urlResolver.ts" \
  "$API_SRC/services/companyResolver.ts" \
  "$API_SRC/routes/prospector.ts"; do
  if [ ! -f "$required" ]; then
    echo "[apply] FAIL: $required missing — apply 2.1-BE and 2.2-BE-A first." >&2
    exit 3
  fi
done

if ! grep -q '"/prospector/resolve-company"' "$API_SRC/routes/prospector.ts"; then
  echo "[apply] FAIL: 2.2-BE-A's /resolve-company route missing — apply 2.2-BE-A first." >&2
  exit 3
fi

if [ ! -f "$DB_SRC/schema/action_logs.ts" ]; then
  echo "[apply] FAIL: $DB_SRC/schema/action_logs.ts missing." >&2
  exit 3
fi

if ! grep -q 'prospectorCompanyResolved' "$DB_SRC/schema/action_logs.ts"; then
  echo "[apply] FAIL: 2.2-BE-A's prospectorCompanyResolved key missing — apply 2.2-BE-A first." >&2
  exit 3
fi

echo "==[ Step 1/6 ]== Verify APOLLO_API_KEY hint"
echo "  (apply.sh does not check secrets; reminder: APOLLO_API_KEY must be set"
echo "  as a Replit Secret on both workspace AND deploy. Without it, the new"
echo "  endpoints return 503 apollo_not_configured.)"

echo
echo "==[ Step 2/6 ]== Copy 2.2-BE-B services (apolloProspector, orgFinder, contactCollector)"
mkdir -p "$API_SRC/services"
cp -v "$BUNDLE_DIR/new-files/artifacts/api-server/src/services/apolloProspector.ts" \
      "$API_SRC/services/apolloProspector.ts"
cp -v "$BUNDLE_DIR/new-files/artifacts/api-server/src/services/orgFinder.ts" \
      "$API_SRC/services/orgFinder.ts"
cp -v "$BUNDLE_DIR/new-files/artifacts/api-server/src/services/contactCollector.ts" \
      "$API_SRC/services/contactCollector.ts"

echo
echo "==[ Step 3/6 ]== Patch action_logs.ts (add 3 new action types)"
node "$BUNDLE_DIR/patches/patch-action-types.mjs"

echo
echo "==[ Step 4/6 ]== Patch routes/prospector.ts (add /find-org, /collect-contacts, /discover-simple)"
node "$BUNDLE_DIR/patches/patch-prospector-route.mjs"

echo
echo "==[ Step 5/6 ]== Root typecheck"
pnpm run typecheck

echo
echo "==[ Step 6/6 ]== Build api-server"
pnpm --filter @workspace/api-server run build

echo
echo "==[ Optional: sync to source-code/ mirror ]=="
if [ -f "scripts/sync-source-code.sh" ]; then
  bash scripts/sync-source-code.sh || echo "[apply] sync failed (non-fatal)"
elif [ -f "sync.sh" ]; then
  bash sync.sh || echo "[apply] sync failed (non-fatal)"
elif [ -f "source-code/sync.sh" ]; then
  bash source-code/sync.sh || echo "[apply] sync failed (non-fatal)"
else
  echo "[apply] no sync script found, skipping"
fi

echo
echo "============================================================"
echo "  apply.sh complete."
echo
echo "  ENV CHECK — required for 2.2-BE-B endpoints to function:"
echo "    APOLLO_API_KEY (Replit Secret, both workspace & deploy)"
echo "    ANTHROPIC_API_KEY (already required for 2.2-BE-A)"
echo
echo "  BACKEND BUNDLE — workflow restart REQUIRED:"
echo "    Stop, then Run the api-server workflow in the Replit UI."
echo
echo "  AFTER RESTART, run integration test:"
echo "    cp ticket-2-2-be-b/new-files/tests/integration-2-2-be-b-stage-b.mjs /tmp/"
echo "    node /tmp/integration-2-2-be-b-stage-b.mjs"
echo
echo "  Then walk ticket-2-2-be-b/docs/manual-test-2-2-be-b.md for the"
echo "  real-Apollo discovery probes against known cases."
echo "============================================================"
