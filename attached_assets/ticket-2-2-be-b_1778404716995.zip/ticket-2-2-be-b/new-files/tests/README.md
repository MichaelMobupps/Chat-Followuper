# Tests for Ticket 2.2-BE-B

## integration-2-2-be-b-stage-b.mjs

Hits a deployed api-server end-to-end. Tests the three new endpoints (/find-org, /collect-contacts, /discover-simple) for auth gating, body validation, real Apollo cascade against Probo, action_log shape, and cross-tenant isolation.

### Running

```bash
# From the bundle root, after apply.sh and api-server restart:
cp ticket-2-2-be-b/new-files/tests/integration-2-2-be-b-stage-b.mjs /tmp/
node /tmp/integration-2-2-be-b-stage-b.mjs
```

The script connects to PostgreSQL directly to create test users and inspect action_logs. It mints session cookies using `SESSION_SECRET` (HMAC-SHA256, same envelope as auth.ts).

### Required env

| var | purpose |
|---|---|
| `DATABASE_URL` | PG connection string |
| `SESSION_SECRET` | matches the api-server's SESSION_SECRET |
| `BASE_URL` | optional, default `http://localhost:80` |
| `SKIP_APOLLO_TESTS` | optional, set to `1` to skip happy-path tests (no Apollo cost) |

### Required server state

- api-server running with the new routes mounted
- `APOLLO_API_KEY` set as a Replit Secret on the running workspace
- `ANTHROPIC_API_KEY` already set (for the upstream /resolve-company chain — not exercised by this test, but the action_logs schema patch is shared)

### Cost

- With Apollo tests: ~$0.05-0.20 in Apollo credits per run
- With `SKIP_APOLLO_TESTS=1`: $0

### Cleanup

The script self-cleans: rows with email matching `__t22b_stage_b_%@test.local` are deleted from both `users` and `action_logs` before AND after each run. Failed runs that crash mid-way leave at most a few test rows; rerunning the script wipes them.

### Pass criteria

`[PASS] all N assertions passed` on stdout, exit 0. Any `✗ FAIL` lines indicate a regression.

Expected coverage with Apollo tests enabled: 30+ assertions across 7 test groups.

### Soft-failures

Test [3] (Probo happy path) treats "Apollo doesn't have Probo indexed" as a soft non-fail — the test logs a notice and proceeds. The justification: Apollo's index does occasionally drop or rotate orgs, and a hard fail here would create false flakiness. If Apollo finds Probo in the manual walk but not in the integration test, that's an Apollo flake, not a code bug.

Test [5] (collect-contacts) is also soft on contact count — Apollo may legitimately return 0 contacts for some orgs (small or under-indexed). The test only asserts the response SHAPE.
