# Manual test — Ticket 2.2-BE-B (Apollo cascade)

The integration test verifies auth/validation/cross-tenant + one Probo happy path. This manual walk exercises the **specific cascade strategies** the Python prospector was built to handle: alt-domain enrichment, parent-company upgrades, multi-strategy fallback, micro-org handling, multinational geo-scoping.

Cost: ~$0.50-2.00 in Apollo credits to walk the full doc (each /discover-simple burns 5-100 credits depending on contact count).

## Pre-flight

- [ ] api-server workflow restarted after apply.sh.
- [ ] `APOLLO_API_KEY` set as Replit Secret on workspace AND deploy.
- [ ] `ANTHROPIC_API_KEY` still set (for /resolve-company chain).
- [ ] Integration test passed: `node /tmp/integration-2-2-be-b-stage-b.mjs` → `[PASS]`.
- [ ] Sign in via `/login`, copy `cf_session` cookie.

## Helper

```bash
COOKIE="cf_session=...your.session.cookie..."
RESOLVE() {
  curl -s -X POST "http://localhost:80/api/prospector/resolve-company" \
    -H "Content-Type: application/json" \
    -H "Cookie: $COOKIE" \
    -d "$1" | python3 -m json.tool
}
DISCOVER() {
  curl -s -X POST "http://localhost:80/api/prospector/discover-simple" \
    -H "Content-Type: application/json" \
    -H "Cookie: $COOKIE" \
    -d "$1" | python3 -m json.tool
}
FIND_ORG() {
  curl -s -X POST "http://localhost:80/api/prospector/find-org" \
    -H "Content-Type: application/json" \
    -H "Cookie: $COOKIE" \
    -d "$1" | python3 -m json.tool
}
COLLECT() {
  curl -s -X POST "http://localhost:80/api/prospector/collect-contacts" \
    -H "Content-Type: application/json" \
    -H "Cookie: $COOKIE" \
    -d "$1" | python3 -m json.tool
}
```

## Case 1: Probo (sanity, full pipeline)

```bash
# Step 1: resolve
RESOLVE '{"brand":"Probo","appName":"Probo: Trade Anything With Opinions","domain":"probo.in","country":"IN","sourceType":"play_store"}'
# Step 2: take the .resolved object from above and pipe to discover-simple
DISCOVER '{"resolved":{ ...output of step 1.resolved... }}'
```

Expected:
- [ ] `org.name` mentions Probo
- [ ] `strategy` is `domain_enrich` (probo.in → exact match)
- [ ] `upgradedToParent` is false (no parent)
- [ ] `contacts` array has ≥1 entry (Probo has marketing/growth people in Apollo)
- [ ] `phasesRun` includes "primary" or "secondary"

## Case 2: Cash App → Block (corporate-domain ≠ developer-domain)

```bash
RESOLVE '{"brand":"Cash App","appName":"Cash App","domain":"cash.app","country":"US","sourceType":"app_store"}'
# Use resolved output → discover-simple
```

Expected:
- [ ] `org.name` is "Block" or "Block, Inc." (NOT Cash App)
- [ ] `strategy` is `domain_enrich` on block.xyz, OR `name_validated` if alt-domain enrich needed
- [ ] `org.estimatedNumEmployees` > 1000 (Block is large)
- [ ] `contacts` has marketing/growth contacts at @block.xyz or @squareup.com
- [ ] `attempts` shows the cascade chose corporate domain over cash.app

## Case 3: Astrum Entertainment + VK parent upgrade

```bash
RESOLVE '{"brand":"Astrum Entertainment","appName":"Мир домовят","domain":"astrumgames.com","country":"RU","sourceType":"play_store"}'
# Use resolved → discover-simple
```

Expected:
- [ ] `strategy` succeeds on `domain_enrich` or `name_validated` for Astrum
- [ ] `upgradedToParent: true` (VK has more employees in Apollo than Astrum sub)
- [ ] If upgradedToParent is true, `org.name` is "VK" or "VK Group"
- [ ] If upgradedToParent is false, document why — Apollo's VK org may not be larger by employees

## Case 4: Emma fintech (alt-domain mismatch guard test)

```bash
# Test the alt-domain mismatch guard: a malicious or wrong altDomain shouldn't pull in Emma Sleep
FIND_ORG '{
  "resolved": {
    "companyName": "Emma",
    "parentCompany": "",
    "corporateDomain": "emma-app.com",
    "alternativeDomains": ["emma.com"],
    "searchQueries": ["Emma","Emma App","Emma Finance"],
    "isMultinational": false,
    "focusMarket": "",
    "primaryMarket": "United Kingdom",
    "reasoning": "Test"
  }
}'
```

Expected:
- [ ] `attempts` shows alt_domain_enrich on emma.com → outcome=`rejected_name_mismatch` (Emma Sleep got blocked because of "sleep"/"mattress" signal)
- [ ] Final org is either Emma fintech (if found via emma-app.com domain) or `null` if Apollo doesn't have the fintech indexed
- [ ] If org is null with mismatch in attempts, that's the GUARD WORKING — Emma Sleep was correctly rejected

## Case 5: SMBC subsidiary → group parent

```bash
RESOLVE '{"brand":"SMBC","appName":"Promise Mobile","domain":"promise.co.jp","country":"JP","description":"Personal loan service from Promise, an SMBC Consumer Finance company."}'
# Use resolved → discover-simple
```

Expected:
- [ ] `strategy` finds either Promise / SMBC Consumer Finance or directly upgrades to SMBC Group
- [ ] `upgradedToParent: true` likely (SMBC Group has 10K+ employees vs Promise sub)
- [ ] Contacts at @smbc.co.jp or @smbc-group.com
- [ ] `phasesRun` may include "broad" since Japanese title patterns differ

## Case 6: Casualino (micro-org fallback)

```bash
RESOLVE '{"brand":null,"appName":null,"domain":"casualino.com","country":null,"sourceType":"website"}'
# Use resolved → discover-simple with target 2 (since micro-org)
DISCOVER '{"resolved":{...}, "targetContacts":2}'
```

Expected:
- [ ] `org.estimatedNumEmployees` < 150 (Casualino is small)
- [ ] If primary/secondary/exec phases return 0 contacts, `phasesRun` includes "broad_micro"
- [ ] `contacts` may include CEO / founder / senior generalists (the micro-org permissive fallback)
- [ ] Or `contacts` is empty — Apollo may not have detailed coverage of small studios

## Case 7: Grupo Dia (multinational geo-scoping)

```bash
RESOLVE '{"brand":"Grupo Dia","appName":"Club Dia España","domain":"dia.es","country":"ES","description":"Loyalty program for Dia supermarkets in Spain."}'
# Use resolved (with isMultinational=true) → discover-simple
```

Expected:
- [ ] `org` is Grupo Dia or Dia España
- [ ] `isMultinational: true` in your input → people-search should geo-scope to Spain
- [ ] Contacts have @dia.es / @diacorporate.com domain
- [ ] Most contacts have addresses indicating Spain (verify in `attempts` log if needed)

## Case 8: Per-stage debugging (find-org + collect-contacts independent)

For when /discover-simple returns no contacts and you want to see exactly where it broke:

```bash
# Stage 1: find org separately
FIND_ORG '{"resolved":{...probo resolved...}}'
# inspect the result, copy the .org

# Stage 2: collect contacts with the found org, optionally tweaking targetContacts
COLLECT '{"org":{...from stage 1...}, "resolved":{...}, "targetContacts":10}'
```

Expected:
- [ ] /find-org returns same org as /discover-simple does
- [ ] /collect-contacts returns same contacts (within randomness)
- [ ] `phasesRun` and `rejected` counts let you diagnose: "0 phases ran" → org.id missing; "domainMismatch high" → wrong domain in resolved

## Case 9: Rate limit behavior

Hit /find-org rapidly to verify the per-user rate limit (60/min) returns 429:

```bash
for i in $(seq 1 70); do
  curl -s -o /dev/null -w "%{http_code} " -X POST \
    "http://localhost:80/api/prospector/find-org" \
    -H "Content-Type: application/json" -H "Cookie: $COOKIE" \
    -d '{"resolved":{"companyName":"Rate Limit Test","parentCompany":"","corporateDomain":"","alternativeDomains":[],"searchQueries":[],"isMultinational":false,"focusMarket":"","primaryMarket":"","reasoning":""}}'
done; echo
```

Expected:
- [ ] First ~60 requests return 200 (or 502 if Apollo can't find the bogus org — that's fine)
- [ ] Next requests return 429
- [ ] Each 429 has `Retry-After` header
- [ ] `action_logs` shows blocked rows with `error_class: rate_limit`

## Case 10: Apollo credentials missing (negative test)

This is destructive — only do it if you can quickly toggle `APOLLO_API_KEY` back. Or use a separate dev workspace.

- [ ] Temporarily unset `APOLLO_API_KEY` in workspace secrets
- [ ] Restart api-server
- [ ] Hit /find-org → expect 503 with `error: "apollo_not_configured"`
- [ ] Restore APOLLO_API_KEY immediately

## Pass criteria summary

| Case | What's tested | Pass condition |
|------|---|---|
| 1 | Sanity (Probo) | org found, contacts collected, strategy=domain_enrich |
| 2 | Corporate ≠ dev domain | Block found, not Cash App |
| 3 | Parent upgrade | upgradedToParent=true, VK selected |
| 4 | Alt-domain guard | Emma Sleep rejected via name-mismatch signal |
| 5 | Subsidiary → parent | SMBC Group selected over Promise |
| 6 | Micro-org fallback | broad_micro phase runs when others empty |
| 7 | Multinational geo | Spain location filter applied |
| 8 | Per-stage debug | /find-org and /collect-contacts work independently |
| 9 | Rate limit | 429 after 60 calls/min, blocked logs written |
| 10 | Apollo missing | 503 apollo_not_configured |

## Action log inspection

After the walk, review the new action types:

```bash
psql "$DATABASE_URL" -c \
  "SELECT
     action_type,
     metadata->>'company_name' AS company,
     metadata->>'strategy' AS strategy,
     metadata->>'upgraded_to_parent' AS upgrade,
     metadata->>'org_name' AS org,
     metadata->>'contacts_returned' AS contacts,
     action_status,
     duration_ms
   FROM action_logs
   WHERE action_type IN (
     'prospector.org_found',
     'prospector.contacts_collected',
     'prospector.discover_simple'
   )
   ORDER BY executed_at DESC LIMIT 20;"
```

## If anything fails

Paste:
1. Case number
2. The full request body
3. The full response body (includes `attempts` for /find-org which shows what was tried)
4. The matching action log row

For org-find issues, the `attempts` field in the response is the diagnostic — it shows every strategy and its outcome.
