# Ticket 2.2-BE-C — Production /discover endpoint

## Summary

Production-grade discovery chain for the Email-Folllowuper monorepo. Layers above 2.2-BE-A (resolveCompany) and 2.2-BE-B (findOrg + collectContacts):

1. **resolveCompany** (Sonnet) → company_info
2. **findOrg strict** (2.2-BE-B) → if hit, proceed
3. **findOrg smart** (relaxed name search + LLM-validated candidate pick) → if hit, proceed
4. **opusRescue** (Opus + web_search) → 2-5 refined strategies, each retried via findOrg
5. **collectContacts** (2.2-BE-B) → contacts up to target
6. **subsidiary expansion** (Phase 3) when contacts < target → cross-org search through holding companies (SMBC Group → SMBC Nikko + SMBC Consumer Finance, etc.)

Plus production wiring: AbortSignal threading (closes 2.2-BE-B residual F-NEW-A at orchestrator-level call sites), per-request Apollo budget cap, full audit trail, action_log persistence.

## What changed

### New service files (4)
- `artifacts/api-server/src/services/llmValidator.ts` (298 lines) — port of `llm_validate_org_candidates`
- `artifacts/api-server/src/services/opusRescue.ts` (553 lines) — port of `rescue_with_opus` with web_search tool
- `artifacts/api-server/src/services/subsidiaryExpander.ts` (337 lines) — port of Phase 3 (NOT wired into orchestrator's main path; see notes)
- `artifacts/api-server/src/services/discoveryOrchestrator.ts` (852 lines) — full chain

### Patches (3)
- `patches/patch-apollo-abort.mjs` — adds `signal?: AbortSignal` to `ApolloPostOptions`, threads through `withTimeout` + fetch + retry-loop abort check
- `patches/patch-action-types.mjs` — adds `prospectorDiscover: "prospector.discover"`
- `patches/patch-prospector-route.mjs` — adds POST `/api/prospector/discover` route

### Tests + docs
- `tests/integration-2-2-be-c-discover.mjs` — 30+ assertions: auth, validation, rate limit, live discover, action_log, cross-tenant
- `docs/manual-test-2-2-be-c.md` — 8 real-Apollo cases (Probo, Casualino, Astrum, SMBC, budget, timeout, action_log)

## Apply

Run from monorepo root with this bundle in any temp folder:

```bash
bash apply.sh
```

After: **Stop+Run the api-server workflow** (build is included in apply.sh; the Replit Agent restart picks up the new bundle).

## Verify

```bash
# Health
curl -s http://localhost:5000/api/healthz | jq .   # → {"status":"ok"}

# Auth gate
curl -s -X POST http://localhost:5000/api/prospector/discover -d '{}'   # → 401

# Live discover
ADDON_API_KEY=$ADDON_API_KEY node tests/integration-2-2-be-c-discover.mjs
```

## Architecture notes

### LLM call points (3 distinct callers, separate cost lines)

| Caller | Model | Tools | Use |
| --- | --- | --- | --- |
| `companyResolver.defaultLLMCaller` | Sonnet | none | resolveCompany |
| `llmValidator.validateOrgCandidates` (uses Sonnet caller) | Sonnet | none | smart cascade candidate pick |
| `opusRescue.defaultOpusRescueLLMCaller` | Opus | `web_search_20250305` | Opus rescue |

The Opus caller uses the raw Anthropic SDK (not the LLMCaller interface) because it needs the `tools` parameter, which the LLMCaller signature doesn't currently expose. Both are testable via injection.

### AbortSignal threading

- **Closed** at 2.2-BE-C scope: orchestrator's own `apolloPost` calls (smart cascade + Phase 3) check `signal.aborted` between calls and pass `signal` into `apolloPost`. The retry loop inside `apolloPost` also bails immediately on aborted signal.
- **Partial residual (F-NEW-A)**: `findOrg` and `collectContacts` from 2.2-BE-B do not yet accept a signal parameter; their internal `apolloPost` calls run without the signal. Each apolloPost has a 30s internal timeout, so worst-case overrun past the outer `/discover` 300s timeout is bounded at ~30s. **Closing this fully is 2.2-BE-D scope.**

### Apollo call budget

Per-request, in-memory counter capped at `apolloCallBudget` (default 80, max 200 per Zod). Bumps are **approximate**: the orchestrator can't introspect inside `findOrg` / `collectContacts`, so it bumps by conservative estimates (`FIND_ORG_CALL_ESTIMATE = 5`, `COLLECT_CONTACTS_CALL_ESTIMATE = 20`). Real per-call counts are bounded by zod limits in those services.

The budget is a **stop-loss**, not a precision meter. Per-request scope means concurrent `/discover` requests don't share state. Apollo-level rate limits (handled inside `apolloProspector`) provide the global safety net.

### Subsidiary expansion: simplified inline path

`subsidiaryExpander.ts` is a complete port of the Python Phase 3 logic, BUT the orchestrator does not currently call `expandToSubsidiaries`. Instead it implements a simplified Phase 3 inline (Strategy A name-variant search → call `collectContacts` on each subsidiary org).

**Why**: the full `expandToSubsidiaries` requires the orchestrator to inject `processPeople` and `apolloPeopleSearch` from `contactCollector`, which 2.2-BE-B doesn't currently export. Wiring those exports is a 2.2-BE-D refactor.

The simplified inline path achieves Phase 3's goal (collect contacts across subsidiaries) at higher Apollo cost (~10 calls per subsidiary vs ~4 in full Phase 3). For typical holding-company prospects this is a 30-50 call overhead — within the 80-call default budget.

`subsidiaryExpander.ts` ships in this bundle (with `void`-suppressed unused imports in the orchestrator) so 2.2-BE-D can wire it in without re-shipping the file.

### Rate limit bucket sharing

`/discover` and `/discover-simple` share the `"discover_simple"` rate-limit bucket (12/min/user). This is **intentional**: the two routes serve the same purpose, only differing in which cascade depth they run. A user shouldn't be able to bypass the rate limit by alternating between them. If splitting becomes important (e.g. `/discover-simple` for free tier, `/discover` for paid), it's a one-line change.

### Action_log metadata schema

Every `/discover` response writes one `action_logs` row with `action_type = "prospector.discover"` and metadata:

```jsonc
{
  "brand": "Probo",
  "app_name": "Probo: Opinion Trading App",
  "status": "success",                  // success | no_org_found | no_contacts_found | budget_exhausted | aborted
  "resolution": "strict_cascade",       // strict_cascade | smart_llm_validated | opus_rescue | no_org
  "strict_strategy": "domain_enrich",   // domain_enrich | name_search | name_search_with_domain_validation | parent_direct | none
  "upgraded_to_parent": false,
  "smart_search_ran": false,
  "smart_match_confidence": null,       // high | medium | low | null
  "opus_rescue_ran": false,
  "opus_strategies_attempted": null,
  "opus_strategy_succeeded": null,
  "opus_web_search_used": null,
  "subsidiary_expansion_ran": false,
  "subsidiaries_found": 0,
  "apollo_calls_consumed": 12,
  "budget_exhausted": false,
  "aborted": false,
  "org_found": true,
  "org_name": "Probo",
  "org_employees": 200,
  "contacts_returned": 1,
  "llm_input_tokens": 4231,             // sum across resolveCompany + smart + opus
  "llm_output_tokens": 312
}
```

## Known residuals (audit-acknowledged)

| ID | Description | Bound | Resolution |
| --- | --- | --- | --- |
| F-NEW-A | findOrg/collectContacts don't thread signal through to inner apolloPost | ≤30s overrun past outer timeout | 2.2-BE-D ticket |
| F-2.2-C-1 | `subsidiaryExpander` not wired (orchestrator runs simplified inline) | ~30-50 extra Apollo calls per holding-company case | 2.2-BE-D refactor (export processPeople from contactCollector) |
| F-2.2-C-2 | `legalName` cast hack (`resolved as { legalName?: string }`) | none — runtime safe | 2.2-BE-A v2 to add legalName field on ResolvedCompany |
| F-2.2-C-3 | Apollo budget per-request, not per-process | concurrent /discover requests don't share | acceptable; per-Apollo-key rate limit is the global stop |
| F-2.2-C-4 | Per-strategy "without domain constraint" relax (Python lines 1467-1474) not ported | Strategy 5 (parent_direct) inside findOrg cascade already covers domainless name search | acceptable |
| F-2.2-C-5 | Apollo budget bumps are approximate (fixed estimates per service call) | budget is coarse stop-loss, not precise meter | acceptable; documented |
| F-2.2-C-6 | `/discover` and `/discover-simple` share rate bucket | intentional; prevents bypass | acceptable; documented |

## Verified pre-ship

```
✓ All 9 service files: brace-balanced (apolloProspector 93/93, orgFinder 100/100, contactCollector 99/99, companyResolver 94/94, urlResolver 52/52, llmValidator 56/56, opusRescue 75/75, subsidiaryExpander 33/33, discoveryOrchestrator 99/99)
✓ Patched prospector.ts: 213/213 braces (1314 lines)
✓ TS strict compile: exit 0 across all services
✓ Patch chain BE-2 → 2.1-BE → 2.2-BE-A → 2.2-BE-B → 2.2-BE-C: applies clean
✓ Idempotency on second apply: all SKIP/NOOP, evidence checks pass
✓ Routes after chain: 6 endpoints (resolve-urls + resolve-company + find-org + collect-contacts + discover-simple + discover)
✓ ACTION_TYPES after chain: 6 prospector.* keys (resolveUrls + resolveCompany + orgFound + contactsCollected + discoverSimple + discover)
```

## File manifest

```
ticket-2-2-be-c/
├── apply.sh                                              # bundle install
├── README.md                                             # this file
├── docs/
│   └── manual-test-2-2-be-c.md                          # 8 real-Apollo cases
├── new-files/
│   └── artifacts/api-server/src/services/
│       ├── llmValidator.ts          (298 lines, 56/56)
│       ├── opusRescue.ts            (553 lines, 75/75)
│       ├── subsidiaryExpander.ts    (337 lines, 33/33)
│       └── discoveryOrchestrator.ts (852 lines, 99/99)
├── patches/
│   ├── patch-apollo-abort.mjs       # AbortSignal threading
│   ├── patch-action-types.mjs       # +prospectorDiscover
│   └── patch-prospector-route.mjs   # +POST /discover
└── tests/
    └── integration-2-2-be-c-discover.mjs                # 30+ assertions
```
