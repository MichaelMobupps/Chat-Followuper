#!/usr/bin/env node
/**
 * Anchored, idempotent patch for lib/db/src/schema/action_logs.ts.
 * Adds one new ACTION_TYPES key for 2.2-BE-C:
 *   - prospectorDiscover: "prospector.discover"
 *
 * Anchored on prospectorDiscoverSimple from 2.2-BE-B.
 */
import fs from "node:fs";

const PATH = "lib/db/src/schema/action_logs.ts";

let src = fs.readFileSync(PATH, "utf8");
const before = src;
const log = (m) => console.log(`[patch-action-types] ${m}`);

const anchor = '  prospectorDiscoverSimple: "prospector.discover_simple",';
const insert =
  '  prospectorDiscoverSimple: "prospector.discover_simple",\n' +
  '  prospectorDiscover: "prospector.discover",';

const presenceMarker = 'prospectorDiscover: "prospector.discover"';

if (src.includes(presenceMarker)) {
  log("[SKIP] prospectorDiscover already present");
} else if (!src.includes(anchor)) {
  console.error(`[patch-action-types] [FAIL] anchor not found.`);
  console.error("       Apply 2.2-BE-B first if not done.");
  process.exit(2);
} else {
  src = src.replace(anchor, insert);
  log("[APPLY] added prospectorDiscover");
}

if (src === before) {
  log("[NOOP] no changes");
} else {
  fs.writeFileSync(PATH, src);
  log("[DONE] action_logs.ts updated");
}

const finalSrc = fs.readFileSync(PATH, "utf8");
const evidence = {
  prospectorDiscover: (
    finalSrc.match(/prospectorDiscover: "prospector\.discover"/g) || []
  ).length,
  prospectorDiscoverSimple_still_present: (
    finalSrc.match(/prospectorDiscoverSimple: "prospector\.discover_simple"/g) || []
  ).length,
};
console.log("[patch-action-types] evidence:", JSON.stringify(evidence));
const expected = {
  prospectorDiscover: 1,
  prospectorDiscoverSimple_still_present: 1,
};
for (const [k, v] of Object.entries(expected)) {
  if (evidence[k] !== v) {
    console.error(`[patch-action-types] [FAIL] evidence ${k}: got ${evidence[k]}, expected ${v}`);
    process.exit(3);
  }
}
console.log("[patch-action-types] all evidence checks passed");
