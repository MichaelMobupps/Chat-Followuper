#!/usr/bin/env node
/**
 * Anchored, idempotent patch for artifacts/api-server/src/services/apolloProspector.ts.
 *
 * Adds optional `signal?: AbortSignal` to ApolloPostOptions and threads it into
 * the fetch call via AbortSignal.any with the internal per-call timeout signal.
 *
 * This closes 2.2-BE-B's residual finding F-NEW-A: when the outer /discover
 * timeout fires, all in-flight Apollo calls receive the abort signal and exit
 * promptly rather than continuing to burn credits in the background.
 *
 * Backward compatible — `signal` is optional. Existing callers (orgFinder,
 * contactCollector) work unchanged until they're updated to pass it through.
 *
 * Anchored on the ApolloPostOptions interface block.
 */
import fs from "node:fs";

const PATH = "artifacts/api-server/src/services/apolloProspector.ts";

let src = fs.readFileSync(PATH, "utf8");
const before = src;
const log = (m) => console.log(`[patch-apollo-abort] ${m}`);

// ─── Patch 1: extend ApolloPostOptions ─────────────────────────────────────

const optsAnchor =
  'export interface ApolloPostOptions {\n' +
  '  /** Path under APOLLO_BASE_URL, e.g. "/organizations/enrich" (leading slash). */\n' +
  '  path: string;\n' +
  '  /** JSON body. Sanitized for control chars before send. */\n' +
  '  body?: Record<string, unknown>;\n' +
  '  /** URL query params. Stringified via URLSearchParams. Arrays repeat the key\n' +
  '   *  with [] suffix per Apollo\'s documented array-param convention. */\n' +
  '  query?: Record<string, string | number | boolean | string[] | undefined | null>;\n' +
  '}';

const optsInsert =
  'export interface ApolloPostOptions {\n' +
  '  /** Path under APOLLO_BASE_URL, e.g. "/organizations/enrich" (leading slash). */\n' +
  '  path: string;\n' +
  '  /** JSON body. Sanitized for control chars before send. */\n' +
  '  body?: Record<string, unknown>;\n' +
  '  /** URL query params. Stringified via URLSearchParams. Arrays repeat the key\n' +
  '   *  with [] suffix per Apollo\'s documented array-param convention. */\n' +
  '  query?: Record<string, string | number | boolean | string[] | undefined | null>;\n' +
  '  /** Optional external AbortSignal. When provided, fetch is aborted as soon\n' +
  '   *  as either this signal or the internal 30s per-call timeout fires.\n' +
  '   *  Used by /discover to halt in-flight Apollo work when its outer 300s\n' +
  '   *  timeout fires (closes 2.2-BE-B residual finding F-NEW-A). */\n' +
  '  signal?: AbortSignal;\n' +
  '}';

if (src.includes('signal?: AbortSignal;')) {
  log("[SKIP] AbortSignal already present in ApolloPostOptions");
} else if (!src.includes(optsAnchor)) {
  console.error(`[patch-apollo-abort] [FAIL] anchor not found for ApolloPostOptions block.`);
  console.error("       Apply 2.2-BE-B first if not done.");
  process.exit(2);
} else {
  src = src.replace(optsAnchor, optsInsert);
  log("[APPLY] added signal?: AbortSignal to ApolloPostOptions");
}

// ─── Patch 2: thread signal through withTimeout helper ─────────────────────
//
// Current withTimeout creates its own controller. We add a helper variant
// that accepts an external signal and aborts on whichever fires first.

const withTimeoutAnchor =
  'async function withTimeout<T>(\n' +
  '  fn: (signal: AbortSignal) => Promise<T>,\n' +
  '  ms: number,\n' +
  '  label: string,\n' +
  '): Promise<T> {\n' +
  '  const ctrl = new AbortController();\n' +
  '  const timer = setTimeout(() => ctrl.abort(), ms);\n' +
  '  try {\n' +
  '    return await fn(ctrl.signal);\n' +
  '  } catch (err) {\n' +
  '    if (ctrl.signal.aborted) {\n' +
  '      throw new Error(`${label} aborted after ${ms}ms`);\n' +
  '    }\n' +
  '    throw err;\n' +
  '  } finally {\n' +
  '    clearTimeout(timer);\n' +
  '  }\n' +
  '}';

const withTimeoutInsert =
  'async function withTimeout<T>(\n' +
  '  fn: (signal: AbortSignal) => Promise<T>,\n' +
  '  ms: number,\n' +
  '  label: string,\n' +
  '  externalSignal?: AbortSignal,\n' +
  '): Promise<T> {\n' +
  '  const ctrl = new AbortController();\n' +
  '  const timer = setTimeout(() => ctrl.abort(), ms);\n' +
  '\n' +
  '  // F-NEW-A: forward external aborts. AbortSignal.any may not be available\n' +
  '  // on older Node runtimes; we wire it manually for portability.\n' +
  '  const onExternalAbort = () => ctrl.abort();\n' +
  '  if (externalSignal) {\n' +
  '    if (externalSignal.aborted) {\n' +
  '      ctrl.abort();\n' +
  '    } else {\n' +
  '      externalSignal.addEventListener("abort", onExternalAbort, { once: true });\n' +
  '    }\n' +
  '  }\n' +
  '\n' +
  '  try {\n' +
  '    return await fn(ctrl.signal);\n' +
  '  } catch (err) {\n' +
  '    if (ctrl.signal.aborted) {\n' +
  '      const reason = externalSignal?.aborted\n' +
  '        ? `${label} aborted by caller`\n' +
  '        : `${label} aborted after ${ms}ms`;\n' +
  '      throw new Error(reason);\n' +
  '    }\n' +
  '    throw err;\n' +
  '  } finally {\n' +
  '    clearTimeout(timer);\n' +
  '    if (externalSignal) {\n' +
  '      externalSignal.removeEventListener("abort", onExternalAbort);\n' +
  '    }\n' +
  '  }\n' +
  '}';

if (src.includes('externalSignal?: AbortSignal,')) {
  log("[SKIP] externalSignal already threaded into withTimeout");
} else if (!src.includes(withTimeoutAnchor)) {
  console.error(`[patch-apollo-abort] [FAIL] anchor not found for withTimeout helper.`);
  process.exit(2);
} else {
  src = src.replace(withTimeoutAnchor, withTimeoutInsert);
  log("[APPLY] threaded externalSignal through withTimeout");
}

// ─── Patch 3: pass opts.signal into the withTimeout call ──────────────────

const fetchCallAnchor =
  '      resp = await withTimeout(\n' +
  '        (signal) =>\n' +
  '          fetch(url.toString(), {\n' +
  '            method: "POST",\n' +
  '            headers,\n' +
  '            body: bodyJson,\n' +
  '            signal,\n' +
  '            // Audit fix B3.1: never follow redirects. A DNS hijack or Apollo\n' +
  '            // bug that 3xx-redirects to attacker.example would otherwise\n' +
  '            // forward our X-Api-Key header to the redirect target.\n' +
  '            redirect: "error",\n' +
  '          }),\n' +
  '        APOLLO_REQUEST_TIMEOUT_MS,\n' +
  '        `Apollo POST ${path}`,\n' +
  '      );';

const fetchCallInsert =
  '      resp = await withTimeout(\n' +
  '        (signal) =>\n' +
  '          fetch(url.toString(), {\n' +
  '            method: "POST",\n' +
  '            headers,\n' +
  '            body: bodyJson,\n' +
  '            signal,\n' +
  '            // Audit fix B3.1: never follow redirects. A DNS hijack or Apollo\n' +
  '            // bug that 3xx-redirects to attacker.example would otherwise\n' +
  '            // forward our X-Api-Key header to the redirect target.\n' +
  '            redirect: "error",\n' +
  '          }),\n' +
  '        APOLLO_REQUEST_TIMEOUT_MS,\n' +
  '        `Apollo POST ${path}`,\n' +
  '        opts.signal,\n' +
  '      );';

if (src.includes('`Apollo POST ${path}`,\n        opts.signal,\n      );')) {
  log("[SKIP] opts.signal already passed to withTimeout");
} else if (!src.includes(fetchCallAnchor)) {
  console.error(`[patch-apollo-abort] [FAIL] anchor not found for fetch withTimeout call site.`);
  process.exit(2);
} else {
  src = src.replace(fetchCallAnchor, fetchCallInsert);
  log("[APPLY] passed opts.signal into withTimeout call site");
}

// ─── Patch 4: bail early on aborted signal in retry loop ──────────────────
//
// If the external signal aborts during a sleep (429 backoff or 5xx backoff),
// the next loop iteration must surface that immediately rather than make
// another Apollo call. Insert a check at the top of each loop iteration.

const loopTopAnchor =
  '  while (attempt < APOLLO_5XX_MAX_ATTEMPTS) {\n' +
  '    attempt++;\n' +
  '    await _enforceGap();';

const loopTopInsert =
  '  while (attempt < APOLLO_5XX_MAX_ATTEMPTS) {\n' +
  '    // F-NEW-A: bail immediately if caller has aborted, before consuming a\n' +
  '    // gap-mutex slot or making the next Apollo call.\n' +
  '    if (opts.signal?.aborted) {\n' +
  '      throw new Error(`Apollo POST ${path} aborted by caller`);\n' +
  '    }\n' +
  '    attempt++;\n' +
  '    await _enforceGap();';

if (src.includes('// F-NEW-A: bail immediately if caller has aborted')) {
  log("[SKIP] abort check already present in retry loop");
} else if (!src.includes(loopTopAnchor)) {
  console.error(`[patch-apollo-abort] [FAIL] anchor not found for retry loop top.`);
  process.exit(2);
} else {
  src = src.replace(loopTopAnchor, loopTopInsert);
  log("[APPLY] added abort check at top of retry loop");
}

if (src === before) {
  log("[NOOP] no changes");
} else {
  fs.writeFileSync(PATH, src);
  log("[DONE] apolloProspector.ts updated");
}

const finalSrc = fs.readFileSync(PATH, "utf8");
const evidence = {
  signal_in_options: (finalSrc.match(/signal\?: AbortSignal;/g) || []).length,
  externalSignal_param: (finalSrc.match(/externalSignal\?: AbortSignal,/g) || []).length,
  opts_signal_passed: (finalSrc.match(/opts\.signal,/g) || []).length,
  abort_check_in_loop: (finalSrc.match(/F-NEW-A: bail immediately/g) || []).length,
};
console.log("[patch-apollo-abort] evidence:", JSON.stringify(evidence));
const expected = {
  signal_in_options: 1,
  externalSignal_param: 1,
  opts_signal_passed: 1,
  abort_check_in_loop: 1,
};
for (const [k, v] of Object.entries(expected)) {
  if (evidence[k] !== v) {
    console.error(`[patch-apollo-abort] [FAIL] evidence ${k}: got ${evidence[k]}, expected ${v}`);
    process.exit(3);
  }
}
console.log("[patch-apollo-abort] all evidence checks passed");
