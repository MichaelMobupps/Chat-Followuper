#!/usr/bin/env node
/**
 * Anchored, idempotent patch for artifacts/api-server/src/routes/prospector.ts.
 * Adds the production /discover endpoint for Ticket 2.2-BE-C.
 *
 *   POST /api/prospector/discover
 *
 * Wraps the discoveryOrchestrator with auth, rate limiting, body validation,
 * outer-timeout, action_log persistence, and HTTP error mapping.
 *
 * Reuses 2.2-BE-A's redactSecrets + sanitizeForStorage and 2.2-BE-B's
 * redactApolloKey + withStageBTimeout — no new helpers.
 */
import fs from "node:fs";

const PATH = "artifacts/api-server/src/routes/prospector.ts";

let src = fs.readFileSync(PATH, "utf8");
const before = src;
const log = (m) => console.log(`[patch-prospector-route] ${m}`);

// ─── Patch 1: import line ─────────────────────────────────────────────────
//
// 2.2-BE-B's import block ends with:
//   import type { ResolvedCompany } from "../services/companyResolver";
// We append the discoveryOrchestrator import after it.

const importAnchor = 'import type { ResolvedCompany } from "../services/companyResolver";';

const importInsert =
  importAnchor +
  '\n' +
  'import {\n' +
  '  discover,\n' +
  '  type DiscoveryInput,\n' +
  '  type DiscoveryResult,\n' +
  '} from "../services/discoveryOrchestrator";';

if (src.includes('from "../services/discoveryOrchestrator"')) {
  log("[SKIP] discoveryOrchestrator import already present");
} else if (!src.includes(importAnchor)) {
  console.error(`[patch-prospector-route] [FAIL] import anchor not found.`);
  console.error("       Apply 2.2-BE-B first if not done.");
  process.exit(2);
} else {
  src = src.replace(importAnchor, importInsert);
  log("[APPLY] added discoveryOrchestrator import");
}

// ─── Patch 2: route block before export ───────────────────────────────────

const ROUTE_BLOCK = `// ─── Ticket 2.2-BE-C: /discover (production endpoint) ───────────────────────
//
// Production discovery chain. Wraps discoveryOrchestrator.discover() with auth,
// rate limit, body validation, outer 300s timeout, action_log persistence.
//
// Differs from /discover-simple (2.2-BE-B):
//   - Adds smart cascade (LLM-validated relaxed name search) when strict cascade fails
//   - Adds Opus rescue with web_search when smart cascade fails
//   - Adds Phase 3 subsidiary expansion when contacts < target
//   - Threads AbortSignal through every Apollo call (closes 2.2-BE-B residual F-NEW-A)
//   - Returns rich audit trail showing which step succeeded and why

const DISCOVER_TIMEOUT_MS = 300_000;
const DISCOVER_RATE_MAX = 12; // per user per minute — heavier than discover-simple due to Opus + Phase 3 cost

const discoverBodySchema = z
  .object({
    brand: z.string().trim().max(500).nullable().optional(),
    appName: z.string().trim().max(500).nullable().optional(),
    domain: z.string().trim().max(500).nullable().optional(),
    country: z.string().trim().max(200).nullable().optional(),
    description: z.string().trim().max(2000).nullable().optional(),
    developerEmail: z.string().trim().max(500).nullable().optional(),
    legalName: z.string().trim().max(500).nullable().optional(),
    storeUrl: z.string().trim().max(1000).nullable().optional(),
    storeCategory: z.string().trim().max(200).nullable().optional(),
    sourceType: z.enum(["play_store", "app_store", "website"]).nullable().optional(),
    targetContacts: z.number().int().min(1).max(50).optional(),
    skipSubsidiaryExpansion: z.boolean().optional(),
    skipOpusRescue: z.boolean().optional(),
    disableWebSearchInRescue: z.boolean().optional(),
    apolloCallBudget: z.number().int().min(10).max(200).optional(),
  })
  .strict();

router.post(
  "/prospector/discover",
  requireAuth,
  async (req: Request, res: Response): Promise<void> => {
    const user = req.user!;
    const start = Date.now();

    const rl = checkStageBRateLimit("discover_simple", user.id, DISCOVER_RATE_MAX);
    if (!rl.ok) {
      const retryAfterSec = Math.ceil(rl.resetMs / 1000);
      try {
        await db.insert(actionLogsTable).values({
          userId: user.id,
          actionType: ACTION_TYPES.prospectorDiscover,
          actionStatus: "blocked",
          durationMs: Date.now() - start,
          metadata: {
            error_class: "rate_limit",
            limit_per_window: DISCOVER_RATE_MAX,
            window_seconds: STAGE_B_RATE_WINDOW_MS / 1000,
            retry_after_seconds: retryAfterSec,
          },
        });
      } catch {}
      res.setHeader("Retry-After", String(retryAfterSec));
      res.status(429).json({
        error: "rate_limit_exceeded",
        message: \`Too many /discover calls. Limit \${DISCOVER_RATE_MAX}/min. Retry in \${retryAfterSec}s.\`,
        retryAfterSeconds: retryAfterSec,
      });
      return;
    }

    let body: z.infer<typeof discoverBodySchema>;
    try {
      body = discoverBodySchema.parse(req.body);
    } catch (err) {
      if (err instanceof ZodError) {
        const mapped = zodErrorToHttp(err);
        res.status(mapped.status).json(mapped.body);
        return;
      }
      throw err;
    }

    // External AbortController so the orchestrator can be told to stop when
    // the outer timeout fires. discoveryOrchestrator threads this signal
    // through every Apollo call.
    const ctrl = new AbortController();

    const discoveryInput: DiscoveryInput = {
      brand: body.brand ?? undefined,
      appName: body.appName ?? undefined,
      domain: body.domain ?? undefined,
      country: body.country ?? undefined,
      description: body.description ?? undefined,
      developerEmail: body.developerEmail ?? undefined,
      legalName: body.legalName ?? undefined,
      storeUrl: body.storeUrl ?? undefined,
      storeCategory: body.storeCategory ?? undefined,
      sourceType: body.sourceType ?? undefined,
      targetContacts: body.targetContacts,
      skipSubsidiaryExpansion: body.skipSubsidiaryExpansion,
      skipOpusRescue: body.skipOpusRescue,
      disableWebSearchInRescue: body.disableWebSearchInRescue,
      apolloCallBudget: body.apolloCallBudget,
      signal: ctrl.signal,
    };

    let result: DiscoveryResult;
    try {
      const work = discover(discoveryInput);
      // Race the orchestrator against the outer timeout. On timeout we abort
      // the controller so in-flight Apollo calls stop promptly, then surface
      // the error.
      const timer = setTimeout(() => ctrl.abort(), DISCOVER_TIMEOUT_MS);
      try {
        result = await work;
      } finally {
        clearTimeout(timer);
      }
    } catch (err) {
      const errMsg = err instanceof Error ? err.message : String(err);
      const isMissingAnthropic = /ANTHROPIC_API_KEY/.test(errMsg);
      const isMissingApollo = err instanceof ApolloMissingApiKeyError;
      const isApolloRate = err instanceof ApolloRateLimitError;
      const isTimeout =
        ctrl.signal.aborted ||
        /timeout|timed out|aborted|outer timeout/i.test(errMsg);
      const safeErr = redactApolloKey(redactSecrets(errMsg)).slice(0, 500);

      try {
        await db.insert(actionLogsTable).values({
          userId: user.id,
          actionType: ACTION_TYPES.prospectorDiscover,
          actionStatus: "failure",
          durationMs: Date.now() - start,
          errorDetail: safeErr,
          metadata: {
            brand: sanitizeForStorage(body.brand ?? "", 200),
            error_class: isMissingAnthropic
              ? "missing_anthropic_key"
              : isMissingApollo
                ? "missing_apollo_key"
                : isApolloRate
                  ? "apollo_rate_limit"
                  : isTimeout
                    ? "timeout"
                    : "discovery_error",
          },
        });
      } catch {}

      const status = isMissingAnthropic
        ? 503
        : isMissingApollo
          ? 503
          : isApolloRate
            ? 503
            : isTimeout
              ? 504
              : 502;
      const code = isMissingAnthropic
        ? "anthropic_not_configured"
        : isMissingApollo
          ? "apollo_not_configured"
          : isApolloRate
            ? "apollo_rate_limited"
            : isTimeout
              ? "discover_timeout"
              : "discover_failure";
      res.status(status).json({
        error: code,
        message: isMissingAnthropic
          ? "ANTHROPIC_API_KEY is not configured."
          : isMissingApollo
            ? "APOLLO_API_KEY is not configured."
            : isApolloRate
              ? "Apollo rate limit hit. Try again in a minute."
              : isTimeout
                ? "Discovery cascade exceeded the 300s timeout."
                : "Discovery failed.",
        retryAfterSeconds:
          isApolloRate && err instanceof ApolloRateLimitError
            ? err.retryAfterSeconds
            : undefined,
      });
      return;
    }

    try {
      await db.insert(actionLogsTable).values({
        userId: user.id,
        actionType: ACTION_TYPES.prospectorDiscover,
        actionStatus:
          result.status === "success"
            ? "success"
            : result.status === "no_org_found" ||
                result.status === "no_contacts_found"
              ? "skipped"
              : "failure",
        durationMs: Date.now() - start,
        metadata: {
          brand: sanitizeForStorage(body.brand ?? "", 200),
          app_name: sanitizeForStorage(body.appName ?? "", 200),
          status: result.status,
          resolution: result.audit.resolution,
          strict_strategy: result.audit.strictStrategy,
          upgraded_to_parent: result.audit.upgradedToParent,
          smart_search_ran: Boolean(result.audit.smartSearch),
          smart_match_confidence:
            result.audit.smartSearch?.confidence ?? null,
          opus_rescue_ran: Boolean(result.audit.opusRescue),
          opus_strategies_attempted:
            result.audit.opusRescue?.strategiesAttempted ?? null,
          opus_strategy_succeeded:
            result.audit.opusRescue?.strategySucceeded ?? null,
          opus_web_search_used:
            result.audit.opusRescue?.webSearchUsed ?? null,
          subsidiary_expansion_ran:
            result.audit.subsidiaryExpansion?.ran ?? false,
          subsidiaries_found:
            result.audit.subsidiaryExpansion?.subsidiariesFound ?? 0,
          apollo_calls_consumed: result.audit.apolloCallsConsumed,
          budget_exhausted: result.audit.budgetExhausted,
          aborted: result.audit.aborted,
          org_found: Boolean(result.org),
          org_name: result.org ? sanitizeForStorage(result.org.name, 200) : null,
          org_employees: result.org?.estimatedNumEmployees ?? null,
          contacts_returned: result.contacts.length,
          // Aggregate token usage across resolveCompany + smart + opus
          llm_input_tokens:
            (result.llmUsage.resolveCompany?.inputTokens ?? 0) +
            (result.llmUsage.smartValidator?.inputTokens ?? 0) +
            (result.llmUsage.opusRescue?.inputTokens ?? 0),
          llm_output_tokens:
            (result.llmUsage.resolveCompany?.outputTokens ?? 0) +
            (result.llmUsage.smartValidator?.outputTokens ?? 0) +
            (result.llmUsage.opusRescue?.outputTokens ?? 0),
        },
      });
    } catch {}

    res.status(200).json({
      status: result.status,
      resolved: result.resolved,
      org: result.org,
      contacts: result.contacts,
      phasesRun: result.phasesRun,
      rejected: result.rejected,
      audit: result.audit,
      llmUsage: result.llmUsage,
    });
  },
);

`;

const exportAnchor = "export default router;";

if (src.includes('"/prospector/discover"') && !src.includes('"/prospector/discover_simple"') && !src.includes('"/prospector/discover-simple"')) {
  // Catastrophic — earlier 2.2-BE-B keys gone. Bail.
  console.error(`[patch-prospector-route] [FAIL] /prospector/discover-simple missing — chain broken.`);
  process.exit(2);
}
// Use a more specific marker for /discover (not /discover-simple)
const discoverRouteMarker = '"/prospector/discover",';
if (src.includes(discoverRouteMarker)) {
  log("[SKIP] /prospector/discover route already present");
} else if (!src.includes(exportAnchor)) {
  console.error(`[patch-prospector-route] [FAIL] export anchor not found.`);
  process.exit(2);
} else {
  src = src.replace(exportAnchor, ROUTE_BLOCK + exportAnchor);
  log("[APPLY] added /prospector/discover route handler");
}

if (src === before) {
  log("[NOOP] no changes");
} else {
  fs.writeFileSync(PATH, src);
  log("[DONE] prospector.ts updated");
}

const finalSrc = fs.readFileSync(PATH, "utf8");
const evidence = {
  discoveryOrchestrator_import: (finalSrc.match(/from "\.\.\/services\/discoveryOrchestrator"/g) || []).length,
  discover_route: (finalSrc.match(/"\/prospector\/discover",/g) || []).length,
  discover_simple_still_present: (finalSrc.match(/"\/prospector\/discover-simple"/g) || []).length,
  resolve_company_still_present: (finalSrc.match(/"\/prospector\/resolve-company"/g) || []).length,
  discover_handler_distinct: finalSrc.includes('"/prospector/discover",') && finalSrc.includes('"/prospector/discover-simple"'),
};
console.log("[patch-prospector-route] evidence:", JSON.stringify(evidence));
const expected = {
  discoveryOrchestrator_import: 1,
  discover_route: 1,
  discover_simple_still_present: 1,
  resolve_company_still_present: 1,
  discover_handler_distinct: true,
};
for (const [k, v] of Object.entries(expected)) {
  if (evidence[k] !== v) {
    console.error(`[patch-prospector-route] [FAIL] evidence ${k}: got ${evidence[k]}, expected ${v}`);
    process.exit(3);
  }
}
console.log("[patch-prospector-route] all evidence checks passed");
