# Manual real-Apollo walk-through — Ticket 2.2-BE-C

These cases exercise the production `/discover` endpoint with **smart cascade + Opus rescue + Phase 3 subsidiary expansion**, against live Apollo data. Intended to catch bugs the automated integration test (which only runs Probo end-to-end) doesn't surface.

## Prerequisites

1. `apply.sh` ran clean and the api-server workflow restarted.
2. `curl http://localhost:5000/api/healthz` returns `{"status":"ok"}`.
3. Replit Secrets: `APOLLO_API_KEY`, `ANTHROPIC_API_KEY`, `ADDON_API_KEY`.
4. Estimated total cost: **$2-4 in Apollo credits + $0.50 in Anthropic spend** for all 8 cases.

Each `curl` should be run with your real `$ADDON_API_KEY` and a real `$USER_ID` (any active user). Replace `localhost:5000` with your Replit deployment URL if running externally.

## Case 1 — Standard cascade hit (sanity)

**Goal**: confirm the orchestrator's **strict cascade** path still works after the smart/Opus layers were added on top.

```bash
curl -s -X POST http://localhost:5000/api/prospector/discover \
  -H "X-Api-Key: $ADDON_API_KEY" \
  -H "X-User-Id: $USER_ID" \
  -H "Content-Type: application/json" \
  -d '{"brand":"Probo","appName":"Probo: Opinion Trading App","domain":"probo.in","country":"IN","sourceType":"play_store","targetContacts":3}' \
  | jq '.audit.resolution, .audit.strictStrategy, .contacts | length'
```

**Pass criteria**:
- `audit.resolution = "strict_cascade"`
- `audit.strictStrategy ∈ {"domain_enrich","name_search","name_search_with_domain_validation","parent_direct"}`
- `contacts.length ≥ 1`
- `audit.opusRescue` is undefined (rescue did not run)

## Case 2 — Smart cascade rescues "Casualino Games" → "Casualino JSC"

**Goal**: brand vs legal entity. Strict cascade rejects domain-mismatched candidates; smart cascade does relaxed name search and Sonnet picks "Casualino JSC".

```bash
curl -s -X POST http://localhost:5000/api/prospector/discover \
  -H "X-Api-Key: $ADDON_API_KEY" \
  -H "X-User-Id: $USER_ID" \
  -H "Content-Type: application/json" \
  -d '{"brand":"Casualino Games","appName":"Bingo Casino","country":"BG","sourceType":"play_store","targetContacts":3}' \
  | jq '.audit.resolution, .audit.smartSearch, .org.name'
```

**Pass criteria**:
- `audit.resolution = "smart_llm_validated"`
- `audit.smartSearch.matchedCandidate = true`
- `audit.smartSearch.confidence ∈ {"high","medium"}`
- `org.name` contains "Casualino" (preferably "Casualino JSC")

## Case 3 — Opus rescue with web_search: tiny Russian dev "Astrum"

**Goal**: developer name ≠ brand name. The strict cascade fails (no Apollo match for the dev name); smart cascade finds candidates but Sonnet rejects them; Opus rescue uses web_search to find that "Astrum Entertainment" → "ASTRUM LLC".

```bash
curl -s -X POST http://localhost:5000/api/prospector/discover \
  -H "X-Api-Key: $ADDON_API_KEY" \
  -H "X-User-Id: $USER_ID" \
  -H "Content-Type: application/json" \
  -d '{"brand":"Astrum Entertainment","appName":"Мир домовят","country":"RU","sourceType":"play_store","targetContacts":3,"apolloCallBudget":80}' \
  | jq '.audit.resolution, .audit.opusRescue, .org.name, .org.estimatedNumEmployees'
```

**Pass criteria**:
- `audit.opusRescue.ran = true`
- `audit.opusRescue.diagnosis` mentions developer-vs-brand mismatch or similar
- `audit.opusRescue.webSearchUsed = true` (Opus called web_search)
- `audit.opusRescue.strategySucceeded > 0` OR final `audit.resolution = "opus_rescue"`
- If success: `org.name` contains "Astrum" AND **NOT** "VK" (the implausible-name rejection should fire if Opus suggests VK)

## Case 4 — Subsidiary expansion: "SMBC Group" → SMBC Nikko + SMBC Consumer Finance

**Goal**: holding company. Standard cascade finds SMBC Group (parent) but only ~2 contacts. Phase 3 expansion finds SMBC Nikko Securities + SMBC Consumer Finance and merges contacts to ≥6.

```bash
curl -s -X POST http://localhost:5000/api/prospector/discover \
  -H "X-Api-Key: $ADDON_API_KEY" \
  -H "X-User-Id: $USER_ID" \
  -H "Content-Type: application/json" \
  -d '{"brand":"SMBC Group","appName":"SMBC Direct","domain":"smbc.co.jp","country":"JP","sourceType":"website","targetContacts":6,"apolloCallBudget":120}' \
  | jq '.audit.resolution, .audit.subsidiaryExpansion, .contacts | length'
```

**Pass criteria**:
- `audit.subsidiaryExpansion.ran = true`
- `audit.subsidiaryExpansion.subsidiariesFound ≥ 1`
- `contacts.length ≥ 4` (parent contributed some, subsidiaries contributed more)
- Email domains span multiple subsidiaries (smbc.co.jp + smbcnikko.com or similar)

## Case 5 — Skip Opus rescue (cost control)

**Goal**: `skipOpusRescue: true` halts the cascade after smart phase fails. Verifies the off-switch works and returns `no_org_found` cleanly when applicable.

```bash
curl -s -X POST http://localhost:5000/api/prospector/discover \
  -H "X-Api-Key: $ADDON_API_KEY" \
  -H "X-User-Id: $USER_ID" \
  -H "Content-Type: application/json" \
  -d '{"brand":"Astrum Entertainment","appName":"Мир домовят","country":"RU","sourceType":"play_store","targetContacts":3,"skipOpusRescue":true,"apolloCallBudget":50}' \
  | jq '.status, .audit.resolution, .audit.opusRescue'
```

**Pass criteria**:
- `audit.opusRescue` is undefined (rescue did NOT run)
- `status` likely `"no_org_found"` (since smart alone may not resolve Astrum)

## Case 6 — Budget exhausted

**Goal**: tight `apolloCallBudget` triggers `budget_exhausted` status with audit telemetry intact.

```bash
curl -s -X POST http://localhost:5000/api/prospector/discover \
  -H "X-Api-Key: $ADDON_API_KEY" \
  -H "X-User-Id: $USER_ID" \
  -H "Content-Type: application/json" \
  -d '{"brand":"SMBC Group","appName":"SMBC Direct","country":"JP","sourceType":"website","targetContacts":15,"apolloCallBudget":15}' \
  | jq '.status, .audit.budgetExhausted, .audit.apolloCallsConsumed'
```

**Pass criteria**:
- `audit.budgetExhausted = true`
- `audit.apolloCallsConsumed ≥ 15`
- `status` is one of `"budget_exhausted"`, `"no_contacts_found"`, or `"success"` (depending on how much progress was made before budget hit)

## Case 7 — Outer timeout (synthetic — large Phase 3 search)

**Goal**: confirm the 300s outer timeout fires and returns `discover_timeout`. Synthetic scenario: high target + all features enabled + low cap.

> **Skip if**: short on time. This case takes 5 minutes by design.

```bash
time curl --max-time 320 -s -X POST http://localhost:5000/api/prospector/discover \
  -H "X-Api-Key: $ADDON_API_KEY" \
  -H "X-User-Id: $USER_ID" \
  -H "Content-Type: application/json" \
  -d '{"brand":"NotARealCompany12345Xyz","appName":"NotReal","country":"XX","sourceType":"website","targetContacts":50,"apolloCallBudget":200}' \
  | jq '.status, .error'
```

**Pass criteria**: response within ~305s with `error: "discover_timeout"` (504) — OR `status: "no_org_found"` if the cascade exits naturally on no candidates (which is more likely for a fake brand).

## Case 8 — Action_log inspection

**Goal**: confirm metadata fields are populated correctly.

```bash
psql "$DATABASE_URL" -c "
  SELECT
    action_status,
    metadata->>'resolution' AS resolution,
    metadata->>'opus_rescue_ran' AS opus_ran,
    metadata->>'subsidiaries_found' AS subs_found,
    metadata->>'apollo_calls_consumed' AS calls,
    metadata->>'contacts_returned' AS contacts,
    metadata->>'llm_input_tokens' AS in_tok,
    metadata->>'llm_output_tokens' AS out_tok,
    duration_ms
  FROM action_logs
  WHERE action_type = 'prospector.discover'
    AND user_id = '$USER_ID'
  ORDER BY created_at DESC
  LIMIT 10;
"
```

**Pass criteria**: every column populated with sensible values; durations spread between ~5s (cache hit) and ~120s (full Opus + Phase 3); token totals roughly 2k-15k input + 200-2k output per call.

## Pass / fail summary

After running cases 1-8, fill in:

| Case | Status | Notes |
| --- | --- | --- |
| 1 — Standard cascade | | |
| 2 — Smart (Casualino) | | |
| 3 — Opus rescue (Astrum) | | |
| 4 — Subsidiary (SMBC) | | |
| 5 — Skip Opus | | |
| 6 — Budget exhausted | | |
| 7 — Outer timeout | | |
| 8 — Action_log inspection | | |

If any case fails: capture the full response JSON + the action_log row + the api-server console output, and feed back for triage.
