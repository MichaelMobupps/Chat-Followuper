#!/usr/bin/env bash
#
# Apply 2.2-BE-C bundle. Idempotent. Run from monorepo root.
#
# Stack: appends to BE-2 → 2.1-BE → 2.2-BE-A → 2.2-BE-B (must already be applied).
#
# What this does:
#   1. Threads AbortSignal through apolloProspector.ts (closes 2.2-BE-B F-NEW-A
#      partially — at orchestrator's own apolloPost call sites).
#   2. Adds prospectorDiscover ACTION_TYPE in lib/db.
#   3. Adds llmValidator, opusRescue, subsidiaryExpander, discoveryOrchestrator
#      services.
#   4. Adds POST /api/prospector/discover route handler.
#   5. Mirrors changes to source-code/ (skipping lib/db build).
#
# After this script: do `npm run build && Stop+Run api-server workflow`.
#
set -euo pipefail

REPO_ROOT="${REPO_ROOT:-$(pwd)}"
BUNDLE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "[apply] repo: $REPO_ROOT"
echo "[apply] bundle: $BUNDLE_DIR"

cd "$REPO_ROOT"

# ─── Sanity: required upstream files must exist ──────────────────────────
required_files=(
  "lib/db/src/schema/action_logs.ts"
  "artifacts/api-server/src/routes/prospector.ts"
  "artifacts/api-server/src/services/apolloProspector.ts"
  "artifacts/api-server/src/services/orgFinder.ts"
  "artifacts/api-server/src/services/contactCollector.ts"
  "artifacts/api-server/src/services/companyResolver.ts"
)
for f in "${required_files[@]}"; do
  if [ ! -f "$f" ]; then
    echo "[apply] [FAIL] Required upstream file missing: $f"
    echo "[apply]        Apply 2.2-BE-B (and prior tickets) first."
    exit 2
  fi
done

# ─── Sanity: 2.2-BE-B markers present ────────────────────────────────────
grep -q 'prospectorDiscoverSimple: "prospector.discover_simple"' lib/db/src/schema/action_logs.ts \
  || { echo "[apply] [FAIL] 2.2-BE-B not detected in action_logs.ts"; exit 2; }
grep -q '"/prospector/discover-simple"' artifacts/api-server/src/routes/prospector.ts \
  || { echo "[apply] [FAIL] 2.2-BE-B not detected in routes/prospector.ts"; exit 2; }

# ─── Step 1: copy new service files (overwrite-safe — files are net-new) ──
echo "[apply] copying new service files…"
SVC=artifacts/api-server/src/services
cp "$BUNDLE_DIR/new-files/$SVC/llmValidator.ts" "$SVC/llmValidator.ts"
cp "$BUNDLE_DIR/new-files/$SVC/opusRescue.ts" "$SVC/opusRescue.ts"
cp "$BUNDLE_DIR/new-files/$SVC/subsidiaryExpander.ts" "$SVC/subsidiaryExpander.ts"
cp "$BUNDLE_DIR/new-files/$SVC/discoveryOrchestrator.ts" "$SVC/discoveryOrchestrator.ts"
echo "[apply]   ✓ llmValidator.ts ($(wc -l <"$SVC/llmValidator.ts") lines)"
echo "[apply]   ✓ opusRescue.ts ($(wc -l <"$SVC/opusRescue.ts") lines)"
echo "[apply]   ✓ subsidiaryExpander.ts ($(wc -l <"$SVC/subsidiaryExpander.ts") lines)"
echo "[apply]   ✓ discoveryOrchestrator.ts ($(wc -l <"$SVC/discoveryOrchestrator.ts") lines)"

# ─── Step 2: apply patches (anchored, idempotent) ─────────────────────────
echo "[apply] running patches…"
node "$BUNDLE_DIR/patches/patch-apollo-abort.mjs"
node "$BUNDLE_DIR/patches/patch-action-types.mjs"
node "$BUNDLE_DIR/patches/patch-prospector-route.mjs"

# ─── Step 3: typecheck (skip lib/db build per project convention) ─────────
echo "[apply] typecheck api-server…"
( cd artifacts/api-server && npx --no-install tsc --noEmit ) || {
  echo "[apply] [FAIL] typecheck failed."
  exit 3
}
echo "[apply] [OK] typecheck"

# ─── Step 4: bundle (esbuild) ─────────────────────────────────────────────
echo "[apply] bundling api-server…"
( cd artifacts/api-server && npm run build 2>&1 | tail -5 ) || {
  echo "[apply] [FAIL] esbuild bundle failed."
  exit 4
}
echo "[apply] [OK] bundle"

# ─── Step 5: mirror to source-code/ (artifacts → source-code only) ────────
if [ -f "source-code/sync.sh" ]; then
  echo "[apply] mirroring to source-code via sync.sh…"
  bash source-code/sync.sh || {
    echo "[apply] [WARN] sync.sh failed — continue (source mirror is non-blocking)."
  }
else
  echo "[apply] [SKIP] source-code/sync.sh not found — skipping mirror."
fi

echo
echo "[apply] DONE. Next:"
echo "[apply]   1. Stop+Run the api-server workflow."
echo "[apply]   2. Verify: curl http://localhost:5000/api/healthz   →   {\"status\":\"ok\"}"
echo "[apply]   3. Run integration test:"
echo "[apply]      ADDON_API_KEY=\$ADDON_API_KEY node tests/integration-2-2-be-c-discover.mjs"
echo
exit 0
