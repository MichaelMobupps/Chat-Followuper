# Group A — Doctrine engine verbatim ports + new stubs

## Where each file goes in your Replit repo

The folder structure of this zip mirrors the Replit repo layout. You can
extract the zip directly at the repo root and it will land each file in
the right place. Or paste them one by one through the Replit file UI.

```
lib/db/src/schema/users.ts                              ← REPLACE existing
artifacts/api-server/src/lib/anthropic.ts               ← NEW
artifacts/api-server/src/lib/constants.ts               ← NEW
artifacts/api-server/src/lib/pricing.ts                 ← NEW (stub for Ticket 1.11)
artifacts/api-server/src/lib/languageNativeness.ts      ← NEW (verbatim from email tool)
artifacts/api-server/src/lib/verticalClassifier.ts      ← NEW (verbatim from email tool)
artifacts/api-server/src/services/anthropicRetry.ts     ← NEW (verbatim from email tool)
artifacts/api-server/src/services/timingEngine.ts       ← NEW (verbatim from email tool)
```

`logger.ts` already exists in the repo from Ticket 1.1 and is unchanged
from the email tool's version — no replacement needed.

## Verbatim files (do not edit)

These five are byte-for-byte copies from the production Email Followuper:

- `anthropic.ts` — Anthropic SDK client with 60s timeout and own retry
- `languageNativeness.ts` — 35-language code-switching guides (Cyrillic, Hebrew, CJK, Arabic, Devanagari, Thai)
- `verticalClassifier.ts` — vertical taxonomy + CPS sub-vertical classifier
- `anthropicRetry.ts` — retry helper with backoff, retry-after, budget cap
- `timingEngine.ts` — schedule windows + batch scheduler

## New files (this project only)

- `constants.ts` — verbatim from email tool, included here because Ticket 1.1
  did not create it. May be reused/extended in later tickets.
- `pricing.ts` — Anthropic pricing table + cost helpers. Used by Ticket 1.11
  cost telemetry but introduced now so `messageGenerator.ts` (Group B) can
  import it cleanly.

## Schema patch — `users.ts`

The existing `lib/db/src/schema/users.ts` has all the columns but no defaults
and no `StageTiming` type. The replacement in this zip adds:

- `StageTiming` interface
- `DEFAULT_STAGE_TIMING` constant (3-7d, 10-14d, 21-28d)
- `DEFAULT_SEND_DAYS` constant ([1,2,3,4,5] = Mon-Fri)
- Defaults wired onto the `stageTiming`, `sendDays`, `sendHourStart`,
  `sendHourEnd`, `maxFollowups` columns
- Makes `stageTiming` and `sendDays` `NOT NULL`

A Drizzle migration is required after replacing this file.

## After pasting all files

Run the agent commands provided separately by Claude:

1. Drizzle generate + migrate (to apply the schema defaults)
2. Typecheck across the workspace
3. Sync to source-code/

If typecheck passes, Group A is done. Group B (messagePrompts.ts,
messageGenerator.ts, messageSummarizer.ts, channelRegister.ts) follows.
