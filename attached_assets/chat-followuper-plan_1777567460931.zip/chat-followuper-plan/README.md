# Chat Followuper — Build Plan Bundle

This bundle contains everything the Replit Agent (or Claude Code) needs to build the MobUpps Chat Followuper from scratch, Phase 1 (WhatsApp end-to-end).

## Files

1. **`CHAT_FOLLOWUPER_BUILD_PLAN.md`** — Architecture spec. Read once for context grounding.
2. **`PHASE_1_TICKETS.md`** — 12 ordered tickets. Each ticket = one agent session.
3. **`PHASE_1_AMENDMENTS.md`** — Three additive changes ported from the old WhatsApp app. Touches Tickets 1.2, 1.5, 1.6, and optional 1.7b.

## Pre-flight before kickoff

Set up these two prerequisites before Ticket 1.1 starts:

1. **Neon Postgres database.** Create a new database in the Neon dashboard. Copy the connection string. Add as Replit Secret: `DATABASE_URL`.
2. **Google OAuth client.** In the MobUpps Google Cloud project, create a new OAuth 2.0 client ID. Set authorized redirect URI to `https://chat-followuper.mobupps.com/api/auth/google/callback` (or the matching localhost redirect for dev). Add to Replit Secrets: `GOOGLE_OAUTH_CLIENT_ID`, `GOOGLE_OAUTH_CLIENT_SECRET`, `GOOGLE_OAUTH_REDIRECT_URI`.

Other secrets (Anthropic, Apollo, Mailgun) are existing MobUpps org-level keys — reuse them. Full list in Ticket 1.1.

## How to feed this to the agent

One ticket per session. Do not paste all 12 at once.

### First session prompt

```
Build the project per Ticket 1.1 in PHASE_1_TICKETS.md.

The full build plan is in CHAT_FOLLOWUPER_BUILD_PLAN.md for context.
The amendments in PHASE_1_AMENDMENTS.md do not affect Ticket 1.1.

Do not start Ticket 1.2 yet. When Ticket 1.1's acceptance criteria pass,
stop and report what passed, what failed, and any deviations from the spec.
```

### Subsequent session prompt template

```
Build the project per Ticket 1.X in PHASE_1_TICKETS.md.

Context files:
- CHAT_FOLLOWUPER_BUILD_PLAN.md (architecture)
- PHASE_1_AMENDMENTS.md (amendments — apply if this ticket is in the modifies list)

The previous ticket (1.X-1) is complete and verified.

Do not start the next ticket. When this ticket's acceptance criteria pass,
stop and report.
```

### Tickets that need the amendments file

- Ticket 1.2 (schema) — apply Amendment A
- Ticket 1.5 (Apollo client) — apply Amendments B and parts of C
- Ticket 1.6 (WhatsApp adapter) — apply Amendments B and C
- Ticket 1.7b (CSV import, optional) — Amendment C section C.2

All other tickets can ignore the amendments file.

## Don't delete the old WhatsApp app yet

Archive it (rename in Replit, e.g., `WhatsApp-Prospector-archived-2026-04`) until the new app passes Ticket 1.12 (Phase 1 closeout smoke test against real prospects). The old code references in `PHASE_1_AMENDMENTS.md` may still be useful if Ticket 1.5 or 1.6 hits unexpected behavior.

## Project subdomain

`chat-followuper.mobupps.com` recommended, matching the existing MobUpps subdomain pattern (`prospector.mobupps.com`, `followup.mobupps.com`, `retliner.mobupps.com`).
