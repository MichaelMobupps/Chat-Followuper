# Phase 1 — WhatsApp End-to-End: Ticket Breakdown

**Phase 1 goal:** SDR can log in with Gmail, seed prospects via Apollo manual flow, generate first WhatsApp messages with Doctrine engine, click deep links to send, and receive daily digests with reply-to-act controls. Follow-up cadence runs automatically.

**Out of scope for Phase 1:** Telegram, Teams, Slack, Mode B (full API), Microsoft auth, inbound message capture beyond manual paste.

**Each ticket below is sized for one Replit Agent or Claude Code session.** Tickets are ordered. Do not skip ahead; later tickets depend on earlier scaffolding.

---

## Ticket 1.1 — Repo bootstrap and shared scaffolding

**Goal:** Stand up an empty Replit project mirroring the `Email-Folllowuper` layout. No business logic yet.

**Files to create:**
- `artifacts/api-server/package.json` (mirror email tool deps: `@anthropic-ai/sdk`, `express`, `drizzle-orm`, `pg`, `dotenv`, `zod`, `libphonenumber-js`, `@mailgun/messages`, `googleapis`, `cookie-parser`, `cors`)
- `artifacts/api-server/tsconfig.json`
- `artifacts/api-server/src/index.ts` — Express boot, listens on `process.env.PORT`
- `artifacts/api-server/src/app.ts` — Express app, middleware, route registration
- `artifacts/api-server/src/lib/anthropic.ts` — copy from email tool verbatim
- `artifacts/api-server/src/lib/logger.ts` — copy from email tool
- `artifacts/api-server/src/lib/constants.ts` — copy from email tool, add chat-app constants
- `artifacts/api-server/src/routes/index.ts`, `routes/health.ts` — copy
- `dashboard/package.json`, `dashboard/vite.config.ts`, `dashboard/tsconfig.json`, `dashboard/index.html`, `dashboard/src/main.tsx`, `dashboard/src/App.tsx`, `dashboard/src/index.css` — copy and strip from email tool, keep shadcn/ui setup
- `dashboard/src/components/ui/*` — copy the shadcn/ui primitives in use
- `dashboard/src/lib/utils.ts` — copy
- `dashboard/src/components/layout.tsx` — copy, change nav items to: Today, Seeder, Prospects, Followups, Activity, Accounts
- `db/schema/index.ts` — empty exports for now
- `db/index.ts` — Drizzle client wired to `DATABASE_URL`
- `sync.sh`, `watch.sh`, `watcher.mjs` — copy from email tool
- `.replit` — autoscale deploy config, `run = "npm run dev"`
- `replit.nix` if needed
- `.env.example` — list expected secrets, no values
- `README.md` — short, points to this ticket file

**Secrets the project will need (set in Replit Secrets, not committed):**
- `ANTHROPIC_API_KEY` (org-level, MobUpps key)
- `APOLLO_API_KEY` (org-level)
- `MAILGUN_API_KEY`, `MAILGUN_DOMAIN`
- `GOOGLE_OAUTH_CLIENT_ID`, `GOOGLE_OAUTH_CLIENT_SECRET`, `GOOGLE_OAUTH_REDIRECT_URI`
- `DATABASE_URL` (Neon Postgres)
- `SESSION_SECRET` (32+ random bytes)
- `PUBLIC_BASE_URL` (e.g., `https://chat-followuper.mobupps.com`)

**Acceptance criteria:**
- `npm run dev` boots the API server, returns 200 on `GET /api/health`
- `npm run dev` in `dashboard/` boots Vite, shows the empty layout shell with the new nav items
- No business routes implemented yet
- Sync rule active: edits in `artifacts/api-server/src/` only

---

## Ticket 1.2 — Database schema and migrations

**Goal:** Final schema for Phase 1 ready to migrate.

**Files to create:**
- `db/schema/users.ts`
- `db/schema/prospects.ts`
- `db/schema/followups.ts`
- `db/schema/conversations.ts`
- `db/schema/magic_link_tokens.ts`
- `db/schema/oauth_nonces.ts`
- `db/schema/index.ts` — re-exports
- `db/migrations/0001_initial.sql` (or use Drizzle Kit `drizzle-kit generate`)

**Schema — see plan §5.** Phase 1 tables only. `microsoftRefreshToken` and `slackBotToken` columns on `users` are nullable, included now to avoid future migration noise.

**Important constraints:**
- `prospects.phone` is `text NOT NULL` and stored E.164 (no spaces, leading `+`)
- `prospects(userId, phone)` UNIQUE — same SDR cannot have two prospects with the same phone
- `followups(prospectId, stage)` UNIQUE
- `conversations.ts` indexed on `(prospectId, ts DESC)`
- `magic_link_tokens.token` UNIQUE, indexed
- All `timestamptz`, never `timestamp`

**Acceptance criteria:**
- `drizzle-kit generate` produces a clean migration
- Migration runs on Neon without error
- A `scripts/seed-dev.ts` inserts one fake user, one fake prospect, one fake follow-up — proves schema is usable

---

## Ticket 1.3 — Gmail OAuth login (tool-level auth)

**Goal:** SDR clicks "Sign in with Google" in the dashboard, lands on a logged-in state. This is tool identity, nothing to do with sending Gmail.

**Files to create / port:**
- `artifacts/api-server/src/routes/auth.ts` — `/api/auth/me`, `/api/auth/logout`
- `artifacts/api-server/src/routes/google-auth.ts` — `/api/auth/google/start`, `/api/auth/google/callback`
  - Adapt from `Email-Folllowuper/api-server/routes/gmail-auth.ts`
  - **Reduce scopes** to identity only: `openid email profile`
  - Do NOT request `gmail.send` or `gmail.readonly` — this tool does not send Gmail
- `artifacts/api-server/src/middlewares/auth.ts` — session cookie verification, populates `req.user`
- `artifacts/api-server/src/lib/session.ts` — sign/verify session cookies with `SESSION_SECRET` (HMAC SHA-256, 30-day expiry)
- `dashboard/src/hooks/use-current-user.ts` — port from email tool
- `dashboard/src/pages/login.tsx` — single "Sign in with Google" button
- `dashboard/src/components/auth-gate.tsx` — wraps protected routes

**Behavior:**
- First-time login auto-creates a `users` row keyed by Google email
- Restrict logins to `@mobupps.com` (or configurable allowlist via `ALLOWED_LOGIN_DOMAINS` env var, default `mobupps.com`)
- Reject other domains with a clean error page

**Acceptance criteria:**
- New SDR clicks login, completes Google flow, lands in dashboard
- `GET /api/auth/me` returns `{ id, email, name }` after login
- Non-MobUpps Gmail account is rejected
- Logout clears the session cookie

---

## Ticket 1.4 — Port the Doctrine engine, retargeted to chat

**Goal:** All language and message-generation logic from the email tool, adapted for chat output.

**Files to create:**
- `artifacts/api-server/src/lib/languageNativeness.ts` — copy verbatim from email tool
- `artifacts/api-server/src/lib/verticalClassifier.ts` — copy verbatim
- `artifacts/api-server/src/lib/channelRegister.ts` — NEW (see §7 of build plan)
  - Export `buildWriterRegisterBlock(channel)` and `buildCriticRegisterBlock(channel)`
  - Channel cases: `whatsapp` for now; stub `telegram`, `teams`, `slack` returning empty strings (filled in later phases)
- `artifacts/api-server/src/services/anthropicRetry.ts` — copy verbatim
- `artifacts/api-server/src/services/messageSummarizer.ts` — adapt from `emailSummarizer.ts`. Same job (extract topic + language), same meta-language sanitizer, same META_PARTICIPLES list. Field rename: `summary` stays the same field name; the prompt already produces a generic topic phrase.
- `artifacts/api-server/src/services/messagePrompts.ts` — adapt from `followupPrompts.ts`:
  - Remove subject-line generation
  - JSON output schema becomes `{ "message": "..." }`
  - Inject `buildWriterRegisterBlock(channel)` after `buildNativenessBlock(language)`
  - Critic adds `channel_register_match` 1-5 with forced rewrite below 3 (mirror the `language_match` pattern)
  - Keep META-LANGUAGE absolute prohibition unchanged
  - Keep FOLLOW-UP ACK rule for stages ≥ 2
- `artifacts/api-server/src/services/messageGenerator.ts` — adapt from `followupGenerator.ts`:
  - Same three-stage pipeline (draft → critic → rewrite)
  - Same self-healing loop with `bestOverall` tracking
  - Same `humanizeText` (em-dash strip, AI-tell phrase replacement, smart-quote normalize)
  - Function signature: `generateChatMessage({ prospect, conversation, channel, stage }) → { message, modelMetadata, costEstimate }`
  - `costEstimate` returns `{ inputTokens, outputTokens, usd }` rolled up across all stages
- `artifacts/api-server/src/services/timingEngine.ts` — copy verbatim

**WhatsApp register content (initial draft, will tune):**
```
WHATSAPP CHANNEL RULES:
- Length: 2-3 sentences MAXIMUM. Anything over 4 sentences feels like spam.
- No subject line. No signature. WhatsApp shows your name automatically.
- Greeting: "Hi {FirstName}," or omit entirely. Never "Dear", never "Good morning".
- Tone: real human typing on a phone. Casual-professional.
- Emojis: 0 in conservative markets (Japan, Korea, Germany, Nordics, Russia).
  0-1 in friendly markets (LATAM, India, SEA, Middle East).
- Banned phrases: "circling back", "touching base", "hope you are well", "I trust this finds you well".
- One soft CTA. One question mark maximum.
- Plain text only. No bullet lists. No bold/italic markdown. WhatsApp's `*bold*` syntax is allowed only for emphasizing one short word, never for headers.
- For follow-ups: reference prior contact in the first sentence. Keep it brief: "Following up on the MAFO numbers I sent" not "Following up on my detailed pricing breakdown for MAFO that I shared with you on April 24th".
```

**Acceptance criteria:**
- A standalone test script (`scripts/test-generate.ts`) generates a stage-1 WhatsApp message in English, Hebrew, Russian, Portuguese, and Hindi
- Output passes manual eyeball check: no em dashes, no "circling back", no subject lines, no signatures, 2-3 sentences each
- Critic block runs, returns scored JSON
- Total per-message cost reported by `costEstimate` is ≤ $0.20

---

## Ticket 1.5 — Apollo client (two-step search + reveal)

**Goal:** Wrap Apollo's API into a clean two-stage interface for the seeder.

**Files to create:**
- `artifacts/api-server/src/services/apolloClient.ts`

**Functions to expose:**
```ts
searchOrganizations(query: string, limit?: number): Promise<OrgResult[]>
// Calls Apollo organizations/search, no credit cost

searchPeopleInOrg(orgId: string, filters: PeopleFilters): Promise<UnrevealedPerson[]>
// Calls Apollo mixed_people/search, no credit cost
// Returns: name, title, department, seniority, country, linkedin_url, apolloPersonId
// NO contact info revealed

enrichPerson(apolloPersonId: string): Promise<RevealedContact>
// Calls Apollo /people/match or enrichment endpoint
// COSTS CREDITS — log every call to a credit_audit table or stdout with userId
// Returns: phone (E.164), email, telegram_handle (if available), confidence

PeopleFilters: {
  seniority?: 'owner' | 'founder' | 'c_suite' | 'partner' | 'vp' | 'head' | 'director' | 'manager' | 'senior' | 'entry' | 'intern'
  department?: string
  country?: string
  titleKeywords?: string[]
}
```

**Critical implementation details:**
- Phone normalization: every revealed phone runs through `libphonenumber-js` to E.164. Reject prospects whose phone fails parsing — don't store junk.
- Errors: Apollo returns 422 for invalid filters, 429 for rate limits, 401 for bad keys. Handle all three explicitly with typed error returns.
- Hard cap per request: `limit` defaults to 25, max 100. Don't let the UI request 1000 people at once.
- All calls go through the global `APOLLO_API_KEY`, no per-user keys.

**Acceptance criteria:**
- A test script searches "Pixonic" or another known org, picks the first match, lists 10 people without revealing, then reveals exactly 1 by `apolloPersonId`. Credit count goes up by 1.
- Phone numbers come out E.164 or the row is dropped with a logged warning.

---

## Ticket 1.6 — WhatsApp channel adapter (Mode A)

**Goal:** Generate the deep link and clipboard payload for WhatsApp send.

**Files to create:**
- `artifacts/api-server/src/services/channelAdapters/whatsapp.ts`

**Interface:**
```ts
export const whatsappAdapter = {
  channel: 'whatsapp' as const,
  modeA: {
    formatPhone(raw: string, fallbackCountry?: string): string {
      // Returns E.164 with leading + stripped (wa.me format wants digits only)
      // Throws on invalid
    },
    buildSendUrl(phoneE164: string, message: string): { url: string; clipboardText?: string } {
      const digits = phoneE164.replace(/^\+/, '');
      const encoded = encodeURIComponent(message);
      return { url: `https://wa.me/${digits}?text=${encoded}` };
      // No clipboardText for WhatsApp — text pre-fills via URL
    }
  },
  register: 'whatsapp' as const,
};
```

**Acceptance criteria:**
- Unit test: `formatPhone('+972-50-123-4567', 'IL')` returns `'+972501234567'`
- Unit test: `buildSendUrl('+972501234567', 'Hi John, quick check on MAFO?')` returns a URL that, when pasted into a browser, opens WhatsApp with the message pre-filled
- Special characters in message (Hebrew, emoji, line breaks) survive encoding intact when WhatsApp opens

---

## Ticket 1.7 — Seeder route and UI

**Goal:** End-to-end Apollo manual seeder flow in the dashboard.

**Backend:**
- `artifacts/api-server/src/routes/seeder.ts`
  - `POST /api/seeder/orgs/search` → `{ query }` → `OrgResult[]`
  - `POST /api/seeder/people/search` → `{ orgId, filters }` → `UnrevealedPerson[]`
  - `POST /api/seeder/people/reveal` → `{ apolloPersonIds: string[] }` → `RevealedContact[]`
  - `POST /api/seeder/prospects/create` → `{ revealedRows[], channel: 'whatsapp', contextNotes }` → creates `prospects` rows + stage-0 entry in `conversations` (the SDR's intent), returns prospect IDs
  - `POST /api/seeder/messages/generate` → `{ prospectIds }` → runs Doctrine for each, stores generated text on the prospect, returns `{ prospectId, message, deepLinkUrl, costEstimate }[]`

**Frontend:**
- `dashboard/src/pages/seeder.tsx`
  - Step 1: Search for company. Input + results list.
  - Step 2: Pick org. Filters panel (seniority, department, country). People grid: checkbox column, name, title, department, country, LinkedIn icon (opens new tab).
  - Step 3: SDR ticks rows, sees a "Reveal N people (will use ~N credits)" button. Confirmation modal if N > 5.
  - Step 4: Revealed table: phone, email, Telegram. Editable context notes per row ("They asked for India case study", "Met at Gamescom").
  - Step 5: "Generate WhatsApp messages" button. Loading state per row with cost shown. Generated message preview, edit-in-place, "Open in WhatsApp" green button.
  - Step 6: When SDR clicks Open WhatsApp: tool marks the prospect's `firstMessageSentAt = now()`, schedules stage-1 follow-up via `timingEngine`, opens the deep link in a new tab.

**Token/cost telemetry:**
- Reveal step shows running Apollo credit count for the day
- Generate step shows per-row Anthropic cost and a session total at top

**Acceptance criteria:**
- SDR completes the full flow against a real Apollo org
- 5 prospects created, 5 messages generated, all 5 deep links open WhatsApp with correct pre-filled text
- `prospects` and `followups` rows present in DB
- Total session cost displayed accurately (sum of all generation calls)
- Reveal cap enforced: revealing more than the configured daily cap blocks with a clear error

---

## Ticket 1.8 — Scheduler and follow-up generation

**Goal:** Cron-like loop that picks up due follow-ups, generates messages, and surfaces them in the dashboard.

**Files to create:**
- `artifacts/api-server/src/services/scheduler.ts` — adapt from email tool's `scheduler.ts`
  - `processDueFollowups()`: claims followups with `status='queued'` and `scheduledAt <= now()`, calls `messageGenerator.generateChatMessage` with channel + full conversation history, marks `status='pending_approval'` on success or `status='failed'` with `errorMessage` on error
  - `autoQueueAllCampaigns()`: for each prospect not paused and not replied, ensures the next stage is queued per `user.stageTiming`
  - Branches on `prospect.firstMessageChannel` to call the right adapter for `deepLinkUrl` materialization
- `artifacts/api-server/src/cron.ts` — runs `processDueFollowups` and `autoQueueAllCampaigns` every 5 minutes via `setInterval` (Replit autoscale compatible — same pattern as email tool)

**Conversation context fed to the generator:**
- All `conversations` rows for the prospect, oldest to newest, formatted as a thread
- Plus `prospect.contextNotes` (free-text SDR-supplied context)
- Plus the prospect's vertical, country, language

**Status flow:**
```
queued → generating → pending_approval → sent (when SDR clicks deep link)
                   ↘ failed
```

**Acceptance criteria:**
- A prospect created in Ticket 1.7 with `stageTiming.s2 = 3 days` gets a stage-2 follow-up auto-generated within 5 minutes after the 3-day mark
- Generated message references the prior outbound message (FOLLOW-UP ACK rule)
- Failure path: temporarily set a bad `ANTHROPIC_API_KEY`, confirm follow-up moves to `failed` with the error message stored, recovers when the key is restored

---

## Ticket 1.9 — Today / Followups / Prospects pages

**Goal:** Full operational dashboard for daily SDR workflow.

**Pages:**
- `dashboard/src/pages/today.tsx`
  - Three sections: Overdue, Due today, Coming this week
  - Each row: channel badge, prospect name + company + title, stage badge, status pill, generated message preview (collapsible), primary "Open in WhatsApp" button, secondary actions (Edit, Snooze N days, Skip, Mark Replied, Paste Reply)
  - Empty states for each section
- `dashboard/src/pages/prospects.tsx`
  - Filterable table: channel, status (active / replied / paused), country, vertical, last contact date
  - Click a row → drawer or detail page with full conversation history and per-stage breakdown
- `dashboard/src/pages/followups.tsx`
  - Status filter tabs: All / Queued / Pending Approval / Sent / Failed / Skipped
  - Per-row: prospect, stage, channel, scheduled time, generated message, action buttons
- `dashboard/src/pages/activity-log.tsx` — chronological log of every action: generated, sent (clicked), replied, snoozed, skipped, failed
- `dashboard/src/pages/accounts.tsx` — port from email tool, with chat-relevant settings:
  - Stage timing (days between stages, max 5 stages)
  - Send hours (no cron firing outside these for the user's timezone)
  - Send days (skip weekends?)
  - Digest hour, digest timezone
  - Daily Apollo reveal cap
  - Monthly Anthropic spend cap (hard stop)

**Mark Replied / Paste Reply behavior:**
- Mark Replied: confirms, sets `prospects.replied = 1`, `repliedAt = now()`, pauses follow-ups, no conversation entry.
- Paste Reply: opens a textarea, SDR pastes the prospect's actual message, "Save" creates an inbound `conversations` row with the pasted text + `now()` as ts. Future follow-ups will see this in the thread.

**Acceptance criteria:**
- Five fake prospects across different stages render correctly in Today
- Clicking "Open in WhatsApp" opens the deep link AND marks the followup as sent (one click does both — non-blocking analytics call)
- Snooze 3 days actually pushes `scheduledAt` by 3 days and the row vanishes from Today
- Paste Reply text shows up in next generated follow-up's context

---

## Ticket 1.10 — Daily digest and magic-link tokens

**Goal:** Pure-template digest email with reply-to-act controls.

**Files to create:**
- `artifacts/api-server/src/services/digestSender.ts`
  - `generateDigestForUser(userId)`: counts overdue / due today / due this week, generates magic-link tokens for `send_all`, `snooze_all_1d`, `review`, optionally calls Haiku for a one-line opener
  - `sendDigestEmail(userId, payload)`: Mailgun send to `user.email`, `from = 'digest@chat-followuper.mobupps.com'`, `reply-to = digest-<userid>-<yyyymmdd>@inbound.chat-followuper.mobupps.com`
- `artifacts/api-server/src/services/inboundParser.ts`
  - Mailgun Routes webhook target: `POST /api/inbound/digest-reply`
  - Strip quoted reply (Mailgun provides `stripped-text`)
  - Match keywords: `send all`, `send`, `yes` → invoke send_all token; `snooze 1d|2d|3d` → invoke snooze; `review`/`open`/`dashboard` → reply with magic dashboard link; `pause` → pause all follow-ups for the user
  - Unknown reply → auto-respond with "didn't understand, here's the dashboard link"
- `artifacts/api-server/src/routes/magic.ts`
  - `GET /api/magic/:token` — validates, executes the action, redirects to dashboard with a flash message ("Sent 5 follow-ups") or shows a confirmation page
  - Tokens are single-use (set `usedAt`), 7-day expiry
- `artifacts/api-server/src/routes/digest.ts`
  - `POST /api/digest/test` (dev only): triggers a digest send for the calling user immediately
- Cron addition: `cron.ts` runs `runDailyDigest()` once a minute, checks each user's `digestHourLocal` + `digestTimezone` and fires their digest when their local time hits the configured hour

**Digest body template (no client names, no message previews):**
```
Subject: Your follow-ups for {dayName}, {dateLong}

[optional Haiku opener line]

Counts:
  Overdue: {n}
  Due today: {n}
  This week: {n}

[Send all 5 drafts]   [Open dashboard]   [Snooze all 1 day]

Or just reply with:
  send all  — Send drafts as-is
  review    — Open dashboard for full review
  snooze 1d — Push everything one day forward
  pause     — Pause all follow-ups
```

**Mailgun setup (one-time, document in README):**
- MX record on `inbound.chat-followuper.mobupps.com` → Mailgun
- Mailgun Route: `match_recipient(".*@inbound.chat-followuper.mobupps.com")` → `forward("https://chat-followuper.mobupps.com/api/inbound/digest-reply")`
- SPF, DKIM, DMARC on the sending subdomain

**Acceptance criteria:**
- `POST /api/digest/test` sends an email to the SDR's address with correct counts and three working magic-link buttons
- Replying "send all" from the SDR's Gmail triggers the inbound webhook, marks all due follow-ups as sent, and posts a confirmation reply
- Replying "snooze 3" pushes all due follow-ups out 3 days
- Replying "review" responds with a one-time magic link to the dashboard that auto-logs the SDR in for that session

---

## Ticket 1.11 — Cost telemetry and spend caps

**Goal:** Every Anthropic call is logged with token + USD cost. Per-user monthly cap hard-stops generation.

**Files to create:**
- `db/schema/llm_usage.ts` — table: `id, userId, prospectId, followupId, model, inputTokens, outputTokens, usd, ts, purpose ('summarize'|'draft'|'critic'|'rewrite'|'digest_opener')`
- `artifacts/api-server/src/services/costMeter.ts`
  - `logUsage(userId, model, inputTokens, outputTokens, purpose, ...)`
  - `getMonthlySpend(userId): Promise<number>` — current calendar month total
  - `assertUnderCap(userId)` — throws `MonthlyCapExceededError` if `monthly_spend >= user.monthlySpendCapUsd`
- Hook `assertUnderCap` into `messageGenerator.generateChatMessage` before stage 1
- Hook `logUsage` after every Anthropic call (draft, critic, rewrite, digest opener, summarizer)
- Dashboard header pill: "$X.XX this month / $YY cap"
- Activity log entry when cap is hit, with a hint to raise the cap in Accounts

**Pricing constants** (centralized in `lib/pricing.ts`):
```ts
export const ANTHROPIC_PRICING = {
  'claude-opus-4-7': { input: 15.00, output: 75.00 }, // per million tokens
  'claude-sonnet-4-6': { input: 3.00, output: 15.00 },
  'claude-haiku-4-5': { input: 0.80, output: 4.00 },
};
```

**Acceptance criteria:**
- After Ticket 1.7 run, `llm_usage` has 4-7 rows per generated message (summarize + draft + critic + maybe rewrite)
- Header shows accurate running monthly total
- Setting `monthlySpendCapUsd = 0.01` and trying to generate produces `MonthlyCapExceededError` and the dashboard shows it cleanly

---

## Ticket 1.12 — End-to-end smoke test and Phase 1 closeout

**Goal:** Run the full happy path against real services with a real prospect, document anything that needs Phase 1.5 patches.

**Procedure:**
1. Deploy to `chat-followuper.mobupps.com`
2. Sign in with `michael@mobupps.com`
3. Configure Accounts: stageTiming `{s1: 0, s2: 3, s3: 7, s4: 14}`, send hours 9-18, digestHour 9, monthlySpendCap $50, Apollo reveal cap 20/day
4. Seeder: search a real org, pick 3 candidates, reveal, generate, click first WhatsApp link, send manually
5. Wait 3 days. Confirm digest arrives at 9am with overdue=0, dueToday=3
6. Confirm stage-2 follow-up auto-generated, references stage-1 message correctly
7. Reply to digest with "send all"; confirm all 3 stage-2 messages move to sent in the dashboard
8. Pick one prospect, paste a fake reply, generate stage-3 manually from the prospect detail page; confirm stage-3 message addresses the pasted reply contextually
9. Verify total cost in dashboard matches manual sum of `llm_usage`

**Phase 1 closeout deliverables:**
- A `PHASE_1_NOTES.md` in the repo with: what worked, what didn't, prompt tuning needed for WhatsApp register, register edits to commit, any Apollo plan limits hit, Mailgun deliverability notes
- Bug list ranked by severity for Phase 1.5

**Definition of Phase 1 done:** Steps 1-9 complete with no manual database surgery, no console errors, no failed follow-ups except deliberately injected ones for testing.

---

## Cross-cutting rules for every ticket

1. Sync direction: edit only `artifacts/api-server/src/`. After every commit, `rsync --delete` to `source-code/src/`.
2. Secrets only in Replit Secrets. Never in `.replit`, never in code. CI fails if any of the secret names appear in a non-`.env.example` file.
3. Every Anthropic call passes through `withAnthropicRetry`.
4. Every Apollo reveal logs to stdout AND increments a per-day counter checked against the user's cap.
5. No hard-coded multilingual fallback templates in `messageGenerator`. Failure is a real failure surfaced to the SDR.
6. No bullet lists, no headers, no markdown formatting in any generated chat message body.
7. Em dashes are banned in all generated output. The humanizer enforces this.
8. Every new dashboard page has a loading state, an empty state, and an error state.
9. Every backend route returns `{ ok: true, data }` or `{ ok: false, error }`. No mixed shapes.
10. Phase 1 has no Telegram, Teams, Slack, or Microsoft auth code. Stub the channel switch so Phase 2 fits in cleanly without refactoring scheduler or messageGenerator.

---

## What I want to know after each ticket

When you (or Replit Agent / Claude Code) finish a ticket, tell me:
- Which acceptance criteria passed and which failed
- Any deviation from the spec and why
- Any prompt tuning I should know about for the WhatsApp register
- Any unexpected Apollo or Mailgun behavior
- Cost actuals vs estimates

I'll write Phase 2 (Telegram) tickets after Phase 1 ships and the closeout notes are written. Same for Phase 3 (Teams) and Phase 4 (Slack).
