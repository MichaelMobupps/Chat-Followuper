# MobUpps Chat Followuper + Manual Seeder — Build Plan

**Status:** Draft v1.0
**Author context:** Internal MobUpps tool. Sister product to Email Followuper. Replit autoscale, Node/TS + React + Drizzle + Neon Postgres + Anthropic SDK. Same hosting and stack pattern as `michael2502/Email-Folllowuper`.

## 1. Purpose

A single internal tool that does two jobs for chat channels (WhatsApp, Telegram, Teams, Slack):

1. **Manual Prospector (Apollo Seeder).** Human-in-the-loop prospecting that browses Apollo candidates without revealing them, lets the SDR pick whom to pursue, and only then spends Apollo credits on the selected few. Replaces the carpet-bomb pattern with a precision pattern.
2. **Followuper.** Tracks every prospect contacted on a chat channel, schedules follow-ups by stage and timing window, generates each follow-up through the full Doctrine pipeline, and reminds the SDR via daily digest.

Both jobs share the same Doctrine writing engine, the same database, the same dashboard, and the same channel adapters. Two modes, one product.

## 2. Operating Modes

### Mode A — Click-Send Deep Links (default, Phase 1+)

The tool generates a fully formed message and a deep link. The SDR clicks the link, the relevant chat app opens with the conversation loaded, the message is either pre-filled (WhatsApp) or already on the clipboard (Telegram), and the SDR taps Send.

| Channel  | Deep link format                                | Pre-fill | Auth needed |
|----------|-------------------------------------------------|----------|-------------|
| WhatsApp | `https://wa.me/<phone>?text=<urlencoded>`       | Yes      | None        |
| Telegram | `https://t.me/+<phone>` + clipboard copy        | No       | None        |
| Teams    | Graph API send (no deep link path)              | n/a      | MS OAuth    |
| Slack    | Web API send (no deep link path)                | n/a      | Slack OAuth |

WhatsApp and Telegram in Mode A require zero infrastructure: no Meta Cloud API, no QR code logins, no bot tokens, no Telegram MTProto, no rate limits, no template approvals. The cost is one click per send and the inability to read inbound replies programmatically.

### Mode B — Full API (future, optional)

For markets or accounts that justify the setup cost, the same channel adapters can switch to full API send and inbound capture (WhatsApp Cloud API, Telegram Bot API, etc.). Same Doctrine engine, same dashboard, just different last mile. Defer until Mode A is shipped and adopted.

## 3. Carry-Over from Email Followuper

Everything technical that already works in `Email-Folllowuper` ports across with minimal change. Specifically:

### Ported as-is
- `lib/anthropic.ts` — direct Anthropic SDK client with timeout and own retry
- `lib/languageNativeness.ts` — full 35-language code-switching guides (`buildNativenessBlock`, `buildCriticNativenessBlock`)
- `lib/verticalClassifier.ts` — vertical taxonomy and classifier
- `lib/logger.ts`, `lib/constants.ts`
- `services/anthropicRetry.ts` — `withAnthropicRetry` with retryable detection, Retry-After honoring, budget cap
- `services/timingEngine.ts` — `getScheduleWindow`, `generateScheduledTime`, `generateBatchSchedule`
- `services/emailSummarizer.ts` rebadged as `messageSummarizer.ts` — meta-language detection, sanitizer, language detection fallback

### Ported with adaptation
- `services/followupGenerator.ts` → `services/messageGenerator.ts`
  - Same three-stage pipeline: draft (Sonnet) → critic (Opus) → rewriter (Sonnet)
  - Same self-healing loop with `bestOverall` tracking and meta-language guard
  - Same `humanizeText` post-processor (em-dash strip, AI-phrase replacement, smart-quote normalize)
  - **New:** the prompts pull in a `channelRegister` block alongside the language nativeness block
  - **Removed:** subject-line generation, JSON output schema becomes `{ "message": "..." }` instead of `{ "subject": "...", "body": "..." }`
- `services/followupPrompts.ts` → `services/messagePrompts.ts`
  - System prompt rewritten for chat register (no formal email language)
  - Critic adds new criterion `channel_register_match` alongside `language_match`
  - Same META-LANGUAGE absolute prohibition
  - Same FOLLOW-UP ACK rule (every stage 2+ message references prior contact)
- `services/scheduler.ts`
  - Same `processDueFollowups` pattern (claim with status update, generate, send-or-pending-approval, mark sent)
  - Same `autoQueueAllCampaigns` for stage-by-stage advancement
  - **New:** branches on `channel` field to call the right adapter
  - **New:** for Mode A channels, `sent` status means "drafted and SDR clicked the deep link" rather than "API delivered"
- `routes/auth.ts`, `routes/health.ts` — same shape
- Dashboard layout, hooks (`use-api-key`, `use-current-user`, `use-toast`, `use-mobile`), shadcn/ui components, Tailwind setup

### Replaced
- `services/gmailClient.ts`, `services/gmailSync.ts` — replaced by per-channel adapters (see §6)
- `routes/gmail-auth.ts` — replaced by `routes/channels/*.ts`
- `dashboard/pages/email-inspector.tsx` — replaced by `dashboard/pages/seeder.tsx`

### Discarded (not relevant to chat channels)
- The Gmail Apps Script add-on under `addon/`
- Subject-line semantics throughout
- Section-by-section email pipeline remnants (already removed in current Email Followuper, just confirming none ported)

## 4. New Components

| Module                                | Purpose                                                                                          |
|---------------------------------------|--------------------------------------------------------------------------------------------------|
| `lib/channelRegister.ts`              | Per-channel writing rules (length, greeting style, signature, emoji tolerance, formatting)      |
| `services/channelAdapters/whatsapp.ts`| Deep-link generation, phone normalization, message URL-encoding                                  |
| `services/channelAdapters/telegram.ts`| Deep-link generation + clipboard payload preparation                                             |
| `services/channelAdapters/teams.ts`   | Graph API send (Phase 3), token refresh, chat resolution                                         |
| `services/channelAdapters/slack.ts`   | Web API send (Phase 4)                                                                           |
| `services/apolloClient.ts`            | Two-step Apollo flow: `searchPeople` (no reveal, free) + `enrichPerson` (reveal, costs credits) |
| `services/digestSender.ts`            | Pure-template daily digest with optional one-line Haiku opener; magic-link buttons               |
| `services/inboundParser.ts`           | Parses replies to digest emails (`send all`, `snooze 3`, `review`, free text)                    |
| `routes/seeder.ts`                    | Endpoints for the manual prospector flow                                                         |
| `routes/channels/*.ts`                | Connect / disconnect / status endpoints per channel                                              |
| `dashboard/pages/seeder.tsx`          | Apollo manual seeder UI                                                                          |
| `dashboard/pages/channels.tsx`        | Channel connection status (only meaningful from Phase 3)                                         |

## 5. Database Schema

Postgres via Drizzle ORM, same shape pattern as Email Followuper.

### Tables

**`users`** (extends current schema)
```
id, email, name, isConnected
stageTiming jsonb, sendDays jsonb, sendHourStart, sendHourEnd
maxFollowups, requireApproval
digestHourLocal       integer  -- 9 by default
digestTimezone        text     -- 'Asia/Jerusalem' default
microsoftRefreshToken text     -- nullable, Phase 3
slackBotToken         text     -- nullable, Phase 4
createdAt, updatedAt
```

**`prospects`** (the contacts we are reaching out to)
```
id, userId
prospectName, company, title, vertical, subVertical, product
country, language        -- ISO codes
phone                     -- E.164 normalized
telegramHandle            -- nullable
teamsEmail                -- nullable, Phase 3
slackUserId               -- nullable, Phase 4
linkedinUrl               -- nullable, used for context only
apolloPersonId            -- nullable, audit trail for credit usage
sourceMode                -- 'apollo_manual' | 'csv_paste' | 'manual_entry'
contextNotes text         -- free text the SDR pasted: prior thread, intent, hooks
firstMessageBody text     -- the first message generated and sent
firstMessageChannel       -- 'whatsapp' | 'telegram' | 'teams' | 'slack'
firstMessageSentAt timestamptz
replied integer default 0
repliedAt timestamptz
followupPaused boolean default false
createdAt, updatedAt
```

**`followups`** (each scheduled follow-up against a prospect)
```
id, prospectId
stage integer
channel text                -- inherits from prospect.firstMessageChannel by default
status text                 -- 'queued' | 'generating' | 'pending_approval' | 'sent' | 'skipped' | 'failed'
scheduledAt timestamptz
generatedMessage text       -- nullable until generation
sentAt timestamptz          -- in Mode A, set when SDR clicks the deep link
deepLinkUrl text            -- materialized for dashboard rendering
clickedAt timestamptz       -- nullable, telemetry only
errorMessage text
createdAt
unique(prospectId, stage)
```

**`conversations`** (every message exchanged with a prospect, for context)
```
id, prospectId
direction text              -- 'outbound' | 'inbound'
channel text
body text
ts timestamptz
sourceFollowupId integer    -- nullable, links to followups.id when outbound was generated
createdAt
```

The `conversations` table is the new spine of context. For follow-up generation at stage N, the generator pulls the full conversation history (outbound and inbound) and feeds it into the prompt. This is more reliable than summary-only context and mirrors what Gmail thread reading does in the email tool.

**`magic_link_tokens`**
```
id, userId
token text unique
action text                 -- 'send_all' | 'snooze' | 'review' | 'send_one' | 'mark_replied'
payloadJson jsonb           -- e.g., { followupId: 123 } for send_one
expiresAt timestamptz       -- 7 days
usedAt timestamptz
createdAt
```

**`oauth_nonces`** — same as Email Followuper, used by Teams/Slack OAuth flows in later phases.

## 6. Channel Adapters

A channel adapter exposes a uniform interface:

```ts
interface ChannelAdapter {
  channel: 'whatsapp' | 'telegram' | 'teams' | 'slack';
  modeA: {
    buildSendUrl(prospect, message): { url: string; clipboardText?: string };
    formatPhone?(raw: string, country?: string): string;
  };
  modeB?: {
    sendMessage(user, prospect, message): Promise<{ externalId: string }>;
    fetchInbound(user, sinceTs): Promise<InboundMessage[]>;
  };
  register: ChannelRegister;
}
```

### WhatsApp adapter (Phase 1)
- `formatPhone`: strip non-digits, prepend country code if missing, validate via libphonenumber-js
- `buildSendUrl`: `https://wa.me/${digits}?text=${encodeURIComponent(message)}`
- Mode B placeholder: WhatsApp Cloud API client (defer)

### Telegram adapter (Phase 2)
- `formatPhone`: same normalization
- `buildSendUrl`: returns `{ url: 'https://t.me/+${digits}', clipboardText: message }`
  - Telegram deep links do not pre-fill text for non-bot chats. Tool copies message to clipboard and opens the link. UI shows a "Message copied — paste with Cmd/Ctrl-V in Telegram" hint.
- Mode B placeholder: Telegram Bot API (only useful when prospect already messaged a MobUpps bot first; deprioritize)

### Teams adapter (Phase 3)
- Microsoft OAuth via Graph API (`Chat.ReadWrite`, `ChatMessage.Send`, `User.Read`)
- Sends as the SDR (delegated permissions), not as a bot
- `sendMessage`: resolve or create 1:1 chat by recipient email, then `POST /chats/{chatId}/messages`
- Inbound: poll `GET /me/chats/{chatId}/messages?$filter=createdDateTime gt …` per active prospect once per scheduler tick
- No deep link mode. Teams requires API auth regardless. The product surface is "click-send" through the dashboard.

### Slack adapter (Phase 4, deferred)
- Slack OAuth, store bot token per user
- Send via `chat.postMessage` to a Slack Connect channel or DM
- Inbound via Events API webhook (requires public URL; Replit handles this)
- Skip until the other three are stable.

## 7. Channel Register

The new `lib/channelRegister.ts` mirrors the architecture of `languageNativeness.ts`. It returns a rules block injected into both the writer and critic prompts. Keys are channel codes; values are the literal text appended to the system prompt.

Sketch of the WhatsApp register:

```
WHATSAPP CHANNEL RULES:
- Length: 2-3 sentences MAXIMUM. Anything over 4 sentences feels like spam.
- No subject line. No signature. WhatsApp shows your name automatically.
- Greeting: "Hi <FirstName>," or omit. Never "Dear", never formal openers.
- Tone: real human typing on a phone. Casual-professional.
- Emojis: 0 in conservative markets (Japan, Korea, Germany, Nordics).
  0-1 in friendly markets (LATAM, India, SEA, Middle East).
- No "circling back", "touching base", "hope you are well".
- One soft CTA. One question mark maximum.
- Plain text only. No bullet lists. No bold/italic markdown.
```

The critic gets a parallel block scoring `channel_register_match` 1-5. Like `language_match`, a score below 3 forces `needs_rewrite = true`.

For follow-ups, the same register applies, plus the universal follow-up acknowledgement rule already in the email engine ("must reference prior contact in first 1-2 sentences").

## 8. Doctrine Engine — Multi-Stage Pipeline

Identical control flow to `Email-Folllowuper/api-server/services/followupGenerator.ts`, retargeted at chat output:

1. **Self-heal stored summary** (port `summaryLooksMeta` + `resanitizeStoredSummary`)
2. **Draft** with Sonnet 4.6, JSON output `{ "message": "..." }`
3. **Detect meta-language** in the body (port the regex set: `META_VERBS`, `claiming the ability to`, `as urgency`, `-ing` chain detector, "following up on" reference scanner)
4. **Critic** with Opus 4.7, scoring criteria:
   - `no_meta_language` (1-5)
   - `followup_ack` (1-5, only stages ≥ 2)
   - `language_match` (1-5)
   - `language_naturalness` (1-5)
   - `channel_register_match` (1-5) — new
   - `conciseness` (1-5)
   - `relevance` (1-5)
   - `differentiation` (1-5)
   - `tone` (1-5)
5. **Rewrite** with Sonnet 4.6 if `needs_rewrite`
6. **Loop up to 3 healing iterations**, tracking `bestOverall` so we always have a usable draft to fall back to
7. **Humanize** the final output: strip em/en dashes, smart quotes, AI-tell phrases ("delve", "leverage", "seamless", "unlock potential")

Important inheritance: the engine never falls back to a hardcoded multilingual template on failure. If the LLM is unreachable, the follow-up is marked `failed` with the error message and surfaces in the UI. Same hard rule as the email tool.

## 9. Apollo Manual Seeder Flow

The whole point of the seeder is to spend Apollo credits **after** human judgement, not before.

### Step-by-step
1. SDR opens **Seeder** page in dashboard
2. Search by company name or domain → calls Apollo `organizations/search` (free)
3. Pick the right organization from results → calls Apollo `mixed_people/search` filtered by org (free; returns names, titles, departments, LinkedIn URLs without contact info)
4. Optional filter chips: seniority, department, country
5. SDR sees a candidate list, ticks 1-N people worth pursuing
6. SDR clicks **"Reveal selected"** → calls Apollo `enrichment` (this is the credit-spending call) only for ticked rows
7. Tool shows revealed phones / emails / Telegram handles. SDR confirms each row.
8. SDR clicks **"Generate first messages"** → Doctrine engine runs in parallel for each prospect, producing a Mode A message per row
9. Each row now has a green **"Open WhatsApp"** or **"Open Telegram"** button with the pre-built deep link. SDR clicks one, app opens, taps Send, returns. Repeats per row.
10. After click, the row moves to the **Followuper** view with the prospect record initialized and a stage-1 follow-up scheduled.

### What the SDR sees per candidate before reveal
- Name, title, company, department, country, LinkedIn URL
- Apollo confidence score (when available)
- A "no contact info yet — reveal to fetch" hint

### What the SDR sees after reveal
- Phone (E.164), corporate email, Telegram handle if Apollo has it
- Generated message preview
- Two action buttons: open in chat app, or queue without sending now

### Credit guard rails
- A per-user daily reveal cap (config in user settings)
- Confirmation dialog when revealing more than 5 at once
- All reveals logged in `prospects.apolloPersonId` for audit
- Total credits spent today displayed at the top of the seeder page

## 10. Daily Digest

### Generation
- Cron tick at the SDR's `digestHourLocal` (default 9) in their `digestTimezone`
- Pure template body. Slot values: total / overdue / due today / due this week
- Optional one-line Haiku opener (≈$0.10/month total) — toggleable per user
- Body contains: counts grid, three big buttons (Send all, Open dashboard, Snooze all 1d), and a literal text key for keyword replies

### Email transport
- **Provider: Mailgun** (default recommendation)
  - Easy inbound parsing via Routes
  - Decent deliverability with SPF/DKIM/DMARC on `mobupps.com`
  - Cheap at SDR-scale volumes
- Subdomain: `inbound.followuper.mobupps.com` (MX → Mailgun)
- Reply-to address per digest: `digest-<userid>-<yyyymmdd>@inbound.followuper.mobupps.com`
- Magic-link buttons in the email map to `/api/magic/<token>` GET endpoints. Token-validated, single-use, 7-day expiry.

### Inbound parsing rules (`services/inboundParser.ts`)
1. Strip the quoted reply chain (everything below `On <date>, <name> wrote:` etc.). Use a small library or Mailgun's `stripped-text`.
2. Lowercase, trim, normalize whitespace.
3. Match against keyword set:
   - `send all` / `send` / `yes` → invoke send-all action for the digest payload
   - `snooze` / `snooze 1d` / `snooze 3` → snooze N days (parse digit, default 1)
   - `review` / `dashboard` / `open` → reply with a one-time magic dashboard link
   - `pause` → pause all follow-ups for this user
4. If no keyword matches, send a "did not understand — open dashboard" reply with a magic link.

### What the digest does NOT contain
- No client names
- No company names
- No last-talk notes
- No generated message previews
- These live in the dashboard behind login. This is the privacy + cost tradeoff already chosen.

## 11. UI Pages

| Path           | Purpose                                                                   | Phase |
|----------------|---------------------------------------------------------------------------|-------|
| `/`            | Today view: overdue / due today / upcoming, all channels mixed            | 1     |
| `/seeder`      | Apollo manual seeder flow                                                 | 1     |
| `/prospects`   | All prospects, filterable by channel, status, replied                     | 1     |
| `/followups`   | All follow-ups, status filters, per-row generated message preview         | 1     |
| `/channels`    | Channel connection status (mostly informational in Phase 1-2)             | 3     |
| `/accounts`    | User settings: timing windows, send hours, digest hour, reveal caps       | 1     |
| `/activity`    | Audit log: what was sent, what was clicked, what was generated, errors    | 1     |

The current `Email-Folllowuper/dashboard` is the template. Same shadcn/ui components, same Tailwind theme, same `Layout` shell. The Today view replaces the email tool's main dashboard. Followups page is structurally the same but renders chat messages instead of subject + body.

### Today view per-row component
- Channel badge (WhatsApp green, Telegram blue, Teams purple, Slack orange)
- Prospect name, company, title
- Stage badge (S1, S2, S3, …)
- Status: overdue (red), due today (amber), scheduled (grey)
- Generated message preview (collapsible)
- Primary action: **Open in WhatsApp** / **Open in Telegram** / **Send via Teams**
- Secondary: Edit, Snooze, Skip, Mark Replied

### Mark Replied flow (Mode A workaround for missing inbound)
Since Mode A cannot read inbound, the SDR is the source of truth for replies. Two paths:
1. **One-tap mark.** SDR taps "Mark Replied" on the row. Prospect is removed from the follow-up sequence. No context captured.
2. **Paste reply.** SDR opens the prospect, pastes the prospect's actual reply text, hits Save. The reply is stored in `conversations` as inbound. The next follow-up generator will see the full thread context, including the reply, and can write a contextual response. This is the high-quality path for active conversations.

## 12. Build Phases

### Phase 1 — WhatsApp end-to-end
**Goal:** SDR can seed prospects via Apollo, send first WhatsApp messages, and have follow-ups scheduled and surfaced via daily digest.

Deliverables:
- All ported lib/services modules from Email Followuper
- WhatsApp channel adapter (Mode A only)
- `channelRegister.ts` with WhatsApp rules
- Apollo client with two-step search/enrich
- Seeder page UI
- Today / Prospects / Followups / Accounts / Activity pages
- Daily digest with Mailgun inbound
- Magic-link routing
- Conversation model
- "Mark Replied" and "Paste reply" flows

Definition of done: Michael runs the tool against five real prospects, generates messages, clicks through to WhatsApp on phone or desktop, sends, gets stage-2 reminders three to seven days later, generates and sends those, marks replies, and the system tracks everything correctly.

### Phase 2 — Telegram
**Goal:** Add Telegram as a parallel channel.

Deliverables:
- Telegram channel adapter with clipboard payload handling
- UI clipboard-copy + open-link interaction (button shows "Message copied — opening Telegram")
- Telegram register block in `channelRegister.ts`
- Apollo seeder shows Telegram handle when present, with phone fallback for `t.me/+phone`
- Combined channel filter in Today view

Definition of done: same 5-prospect run, on Telegram.

### Phase 3 — Microsoft Teams
**Goal:** Add Teams send for prospects who use Teams (typically enterprise clients).

Deliverables:
- Microsoft OAuth flow (`routes/channels/teams.ts`) using Graph API delegated permissions
- Token storage in `users.microsoftRefreshToken`
- Teams channel adapter (`channelAdapters/teams.ts`):
  - Resolve recipient by email → 1:1 chat
  - Send via `POST /chats/{chatId}/messages`
  - Poll inbound on active prospects
- Teams register in `channelRegister.ts` (more formal than WhatsApp)
- Channels page UI for connect / disconnect
- "Connected" badge in Today rows when the channel is live

Definition of done: SDR connects their Microsoft account, sends a Teams message to a federated client contact, follow-up arrives on schedule, inbound reply is auto-detected and the prospect is marked replied without manual SDR action.

### Phase 4 — Slack (deferred)
**Goal:** Slack Connect channels for the subset of clients on Slack.

Deliverables: same shape as Teams but via Slack OAuth and `chat.postMessage`.

Build only after Phases 1-3 are stable for at least a month. Slack is the lowest-traffic channel for MobUpps clients.

### Phase 5+ — candidates (not committed)
- Mode B for WhatsApp (Cloud API) for high-volume markets
- Mode B for Telegram (Bot API) when a client opts into bot interaction
- Microsoft Teams Adaptive Cards for richer follow-up UI
- WeCom integration if China client base grows enough to justify the registration
- Voice agent handoff (the AI voice agent project already in flight could trigger chat follow-ups)

## 13. File Structure (Replit)

```
artifacts/
  api-server/
    src/
      app.ts
      index.ts
      cron.ts
      lib/
        anthropic.ts
        languageNativeness.ts        # ported
        channelRegister.ts            # NEW
        verticalClassifier.ts         # ported
        logger.ts
        constants.ts
      middlewares/
        auth.ts
      routes/
        index.ts
        auth.ts
        health.ts
        seeder.ts                     # NEW
        prospects.ts
        followups.ts
        digest.ts                     # NEW
        magic.ts                      # NEW
        channels/
          whatsapp.ts                 # status only in Phase 1
          telegram.ts                 # status only in Phase 2
          teams.ts                    # OAuth in Phase 3
          slack.ts                    # OAuth in Phase 4
      services/
        anthropicRetry.ts             # ported
        messageGenerator.ts           # adapted from followupGenerator
        messagePrompts.ts             # adapted from followupPrompts
        messageSummarizer.ts          # adapted from emailSummarizer
        scheduler.ts                  # adapted
        timingEngine.ts               # ported
        apolloClient.ts               # NEW
        digestSender.ts               # NEW
        inboundParser.ts              # NEW
        channelAdapters/
          whatsapp.ts                 # Phase 1
          telegram.ts                 # Phase 2
          teams.ts                    # Phase 3
          slack.ts                    # Phase 4
      scripts/
  dashboard/
    src/
      App.tsx
      main.tsx
      index.css
      lib/utils.ts
      hooks/
        use-api-key.ts
        use-current-user.ts
        use-mobile.tsx
        use-toast.ts
      components/
        layout.tsx
        api-key-provider.tsx
        ui.tsx
        ui/                           # shadcn/ui components
      pages/
        today.tsx                     # NEW (replaces dashboard.tsx)
        seeder.tsx                    # NEW
        prospects.tsx
        followups.tsx
        channels.tsx                  # NEW
        accounts.tsx
        activity-log.tsx
        not-found.tsx
db/
  schema/
    users.ts
    prospects.ts
    followups.ts
    conversations.ts                  # NEW
    magic_link_tokens.ts              # NEW
    oauth_nonces.ts
    index.ts
  index.ts
sync.sh
watch.sh
watcher.mjs
```

Sync rule (per project standard): `artifacts/api-server/src/` is the live code. After any change run `rsync --delete` from `artifacts/api-server/src/` to `source-code/src/`. Do not edit `source-code/` directly.

## 14. Agent Hardening Defaults

Apply the standing rules from the start, not after the first leak:

- Per-cycle branch + auto-merged PR; no force-push
- `ANTHROPIC_API_KEY` in Replit Secrets, never in `.replit`
- `APOLLO_API_KEY`, `MAILGUN_API_KEY`, `MICROSOFT_CLIENT_SECRET`, `SLACK_CLIENT_SECRET` same
- Diff-size gate on auto-merges
- Cost caps per cycle: max Anthropic spend per session, kill switch on env flag
- Tested backups for Postgres
- Redact secrets in logs
- Iteration ceiling on the message generator (already in place: 3 healing iterations)
- Health probe endpoint `/api/health/full` returning PASS/FAIL on: DB connection, Anthropic ping, Mailgun ping, Apollo ping
- Install manifest JSON for any agent helpers added later
- Throwaway-test before prod: every channel adapter has a dry-run mode that returns the URL or API request body without sending

## 15. UI Requirements

The dashboard ships with:
- Real-time per-task token usage count visible per follow-up generation
- Per-task USD cost shown next to each generated message
- Total session cost in the header
- Per-prospect cost rollup in the prospect detail view
- Configurable monthly cost cap per user, hard-stops generation when crossed
- Intuitive enough that a non-technical SDR can run the daily flow without terminal access

## 16. Open Decisions (need answer before Phase 1 implementation)

1. **Two-channel start order.** WhatsApp first is locked. Telegram second is locked. Confirmed.
2. **Auto-send safety in Mode A.** Mode A is by definition click-send (the SDR has to tap Send in the chat app). No auto-send option exists for Mode A. The "time-window auto-send" idea applies only when Mode B is added per channel. Phase 1 has no auto-send.
3. **Email provider.** Default: Mailgun. Alternative: AWS SES + Lambda (cheaper, more setup). **Recommendation: Mailgun for Phase 1**, revisit at scale.
4. **Digest time.** Default: per-SDR local time, configurable. Default value: 9am local. **Recommendation: ship with per-user local from day one** since SDRs span India through Israel through LATAM.
5. **Digest opener.** Pure template confirmed by user. Tiny Haiku opener requested as override after. **Final: Haiku opener on by default at $0.10/month total cost across the team.**
6. **Apollo plan tier needed.** Confirm whether MobUpps' current Apollo plan exposes `mixed_people/search` and `enrichment` to API access. If not, the seeder needs a UI scraping path or a plan upgrade. To verify before kickoff.
7. **Where the tool runs.** Replit autoscale (consistent with Email Followuper). Confirm subdomain pattern: `chat-followuper.mobupps.com` recommended, matching the existing `prospector.mobupps.com` / `followup.mobupps.com` / `retliner.mobupps.com` pattern.

## 17. Cost Estimates

### Per-message Anthropic cost (Doctrine engine)
- Draft: Sonnet 4.6, ~3000 in / 500 out → ~$0.018
- Critic: Opus 4.7, ~3500 in / 600 out → ~$0.097
- Rewriter (when triggered, ~50% of cases): Sonnet 4.6, ~3500 in / 500 out → ~$0.020
- Average per message: $0.115 - $0.135
- Per SDR at 10 messages/day: ~$1.30/day = ~$30/month
- 20 SDRs: ~$600/month for the writer

### Daily digest
- Pure template + optional Haiku opener: ~$0.10/month total

### Apollo manual mode
- Reveals only on ticked candidates (5-10/day per SDR vs. 100/day in carpet mode)
- Estimated 70-85% credit savings vs. API prospector mode

### Mailgun
- Foundation plan covers the volume comfortably for 20 SDRs

## 18. Success Criteria for Phase 1

After 30 days of Phase 1 use:
- ≥80% of generated WhatsApp messages sent by SDR without rewrite (no edit before click)
- Follow-up cadence respected: stage-2 message lands in dashboard within the configured window for ≥95% of unreplied prospects
- Daily digest open rate ≥80% (Mailgun reports it)
- Digest "send all" rate ≥40%
- Zero credit overruns on Apollo (caps held)
- Zero secrets-in-`.replit` incidents
