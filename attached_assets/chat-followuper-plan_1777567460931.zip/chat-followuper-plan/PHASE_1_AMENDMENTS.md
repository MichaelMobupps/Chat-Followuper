# Phase 1 Amendments — Porting from the old WhatsApp app

**Purpose.** The original Phase 1 ticket file remains the source of truth. This file lists three additive amendments based on a code review of the old WhatsApp Prospector (`old_whatsapp_app_source-code__3_.zip`). Each amendment specifies which ticket it modifies and what changes.

**Scope.** Additive only. No tickets are removed or reordered. The amendments port elements that are clean, proven, and aligned with the Mode A architecture. Everything Mode-B-coupled (Playwright `waSession.ts`, browser profiles, session status enums, `browserProfilePath`) is excluded by design.

---

## Amendment A — Add `daily_usage` and `action_logs` tables

**Modifies:** Ticket 1.2 (Database schema and migrations).

**Why.** The old app had two operational tables that the original Phase 1 plan understated. `daily_usage` gives per-user-per-day counters that make rate caps and dashboard headers cheap (no aggregation queries). `action_logs` formalizes what was previously called "Activity Log" — better as a real table than as a derived view, because the page needs to show events that don't map cleanly to other rows (login, channel connect, digest sent, error recovered).

**New tables:**

```ts
// db/schema/daily_usage.ts
export const dailyUsage = pgTable('daily_usage', {
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  date: date('date').notNull(),
  messagesGenerated: integer('messages_generated').notNull().default(0),
  messagesSent: integer('messages_sent').notNull().default(0),
  apolloRevealsUsed: integer('apollo_reveals_used').notNull().default(0),
  anthropicSpendUsd: numeric('anthropic_spend_usd', { precision: 10, scale: 4 }).notNull().default('0'),
  digestSent: boolean('digest_sent').notNull().default(false),
}, (table) => [
  uniqueIndex('idx_daily_usage_pk').on(table.userId, table.date),
]);
```

```ts
// db/schema/action_logs.ts
export const actionLogs = pgTable('action_logs', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').references(() => users.id, { onDelete: 'set null' }),
  prospectId: uuid('prospect_id').references(() => prospects.id, { onDelete: 'set null' }),
  followupId: integer('followup_id').references(() => followups.id, { onDelete: 'set null' }),
  actionType: varchar('action_type', { length: 50 }).notNull(),
  actionStatus: varchar('action_status', { length: 20 }).notNull(),
  durationMs: integer('duration_ms'),
  errorDetail: text('error_detail'),
  metadata: jsonb('metadata'),
  executedAt: timestamptz('executed_at').notNull().defaultNow(),
}, (table) => [
  index('idx_action_logs_user_executed').on(table.userId, table.executedAt),
  index('idx_action_logs_type').on(table.actionType),
]);
```

**`actionType` vocabulary** (open set, document the canonical values in a constants file):
- `auth.login`, `auth.logout`
- `channel.whatsapp.connected` (Phase 1 placeholder, no real OAuth)
- `seeder.org_search`, `seeder.people_search`, `seeder.reveal`, `seeder.message_generated`
- `prospect.created`, `prospect.replied`, `prospect.paused`, `prospect.skipped`
- `followup.queued`, `followup.generated`, `followup.sent`, `followup.failed`, `followup.snoozed`
- `digest.sent`, `digest.reply_handled`
- `cap.exceeded.spend`, `cap.exceeded.reveals`

**`actionStatus` values:** `success`, `failure`, `skipped`.

**Helper to add to `lib/`:**

```ts
// lib/actionLog.ts
export async function logAction(input: {
  userId: string | null;
  prospectId?: string | null;
  followupId?: number | null;
  actionType: string;
  actionStatus: 'success' | 'failure' | 'skipped';
  durationMs?: number;
  errorDetail?: string;
  metadata?: Record<string, unknown>;
}) { /* insert into action_logs */ }

export async function incrementDailyUsage(input: {
  userId: string;
  field: 'messagesGenerated' | 'messagesSent' | 'apolloRevealsUsed';
  by?: number;
}) { /* upsert pattern, see old wa_daily_usage SQL */ }

export async function addAnthropicSpend(userId: string, usd: number) { /* upsert add */ }
```

**Wiring:**
- Ticket 1.5 (Apollo client) calls `incrementDailyUsage('apolloRevealsUsed')` after every successful enrichment, and `logAction('seeder.reveal', 'success' | 'failure')`.
- Ticket 1.7 (Seeder) calls `logAction('seeder.message_generated')` after each generation, with `metadata: { costUsd, tokens }`.
- Ticket 1.8 (Scheduler) calls `logAction('followup.generated' / 'followup.failed')` per follow-up.
- Ticket 1.10 (Digest) calls `logAction('digest.sent')` and sets `dailyUsage.digestSent = true`.
- Ticket 1.11 (Cost telemetry) calls `addAnthropicSpend` instead of (or in addition to) writing to `llm_usage`. Both can coexist: `llm_usage` is the per-call ledger, `daily_usage` is the per-day rollup. Header pill reads from `daily_usage` (cheap), drilldown reads from `llm_usage`.

**Acceptance addition for Ticket 1.2:** Migration creates both tables. Helper functions in `lib/actionLog.ts` exist and are unit-tested with one insert each.

**Acceptance addition for Ticket 1.9 (Activity Log page):** Reads from `action_logs`, paginated by `executedAt DESC`, filterable by `actionType`. No more derived-view fragility.

---

## Amendment B — Port `geoGate.ts` and wire it into reveal + send paths

**Modifies:** Tickets 1.5 (Apollo client) and 1.6 (WhatsApp adapter).

**Why.** The old app's `geoGate.ts` is 141 clean lines of WhatsApp-relevant geo logic: allowed country list, phone-prefix-to-country detection, country-to-language mapping, Apollo country-name normalizer (handles `"brasil"`, `"méxico"`, `"viet nam"`, etc.). Reusing this avoids re-deriving the same regex maps and prevents WhatsApp sends to countries where the channel is the wrong fit (Japan, Korea, US — culturally email or LinkedIn markets).

**New file:** `artifacts/api-server/src/lib/geoGate.ts`

**Source:** Port the old file with two changes.
1. Make the allowed-country list configurable per channel rather than a hardcoded WhatsApp-specific set.
2. Make `getLanguageForCountry` a fallback only — if the prospect already has an explicit `language` field set (e.g., via Apollo's locale or manual override), prefer that.

**Sketch:**

```ts
// lib/geoGate.ts
export type ChannelCode = 'whatsapp' | 'telegram' | 'teams' | 'slack';

const CHANNEL_ALLOWED_COUNTRIES: Record<ChannelCode, Set<string>> = {
  whatsapp: new Set([
    // LATAM
    'BR','MX','AR','CO','CL','PE','EC','UY','PY','BO','VE',
    'CR','PA','GT','HN','SV','NI','DO',
    // Asia
    'IN','TH','VN','PH','ID','MY','SG','MM','KH','LA',
    // Middle East — added vs old app
    'AE','SA','EG','JO','LB',
    // Africa — added vs old app
    'ZA','NG','KE',
  ]),
  telegram: new Set([
    'RU','BY','UA','KZ','UZ','AM','GE','AZ',
    'IR','IL','TR',
    'IN','ID','VN','TH','BR',
  ]),
  teams: new Set(/* allowed everywhere if SDR has Microsoft auth and recipient email */),
  slack: new Set(/* allowed everywhere if Slack Connect is established */),
};

export function checkChannelGeo(channel: ChannelCode, country: string): GeoCheckResult { ... }

export function detectCountryFromPhone(phone: string): { code: string; name: string } {
  // Port lines 45-87 of old geoGate.ts unchanged. Add Middle East / Africa prefixes.
}

export function normalizeCountryCode(apolloCountry: string): string {
  // Port lines 89-128 of old geoGate.ts unchanged. Add MENA + Africa entries.
}

export function getLanguageForCountry(countryCode: string): string {
  // Port lines 130-141 of old geoGate.ts. Used as fallback only.
}
```

**Allowed-country lists are guidance, not hard locks.** A user setting per-account override (`prospects.geo_override = true`) lets MobUpps SDRs bypass the gate when they know the channel works for that specific contact (e.g., a US contact who explicitly asked to chat on WhatsApp). Default behavior is to enforce; override is opt-in per prospect.

**Wiring:**

- **Ticket 1.5 (Apollo `enrichPerson`)**: after revealing, run `checkChannelGeo('whatsapp', prospect.country)` (or whichever channel the SDR selected for this batch). If the result is `{ allowed: false }`, surface the error inline in the Seeder UI with the option to override per-row. Do **not** auto-create a prospect with a geo-mismatched channel without explicit SDR confirmation.

- **Ticket 1.6 (WhatsApp adapter `buildSendUrl`)**: enforce the same gate as a last-line guard. If a prospect with a non-whitelisted country reaches the send step, throw `GeoGateError` instead of producing a `wa.me` link. The Today view shows a clean "Channel mismatch — switch channel or override" state.

- **Ticket 1.7 (Seeder UI)**: when revealed contacts come back, show a per-row geo badge. Green if allowed for the chosen channel. Yellow with override toggle if outside the allowed list. The toggle creates an `actionLogs` entry with `actionType: 'seeder.geo_override'` so overrides are auditable.

**Acceptance addition for Ticket 1.5:** A reveal of a US-based contact with channel set to WhatsApp returns the contact data plus a `geoGate: { allowed: false, reason: '...' }` annotation. The contact is not auto-created as a prospect.

**Acceptance addition for Ticket 1.6:** Unit test confirms `buildSendUrl` for `+1...` (US) phone with channel `whatsapp` and no override flag throws `GeoGateError`. Same call with `override: true` returns a valid URL.

---

## Amendment C — Use the old app's `generateWaLink` and CSV import paths

**Modifies:** Tickets 1.6 (WhatsApp adapter) and adds optional Ticket 1.7b (CSV import).

**Why.** Two pieces of the old app are battle-tested and trivial to reuse: the WhatsApp link builder and the CSV import flow. No reason to rewrite.

### C.1 — `generateWaLink` into the WhatsApp adapter

**Source (old `messageGenerator.ts` lines 197-201):**

```ts
export function generateWaLink(phone: string, message: string): string {
  const cleanPhone = phone.replace(/[^0-9]/g, '');
  const encodedMessage = encodeURIComponent(message);
  return `https://wa.me/${cleanPhone}?text=${encodedMessage}`;
}
```

**Use as the body of `whatsappAdapter.modeA.buildSendUrl`** in Ticket 1.6. Three minor adjustments:

1. Phone input is already normalized to E.164 by `formatPhone` upstream (libphonenumber-js), so the regex strip is just defense-in-depth, not the primary normalizer.
2. Wrap with the geo gate guard from Amendment B before returning.
3. Return the canonical `{ url, clipboardText? }` shape from the adapter contract; `clipboardText` stays `undefined` for WhatsApp (URL pre-fills).

```ts
// services/channelAdapters/whatsapp.ts (excerpt, post-amendments)
buildSendUrl(phoneE164: string, message: string, opts?: { override?: boolean }): { url: string; clipboardText?: string } {
  const country = detectCountryFromPhone(phoneE164).code;
  const gate = checkChannelGeo('whatsapp', country);
  if (!gate.allowed && !opts?.override) {
    throw new GeoGateError(gate.reason);
  }
  const digits = phoneE164.replace(/[^0-9]/g, '');
  const encoded = encodeURIComponent(message);
  return { url: `https://wa.me/${digits}?text=${encoded}` };
}
```

### C.2 — Optional Ticket 1.7b: CSV import for prospects

**Why optional.** Phase 1 ships with the Apollo seeder as the primary path. CSV import is the escape hatch for: SDRs returning from a conference with a contact list, lists exported from another tool, one-off pre-built campaigns, and sanity-checking the pipeline without burning Apollo credits.

**Source (old `routes/contacts.ts` lines ~77-180, the `/import` handler).** Port the multipart-form + PapaParse pattern. Modernize to the new schema field names.

**New endpoint:** `POST /api/seeder/prospects/import-csv`

**Expected CSV columns** (case-insensitive, all optional except `phone`):
- `phone` (E.164 or local format with country hint)
- `firstName`, `lastName` OR `prospectName`
- `company`, `title`, `vertical`, `country`, `language`
- `notes` (free text → `prospects.contextNotes`)
- `channel` (defaults to `whatsapp` for Phase 1; values: `whatsapp`, `telegram`, etc. — Phase 2+ honors others)

**Behavior:**
- Parse with PapaParse, header row required.
- For each row: normalize phone with libphonenumber-js, run geo gate against `channel`, dedupe against existing `prospects(userId, phone)` UNIQUE.
- Preview mode (`dryRun: true`): return per-row `{ status, errors[] }` without inserting. SDR reviews, hits Confirm.
- Commit mode: insert valid rows, return summary `{ inserted, duplicates, geoFailed, invalid, errors[] }`.
- After successful import, the rows go straight into the same Doctrine generation step as the Apollo path — same UI, same "Generate first messages" button.

**Action log entries:** `seeder.csv_import_preview`, `seeder.csv_import_committed`, with `metadata: { rowCount, ... }`.

**UI:** Add a "Import CSV" button next to the seeder's organization search. Opens a drawer with file upload, channel selector, dry-run preview table, and Confirm button.

**Acceptance for Ticket 1.7b:**
- Importing a 50-row CSV with two duplicates, three US numbers (geo-fail for WhatsApp), and one malformed phone returns: `{ inserted: 44, duplicates: 2, geoFailed: 3, invalid: 1 }`. Errors are surfaced per-row.
- Imported rows can have first messages generated immediately afterwards, no manual seeder step needed.
- Setting `channel: 'telegram'` in Phase 1 stores the row but disables the "Generate first messages" button with "Telegram support arrives in Phase 2" tooltip.

**Decision:** Build Ticket 1.7b only if Phase 1 ships with time to spare, or as the first item in Phase 1.5. Not blocking the rest of Phase 1.

---

## Things examined and explicitly NOT ported

For the record, so this isn't revisited:

- **`waSession.ts` (Playwright + WhatsApp Web automation).** Mode B path. Conflicts with autoscale, conflicts with Mode A architecture, conflicts with ban-risk concerns we already discussed.
- **`wa-browser-profiles/` directory.** Playwright artifact, irrelevant.
- **`doctrinePrompts.ts` from the old app.** Replaced by the email tool's prompts plus new `channelRegister.ts`. The old prompts are visibly weaker — no language nativeness module, no proper `bestOverall` healing loop, no full meta-language guard.
- **Hardcoded multilingual fallback templates in old `messageGenerator.ts`.** Explicitly excluded by Phase 1 cross-cutting rule 5: "No hard-coded multilingual fallback templates in `messageGenerator`. Failure is a real failure surfaced to the SDR."
- **`wa_session_status` enum and `browserProfilePath` column on users.** Mode B columns. Phase 1 doesn't need them; Phase 5+ adds them only if Mode B for WhatsApp gets built.
- **The 660-line monolithic `App.tsx`.** No shadcn/ui, no proper routing, hard to extend across four channels. New build uses the email tool's dashboard scaffold.
- **`index.ts.bak`.** Leftover backup.

---

## Net effect of these amendments

- **Ticket 1.2** gains two tables and a helper file. ~30 minutes added to the ticket.
- **Ticket 1.5** gains a geo gate check on enrichment. ~15 minutes.
- **Ticket 1.6** uses the proven URL builder and adds a geo gate guard. Saves time, doesn't add it.
- **Ticket 1.7b (new, optional)** is a self-contained ticket worth 1-2 sessions if scheduled. Not blocking Phase 1.

No tickets reordered. No tickets removed. No architecture changes.
