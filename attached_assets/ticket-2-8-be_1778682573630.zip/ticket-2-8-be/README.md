# ticket-2-8-be — v2

Bulk manual prospect ingest endpoint, BE only. WhatsApp + Telegram.

## What ships

- `POST /api/prospects/manual-ingest/bulk` — accepts 1..200 contacts per request, partial-success response `{accepted: Prospect[], rejected: [{index, identifier, error, detail?}]}`. Per-row identifier routing mirrors the post-2.9 single-ingest handler exactly.
- `ACTION_TYPES.manualIngestBulk` enum entry. One bulk-request audit row per call; per-accepted-row `manualIngestSingle` rows with `metadata.viaBulk = true`.
- `express.json()` body-parser limit raised from 100KB (default) to 2MB. Needed for the 200-row schema-max payload (~1.1MB worst case). Affects all `/api` routes; Apollo webhook unaffected (mounted before json parser).

## What it does NOT touch

FE (ships as `ticket-2-8-fe` next). Rate limiting (punted). Async queueing (punted). DB schema (none needed). Single-ingest behavior is unchanged.

## How to ship

From the Replit shell at the repo root:

```bash
set -e
cd "$(git rev-parse --show-toplevel)"
unzip -o /tmp/ticket-2-8-be.zip -d /tmp/
bash /tmp/ticket-2-8-be/apply.sh
```

Expect 5 OKs from `[1/5]` through `[5/5]`. Then `restart_workflow` on the api-server workflow. Paste the workflow startup log here.

## Smoke matrix (run after restart_workflow)

Auth model: Chat Followuper uses **cf_session cookie**, not bearer tokens. Extract `cf_session` from a logged-in browser tab — DevTools → Application → Cookies → `cf_session` row → Value — and export it:

```bash
export CF_SESSION='<paste-value-here>'
```

### Probe 1 — Mount probe (no auth → 401 PASS)

```bash
curl -sS -o /dev/null -w 'HTTP %{http_code}\n' \
  -X POST http://localhost:80/api/prospects/manual-ingest/bulk \
  -H 'Content-Type: application/json' \
  -d '{"channel":"whatsapp","contacts":[]}'
```

PASS = `HTTP 401`. Confirms the route is mounted and `requireAuth` is gating it.

### Probe 2 — Validation (empty array → 400 PASS)

```bash
curl -sS -w '\nHTTP %{http_code}\n' \
  -X POST http://localhost:80/api/prospects/manual-ingest/bulk \
  -H "Cookie: cf_session=$CF_SESSION" \
  -H 'Content-Type: application/json' \
  -d '{"channel":"whatsapp","contacts":[]}'
```

PASS = `HTTP 400` with `error: "invalid_body"` (Zod `min(1)` fired).

### Probe 3 — WhatsApp happy path (200 PASS)

```bash
curl -sS -w '\nHTTP %{http_code}\n' \
  -X POST http://localhost:80/api/prospects/manual-ingest/bulk \
  -H "Cookie: cf_session=$CF_SESSION" \
  -H 'Content-Type: application/json' \
  -d '{"channel":"whatsapp","contacts":[{"firstName":"BulkTestWA","phone":"+972501111111","company":"BulkCoWA","ticker":"mobile"}]}'
```

PASS = `HTTP 200`, `accepted.length === 1`, `rejected.length === 0`, `accepted[0].source_mode === "manual"`.

### Probe 4 — Telegram with @handle (200 PASS, handle stored)

```bash
curl -sS -w '\nHTTP %{http_code}\n' \
  -X POST http://localhost:80/api/prospects/manual-ingest/bulk \
  -H "Cookie: cf_session=$CF_SESSION" \
  -H 'Content-Type: application/json' \
  -d '{"channel":"telegram","contacts":[{"firstName":"BulkTestTGHandle","phone":"@bulktestuser","company":"BulkCoTG","ticker":"web"}]}'
```

PASS = `HTTP 200`, `accepted[0].telegram_handle === "bulktestuser"` (@ stripped), `accepted[0].phone === null`.

### Probe 5 — Telegram with E.164 (200 PASS, phone stored)

```bash
curl -sS -w '\nHTTP %{http_code}\n' \
  -X POST http://localhost:80/api/prospects/manual-ingest/bulk \
  -H "Cookie: cf_session=$CF_SESSION" \
  -H 'Content-Type: application/json' \
  -d '{"channel":"telegram","contacts":[{"firstName":"BulkTestTGPhone","phone":"+972502222222","company":"BulkCoTG2","ticker":"web"}]}'
```

PASS = `HTTP 200`, `accepted[0].phone === "+972502222222"`, `accepted[0].telegram_handle === null`.

### Probe 6 — Partial success (1 valid + 1 invalid → 200 PASS, mixed result)

```bash
curl -sS -w '\nHTTP %{http_code}\n' \
  -X POST http://localhost:80/api/prospects/manual-ingest/bulk \
  -H "Cookie: cf_session=$CF_SESSION" \
  -H 'Content-Type: application/json' \
  -d '{"channel":"whatsapp","contacts":[{"firstName":"BulkTestWA2","phone":"+972503333333","company":"BulkCoWA2","ticker":"mobile"},{"firstName":"BulkTestBad","phone":"not-a-phone","company":"BulkCoBad","ticker":"mobile"}]}'
```

PASS = `HTTP 200`, `accepted.length === 1`, `rejected.length === 1`, `rejected[0].error === "invalid_identifier"`, `rejected[0].index === 1`.

## Cleanup after smoke

Delete the 4 test prospects (BulkTestWA, BulkTestWA2, BulkTestTGHandle, BulkTestTGPhone) via the dashboard, or:

```bash
# For each accepted.id collected from probes 3-6:
curl -sS -X DELETE "http://localhost:80/api/prospects/$ID" \
  -H "Cookie: cf_session=$CF_SESSION"
```

## Rollback (if needed)

Patches are idempotent forward-only. To roll back:

```bash
# Revert the three patched files from the last git commit:
git checkout HEAD -- \
  lib/db/src/schema/action_logs.ts \
  artifacts/api-server/src/routes/prospects.ts \
  artifacts/api-server/src/app.ts

# Then rebuild lib/db and re-sync source-code:
pnpm exec tsc -b lib/db
bash scripts/sync-source-code.sh
```
