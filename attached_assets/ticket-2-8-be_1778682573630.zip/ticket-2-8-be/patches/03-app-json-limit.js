#!/usr/bin/env node
// ──────────────────────────────────────────────────────────────────────────
// Patch 03: raise the global express.json() body-parser limit from the
// 100KB default to 2MB so the 200-row bulk endpoint can accept realistic
// CSV-paste payloads.
//
// Sizing rationale (recorded so future maintainers can audit):
//   200 rows × ~5500B/row schema-max = ~1.1MB
//   2MB gives ~80% headroom above schema-max.
//
// Scope of side-effects: every route under app.use("/api", ...) now
// accepts up to 2MB JSON payloads, not just the bulk endpoint. The
// Apollo webhook is unaffected — it is mounted before express.json()
// and uses express.raw for HMAC-byte preservation.
//
// Idempotent — detects the limit option in the call and skips.
// ──────────────────────────────────────────────────────────────────────────

const fs = require("fs");
const path = require("path");

const REPO_ROOT = process.cwd();
const FILE = path.join(REPO_ROOT, "artifacts/api-server/src/app.ts");

const MARKER = "express.json({ limit:";
const ANCHOR = "app.use(express.json());";
const REPLACEMENT = "app.use(express.json({ limit: \"2mb\" }));";

const src = fs.readFileSync(FILE, "utf8");

if (src.includes(MARKER)) {
  console.log("  03-app-json-limit: already applied, skipping");
  process.exit(0);
}

if (!src.includes(ANCHOR)) {
  console.error("  03-app-json-limit: anchor not found");
  console.error("    expected: " + JSON.stringify(ANCHOR));
  process.exit(1);
}

// Count occurrences to be sure we replace the right one. The default
// app.ts has exactly one `app.use(express.json());` call.
const occurrences = src.split(ANCHOR).length - 1;
if (occurrences !== 1) {
  console.error(
    "  03-app-json-limit: expected exactly 1 occurrence of anchor, found " +
      occurrences,
  );
  process.exit(1);
}

const updated = src.replace(ANCHOR, REPLACEMENT);

if (updated === src) {
  console.error("  03-app-json-limit: replace was a no-op (unexpected)");
  process.exit(1);
}

fs.writeFileSync(FILE, updated);
console.log("  03-app-json-limit: applied");
