#!/usr/bin/env node
// ──────────────────────────────────────────────────────────────────────────
// Patch 02: insert the bulk manual-ingest handler into routes/prospects.ts
// immediately before `export default router;`.
//
// Idempotent — detects the ticket marker on the inserted block.
// ──────────────────────────────────────────────────────────────────────────

const fs = require("fs");
const path = require("path");

const REPO_ROOT = process.cwd();
const FILE = path.join(
  REPO_ROOT,
  "artifacts/api-server/src/routes/prospects.ts",
);

const MARKER = "Bulk manual ingest — Ticket 2.8-BE";
const ANCHOR = "export default router;";

let src = fs.readFileSync(FILE, "utf8");

if (src.includes(MARKER)) {
  console.log("  02-route-prospects: already applied, skipping");
  process.exit(0);
}

if (!src.includes(ANCHOR)) {
  console.error("  02-route-prospects: anchor not found");
  console.error("    expected: " + JSON.stringify(ANCHOR));
  process.exit(1);
}

// All symbols the new block uses are already imported at the top of
// routes/prospects.ts (db, prospectsTable, actionLogsTable, ACTION_TYPES,
// usersTable, type Prospect, requireAuth, detectCountry, and, eq, z,
// ZodError, Request, Response) and the section above defines the local
// helpers we depend on (MANUAL_INGEST_CHANNELS, TICKERS, PHONE_RE,
// TELEGRAM_HANDLE_RE, tickerToCoarseVertical, zodErrorToHttp). No
// import-block edits required.

const contentPath = path.join(
  process.env.TICKET_DIR || path.join(__dirname, ".."),
  "content",
  "bulk-route-additions.ts.txt",
);
if (!fs.existsSync(contentPath)) {
  console.error("  02-route-prospects: content file missing");
  console.error("    expected: " + contentPath);
  process.exit(1);
}
const additions = fs.readFileSync(contentPath, "utf8");

// Insert with a blank line buffer so the new block visually separates
// from the existing export.
src = src.replace(ANCHOR, additions.trimEnd() + "\n\n" + ANCHOR);

fs.writeFileSync(FILE, src);
console.log("  02-route-prospects: applied");
