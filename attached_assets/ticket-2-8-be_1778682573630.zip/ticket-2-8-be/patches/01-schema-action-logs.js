#!/usr/bin/env node
// ──────────────────────────────────────────────────────────────────────────
// Patch 01: add manualIngestBulk to ACTION_TYPES.
// Idempotent — re-running after success is a no-op.
// ──────────────────────────────────────────────────────────────────────────

const fs = require("fs");
const path = require("path");

const REPO_ROOT = process.cwd();
const FILE = path.join(REPO_ROOT, "lib/db/src/schema/action_logs.ts");

const MARKER = 'manualIngestBulk: "prospect.manual_ingest.bulk"';
const ANCHOR = '  manualIngestToggle: "user.manual_ingest_toggle",';

const INSERTION = `
  // Ticket 2.8-BE — bulk manual prospect ingest.
  //
  // manualIngestBulk: SDR submitted a multi-row manual ingest payload via
  // POST /api/prospects/manual-ingest/bulk. Recorded once per request,
  // independent of how many rows succeeded. metadata.rowCount /
  // .acceptedCount / .rejectedCount give the request-level breakdown.
  // Per-accepted-row audit rows are still emitted under manualIngestSingle
  // (with metadata.viaBulk = true) so per-prospect audit trails stay
  // queryable by the existing single-ingest action type.
  manualIngestBulk: "prospect.manual_ingest.bulk",`;

const src = fs.readFileSync(FILE, "utf8");

if (src.includes(MARKER)) {
  console.log("  01-schema-action-logs: already applied, skipping");
  process.exit(0);
}

if (!src.includes(ANCHOR)) {
  console.error("  01-schema-action-logs: anchor not found");
  console.error("    expected: " + JSON.stringify(ANCHOR));
  process.exit(1);
}

const updated = src.replace(ANCHOR, ANCHOR + INSERTION);

if (updated === src) {
  console.error("  01-schema-action-logs: replace was a no-op (unexpected)");
  process.exit(1);
}

fs.writeFileSync(FILE, updated);
console.log("  01-schema-action-logs: applied");
