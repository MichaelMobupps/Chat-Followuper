#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────────────────────
# ticket-2-8-be — Bulk manual prospect ingest (WhatsApp + Telegram, BE) — v2
# ──────────────────────────────────────────────────────────────────────────
#
# v2 deltas vs v1:
#   - Adds patch 03 raising express.json() limit to 2MB (the v1 100KB
#     default would have 413'd realistic 200-row payloads).
#   - Smoke matrix uses cf_session cookie auth (Chat Followuper's actual
#     auth model) rather than ADDON_API_KEY (which is a Doctrine Follow-up
#     pattern and does not exist in this codebase).
#
# Idempotent. Re-running after a successful run is a no-op on the patches
# (each detects its own marker) and re-runs the tsc/typecheck/sync steps
# cheaply.
#
# Pipeline:
#   1. Pre-flight: required files exist; patch anchors present; post-2.9
#      single-ingest helpers are in place (the bulk handler reuses them).
#   2. Apply three patches (action_logs enum + route handler + json limit).
#   3. Rebuild lib/db composite project so consumers see the new
#      ACTION_TYPES.manualIngestBulk key.
#   4. Typecheck @workspace/api-server.
#   5. Sync artifacts/api-server/src → source-code/ via repo script.
#
# Exits 0 on full success, non-zero on any failure.
#
# No drizzle migration: this ticket adds one TS enum entry to ACTION_TYPES
# (a plain const) and one new router handler. The action_type column is
# varchar(50) with no check constraint, so no DB-side schema change is
# needed.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(git rev-parse --show-toplevel)"
cd "$REPO_ROOT"

export TICKET_DIR="$SCRIPT_DIR"

# ─── 1/5 Pre-flight ───────────────────────────────────────────────────────

echo "[1/5] Pre-flight checks..."

REQUIRED_FILES=(
  "lib/db/src/schema/action_logs.ts"
  "artifacts/api-server/src/routes/prospects.ts"
  "artifacts/api-server/src/app.ts"
  "scripts/sync-source-code.sh"
)

for f in "${REQUIRED_FILES[@]}"; do
  if [ ! -f "$f" ]; then
    echo "  MISSING required file: $f" >&2
    exit 1
  fi
done

# Anchor presence checks. Each patch verifies its own anchor at apply
# time too; failing fast here keeps the error message close to the cause.
# Soft-fail for the json-limit anchor: if patch 03 already ran in a prior
# attempt, the original ANCHOR is gone and replaced by the post-patch
# form. Check for the post-patch marker before erroring.

check_anchor() {
  local file="$1"
  local needle="$2"
  local post_marker="${3:-}"
  if grep -qF "$needle" "$file"; then
    return 0
  fi
  if [ -n "$post_marker" ] && grep -qF "$post_marker" "$file"; then
    echo "  $file: post-patch marker present, proceeding"
    return 0
  fi
  echo "  MISSING anchor in $file" >&2
  echo "    expected: $needle" >&2
  exit 1
}

check_anchor "lib/db/src/schema/action_logs.ts" \
  'manualIngestToggle: "user.manual_ingest_toggle",'
check_anchor "artifacts/api-server/src/routes/prospects.ts" \
  'export default router;'
check_anchor "artifacts/api-server/src/app.ts" \
  'app.use(express.json());' \
  'express.json({ limit:'

# Verify the post-2.9 single-ingest helpers are present. The bulk handler
# reuses MANUAL_INGEST_CHANNELS, TICKERS, TELEGRAM_HANDLE_RE, and
# tickerToCoarseVertical at module scope. If any are missing the bulk
# handler will not compile.
declare -a REQUIRED_SYMBOLS=(
  'MANUAL_INGEST_CHANNELS = ["whatsapp", "telegram"] as const'
  'const TICKERS = ["web", "mobile"] as const'
  'const TELEGRAM_HANDLE_RE'
  'function tickerToCoarseVertical'
)

for needle in "${REQUIRED_SYMBOLS[@]}"; do
  if ! grep -qF "$needle" "artifacts/api-server/src/routes/prospects.ts"; then
    echo "  MISSING required symbol in routes/prospects.ts" >&2
    echo "    expected: $needle" >&2
    echo "    (this ticket assumes the 2.9 single-ingest handler is in place)" >&2
    exit 1
  fi
done

echo "  ok"

# ─── 2/5 Patches ──────────────────────────────────────────────────────────

echo "[2/5] Applying patches..."

# Parse-check each patch before running. node --check catches syntax
# errors without executing.
for p in \
  "$SCRIPT_DIR/patches/01-schema-action-logs.js" \
  "$SCRIPT_DIR/patches/02-route-prospects.js" \
  "$SCRIPT_DIR/patches/03-app-json-limit.js"; do
  node --check "$p"
done

node "$SCRIPT_DIR/patches/01-schema-action-logs.js"
node "$SCRIPT_DIR/patches/02-route-prospects.js"
node "$SCRIPT_DIR/patches/03-app-json-limit.js"

echo "  ok"

# ─── 3/5 Composite rebuild ────────────────────────────────────────────────

echo "[3/5] Rebuilding lib/db composite project..."

pnpm exec tsc -b lib/db

echo "  ok"

# ─── 4/5 Consumer typecheck ───────────────────────────────────────────────

echo "[4/5] Typechecking @workspace/api-server..."

pnpm --filter @workspace/api-server run typecheck

echo "  ok"

# ─── 5/5 Sync source-code/ ────────────────────────────────────────────────

echo "[5/5] Syncing source-code/..."

bash scripts/sync-source-code.sh

echo "  ok"

echo ""
echo "ticket-2-8-be v2: apply.sh completed successfully"
echo ""
echo "Next: restart_workflow on api-server, then paste startup log."
echo "Smoke matrix (6 probes, cf_session cookie auth) is in the ticket README."

exit 0
