/**
 * Channel register — chat-specific writing rules per channel, plus
 * mode-specific shape rules (prospector first-message vs followuper).
 *
 * Mirrors the architecture of `languageNativeness.ts`. Each (channel × mode)
 * combination produces a writer rule block (injected into writer + rewriter
 * prompts) and a critic rule block (injected into the critic prompt).
 *
 * Two modes:
 *   - "prospector" — first cold message to a prospect on this channel.
 *     Carries the full doctrine (WHY → VALIDATION+HOW → CTA), compressed
 *     for chat. ~5-7 sentences max.
 *   - "followuper" — every subsequent message in an ongoing thread.
 *     Compressed shape: prior-contact reference + new value point + soft CTA.
 *     2-3 sentences max. Requires conversation context — no context, no message.
 *
 * Phase 1 implements WhatsApp fully. Telegram, Teams, and Slack return
 * placeholder strings until their respective phases.
 */

export type ChannelCode = "whatsapp" | "telegram" | "teams" | "slack";
export type GenerationMode = "prospector" | "followuper";

export function isChannelCode(value: string): value is ChannelCode {
  return ["whatsapp", "telegram", "teams", "slack"].includes(value);
}

// ─────────────────────────────────────────────────────────────────
// WHATSAPP — Prospector mode (first cold message)
// ─────────────────────────────────────────────────────────────────

const WHATSAPP_PROSPECTOR_WRITER_RULES = `WHATSAPP — FIRST COLD MESSAGE — STRUCTURAL RULES

This is the first message to this prospect on WhatsApp. The prospect does not
know us yet. The message must carry the full doctrine, compressed for chat:

DOCTRINE STRUCTURE (compressed for chat — the full email version is 5 sections;
this version merges them into 5-7 sentences total):

1. GREETING — One short line. Use the GREETING FORMAT rules from the language
   nativeness block (or "Hi {FirstName}," for English / Latin-script casual
   markets). Never "Dear", never "Good morning", never "I hope this finds you
   well", never an emoji-laden opener.

2. WHY — Sentence 1 (the line right after the greeting). Prospect-led: open
   with their brand, vertical, market, or a specific peer behavior.
   ABSOLUTELY FORBIDDEN openers:
     "Our ...", "We ...", "At MobUpps ...", "MobUpps is ...", "I'm reaching out".
   These flip the message from prospect-led to self-referential and break the
   doctrine. The first content word should be about the prospect or their market.

3. VALIDATION + HOW — Sentence 2-3 (one or two sentences). Merge what we can
   deliver with how we deliver it:
     - One specific volume or quality signal (real number, never a range —
       say "above 12%" not "8-15%", say "400+ daily" not "150-400")
     - One concrete vertical-native mechanic — language and metrics that match
       the prospect's exact sub-vertical. Generic "we optimize campaigns" or
       "we drive results" is forbidden.
     - One competitor or peer name-drop where it makes the claim concrete.

4. CTA — Final sentence. One soft question. Low-friction. No calendar links.
   Max 15 words. One question mark, never an exclamation mark.

LENGTH:
- 5-7 sentences total including greeting.
- Hard cap at 7 sentences.

FORMAT:
- No subject line. WhatsApp has no subject field. The "subject" field in your
  JSON output should be a brief 3-5 word topic tag for internal tracking only.
- No signature block. No "Best, Michael" or "Cheers,". The sender's name is
  shown automatically by WhatsApp.
- Plain text only. No bullet lists. No markdown. No headers.
- Always use the "%" symbol for percentages. NEVER spell out "percent",
  "Prozent", "процент", "por ciento", "pour cent", "phần trăm", "퍼센트",
  "パーセント", "เปอร์เซ็นต์".
- No em dashes. No en dashes. Use commas or periods.
- No snake_case tokens (e.g. "funded_account" is forbidden, "funded account"
  is correct).
- No bracketed editorial notes ([Verify X], [Check Y]) — these leak from
  rewriting passes and must never appear.

TONE:
- Real human typing on a phone. Casual-professional.
- No corporate buzzwords: "synergy", "leverage", "delve", "seamless",
  "holistic", "game-changer", "unlock potential", "navigate the landscape".
- No spam phrases: "circling back", "touching base", "hope you are well",
  "I trust this finds you well", "would love to", "wanted to reach out",
  "I just wanted to".
- No "X, not Y" constructions. Rephrase as positive specification.
   BAD: "Real CPI optimization, not vanity bidding."
   GOOD: "Real CPI optimization tied to confirmed installs."

EMOJIS:
- 0 emojis in conservative markets (Japan, Korea, Germany, Nordics, Russia, China).
- 0-1 emoji in friendly markets (LATAM, India, Southeast Asia, Middle East, Africa).
- When in doubt, zero. An over-emojified WhatsApp message reads worse than a plain one.

COUNTRY-MATCHED REFERENCES:
- All competitor names, peer brands, market data, and regulatory references MUST
  match the prospect's country. NEVER default to US references for non-US
  prospects. Indian prospect = Indian peers, Indian metrics. Brazilian
  prospect = Brazilian peers. Etc.

VERTICAL-NATIVE TERMINOLOGY (CRITICAL):
- Use the exact event terminology and metrics the prospect's sub-vertical uses.
- Gaming UA prospects use IAP, payer conversion, ARPDAU, D7 ROAS, retention.
- Fintech prospects use funded account, first deposit, KYC.
- E-commerce prospects use confirmed purchase, AOV, ROAS.
- Telehealth prospects use consultation booking, appointment.
- Cross-vertical leakage (gaming jargon in fintech, subscription jargon in
  e-commerce, etc.) is a critical failure.`;

const WHATSAPP_PROSPECTOR_CRITIC_RULES = `WHATSAPP CHANNEL REGISTER CHECK — PROSPECTOR MODE:

Score channel_register_match 1-5 against these criteria for the FIRST COLD
WhatsApp message:

Score 5 (passes):
- 5-7 sentences total in the body
- Greeting is exactly one short line, language-appropriate
- WHY (sentence 1) starts prospect-led — first content word is about the
  prospect, their brand, their vertical, or their market
- VALIDATION + HOW (sentences 2-3) include one specific volume number,
  one vertical-native mechanic, and ideally one peer/competitor reference
- CTA (final sentence) is one soft question, max 15 words
- No subject line attempted
- No signature / sign-off
- Plain text, no markdown, no bullets
- No spam phrases ("circling back", "touching base", etc.)
- No em dashes
- "%" symbol used (not "percent" / "Prozent" / etc.)
- No "X, not Y" constructions
- All references country-matched (no US peers for non-US prospects)
- Vertical-native terminology throughout

Score 3-4 (minor issues, can pass with one nit):
- 8 sentences but otherwise tight
- One small spam phrase that slipped in
- Greeting slightly informal for the market

Score 1-2 (FAIL — needs_rewrite must be true):
- 9+ sentences (reads like an email)
- Has a signature block
- Greeting is missing or wrong-language
- WHY starts with "Our ...", "We ...", "At MobUpps ...", or any self-referential opener
- Volume given as a range ("8-15%") instead of one specific number
- US references in a non-US-prospect message
- Generic mechanics ("we optimize campaigns", "we drive results")
- Wrong-vertical terminology (e.g., gaming jargon in fintech message)
- Multiple CTAs or multiple question marks
- Bullet points or numbered lists
- Markdown formatting
- Subject line attempted in the body
- Em dashes present
- Spelled-out percentage
- "X, not Y" construction present

If channel_register_match < 3, needs_rewrite MUST be true.`;

// ─────────────────────────────────────────────────────────────────
// WHATSAPP — Followuper mode (subsequent messages in thread)
// ─────────────────────────────────────────────────────────────────

const WHATSAPP_FOLLOWUPER_WRITER_RULES = `WHATSAPP — FOLLOW-UP MESSAGE — STRUCTURAL RULES

This is a follow-up to a prior conversation on WhatsApp. The prospect already
knows who we are. Your only valid input is the prior conversation. Every
value point in this follow-up must trace to something visible in that
conversation — what we said before, or what the prospect said back.

ABSOLUTE RULE — CONTEXT GROUNDING:
- You will receive the full prior conversation (outbound and inbound) plus
  any context notes the SDR pasted. Build the follow-up entirely from that
  material.
- Do NOT invent new claims, new numbers, or new competitor references that
  weren't in the prior thread.
- Do NOT re-introduce yourself or MobUpps. The prospect already knows us.
- If the prior conversation is empty or only contains a generic greeting,
  the upstream code should have refused to call you. If you somehow received
  empty context, return a short generic check-in rather than fabricating.

FOLLOW-UP STRUCTURE — 2-3 sentences total:

1. PRIOR-CONTACT REFERENCE (sentence 1) — Reference the prior thread in the
   FIRST sentence. Keep it brief and concrete. Examples:
     "Following up on the MAFO numbers I sent."
     "Quick follow-up on the Lazada CPS angle we discussed."
     "Circling back on the casual UA conversation."
   The reference must name the SPECIFIC topic, not be vague. Do NOT write
   "Following up on my detailed message from April 24th about the MAFO
   performance benchmarks across our gaming clients in Brazil" — too long
   for a chat thread.

2. NEW VALUE POINT (sentence 2, optional sentence 3) — One thing they did
   not engage with from the prior message, expanded with fresh evidence,
   OR a response to something they said back. Stage strategy rotation:
     - Stage 1: Add a new insight, data point, or relevant industry development.
     - Stage 2: Shift angle — reference a competitor move or market trend.
     - Stage 3: Direct and brief, give them an easy out ("if timing isn't
       right, no worries").
     - Stage 4+: Continue rotating fresh angles. Each stage must bring
       something genuinely new. NEVER repeat an angle from a previous stage.

3. SOFT CTA (final sentence) — One soft question. Lower friction than the
   first message's CTA. Examples: "Worth a quick test on a small segment?",
   "Open to a 15-min call this week?", "If timing is off, no worries — let
   me know either way?"

LENGTH:
- 2-3 sentences MAXIMUM. Hard cap.
- A 4-sentence follow-up reads like spam on WhatsApp.

FORMAT — same rules as the first message:
- No subject line, no signature, plain text only.
- "%" symbol always. No em dashes. No snake_case. No markdown.
- No bracketed editorial notes.
- One question mark maximum. No exclamation marks.

TONE — same:
- Real human texting. Casual-professional.
- No "circling back" used vaguely (you may write "circling back on the
  Lazada CPS angle" because that names a specific topic; you may NOT write
  "just circling back" alone — that's a spam signal).
- No "touching base", "hope you are well", "would love to".
- No corporate buzzwords ("synergy", "leverage", "delve", "seamless", etc.).
- No "X, not Y" constructions.

CONTEXT-USE PATTERN:
- If the prior message included a specific number, reference it: "the 12% lift
  I mentioned" — don't repeat the full pitch.
- If the prospect replied with a question, the follow-up addresses that question.
- If the prospect asked for materials (case study, deck), the follow-up delivers
  or references delivery of those materials.
- If the prior message named a competitor, you can update on that competitor's
  recent move or pivot to a different angle entirely.`;

const WHATSAPP_FOLLOWUPER_CRITIC_RULES = `WHATSAPP CHANNEL REGISTER CHECK — FOLLOWUPER MODE:

Score channel_register_match 1-5 against these criteria for FOLLOW-UP messages:

Score 5 (passes):
- 2-3 sentences total
- Sentence 1 explicitly references the prior conversation with a SPECIFIC
  topic name (not vague "following up")
- Sentence 2-3 introduces a NEW angle or addresses prospect's reply,
  derived from the prior conversation's content
- No re-introduction of MobUpps or the sender
- Soft CTA, one question mark
- No spam phrases, no em dashes, no markdown, "%" symbol used
- All claims traceable to the prior conversation (no invented numbers
  or new competitor references)

Score 3-4 (minor issues, can pass with one nit):
- 4 sentences but otherwise on register
- Reference is slightly vague ("following up on our chat" without naming
  the topic)

Score 1-2 (FAIL — needs_rewrite must be true):
- 5+ sentences (too long for chat follow-up)
- No reference to prior contact in the first sentence
- Re-introduces MobUpps or the sender
- Repeats the full pitch from the prior message
- Invents new claims or numbers not in the prior conversation
- Uses spam phrases ("just circling back", "touching base", "would love to")
- Has em dashes, signature block, or markdown
- Multiple question marks or any exclamation marks
- "X, not Y" construction present

ALSO score context_grounding 1-5 (followup mode only):

Score 5: every claim in the follow-up traces to something in the prior
conversation (what we said, what they replied, or the SDR's context notes).

Score 3-4: most claims traceable; one minor unsupported detail.

Score 1-2: introduces new claims, numbers, competitors, or facts not
present in the prior conversation. This is fabrication. needs_rewrite MUST
be true.

If channel_register_match < 3 OR context_grounding < 3, needs_rewrite MUST be true.`;

// ─────────────────────────────────────────────────────────────────
// Future channels (placeholders for Phases 2-4)
// ─────────────────────────────────────────────────────────────────

const TELEGRAM_PROSPECTOR_WRITER_RULES = ""; // Phase 2
const TELEGRAM_PROSPECTOR_CRITIC_RULES = ""; // Phase 2
const TELEGRAM_FOLLOWUPER_WRITER_RULES = ""; // Phase 2
const TELEGRAM_FOLLOWUPER_CRITIC_RULES = ""; // Phase 2

const TEAMS_PROSPECTOR_WRITER_RULES = ""; // Phase 3
const TEAMS_PROSPECTOR_CRITIC_RULES = ""; // Phase 3
const TEAMS_FOLLOWUPER_WRITER_RULES = ""; // Phase 3
const TEAMS_FOLLOWUPER_CRITIC_RULES = ""; // Phase 3

const SLACK_PROSPECTOR_WRITER_RULES = ""; // Phase 4
const SLACK_PROSPECTOR_CRITIC_RULES = ""; // Phase 4
const SLACK_FOLLOWUPER_WRITER_RULES = ""; // Phase 4
const SLACK_FOLLOWUPER_CRITIC_RULES = ""; // Phase 4

// ─────────────────────────────────────────────────────────────────
// Public API
// ─────────────────────────────────────────────────────────────────

/**
 * Build the writer rule block for the given channel + mode combination.
 * Returns empty string for channel/mode pairs not yet implemented.
 */
export function buildWriterRegisterBlock(
  channel: ChannelCode,
  mode: GenerationMode,
): string {
  if (channel === "whatsapp" && mode === "prospector") return WHATSAPP_PROSPECTOR_WRITER_RULES;
  if (channel === "whatsapp" && mode === "followuper") return WHATSAPP_FOLLOWUPER_WRITER_RULES;
  if (channel === "telegram" && mode === "prospector") return TELEGRAM_PROSPECTOR_WRITER_RULES;
  if (channel === "telegram" && mode === "followuper") return TELEGRAM_FOLLOWUPER_WRITER_RULES;
  if (channel === "teams" && mode === "prospector") return TEAMS_PROSPECTOR_WRITER_RULES;
  if (channel === "teams" && mode === "followuper") return TEAMS_FOLLOWUPER_WRITER_RULES;
  if (channel === "slack" && mode === "prospector") return SLACK_PROSPECTOR_WRITER_RULES;
  if (channel === "slack" && mode === "followuper") return SLACK_FOLLOWUPER_WRITER_RULES;
  return "";
}

/**
 * Build the critic rule block for the given channel + mode combination.
 * Returns empty string for channel/mode pairs not yet implemented.
 */
export function buildCriticRegisterBlock(
  channel: ChannelCode,
  mode: GenerationMode,
): string {
  if (channel === "whatsapp" && mode === "prospector") return WHATSAPP_PROSPECTOR_CRITIC_RULES;
  if (channel === "whatsapp" && mode === "followuper") return WHATSAPP_FOLLOWUPER_CRITIC_RULES;
  if (channel === "telegram" && mode === "prospector") return TELEGRAM_PROSPECTOR_CRITIC_RULES;
  if (channel === "telegram" && mode === "followuper") return TELEGRAM_FOLLOWUPER_CRITIC_RULES;
  if (channel === "teams" && mode === "prospector") return TEAMS_PROSPECTOR_CRITIC_RULES;
  if (channel === "teams" && mode === "followuper") return TEAMS_FOLLOWUPER_CRITIC_RULES;
  if (channel === "slack" && mode === "prospector") return SLACK_PROSPECTOR_CRITIC_RULES;
  if (channel === "slack" && mode === "followuper") return SLACK_FOLLOWUPER_CRITIC_RULES;
  return "";
}
