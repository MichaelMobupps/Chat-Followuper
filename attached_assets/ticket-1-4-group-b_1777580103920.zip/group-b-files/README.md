# Group B — Doctrine engine + chat message generator

## Where each file goes in your Replit repo

The folder structure of this zip mirrors the Replit repo layout. Extract at
the repo root and each file lands in the right place. Or paste them one by
one through the Replit file UI.

```
artifacts/api-server/src/lib/channelRegister.ts             ← NEW
artifacts/api-server/src/services/messageSummarizer.ts      ← NEW
artifacts/api-server/src/services/messagePrompts.ts         ← NEW
artifacts/api-server/src/services/messageGenerator.ts       ← NEW
```

No schema changes. No new dependencies. All four files import only from
modules already in the repo (Group A's anthropic, logger, pricing,
languageNativeness, anthropicRetry, plus the new channelRegister and
messageSummarizer exports).

## What each file does

### `lib/channelRegister.ts` (~340 lines)

Channel-specific writing rules per channel × mode combination. WhatsApp is
fully implemented for both prospector mode (first cold message, 5-7
sentences) and followuper mode (2-3 sentences, requires prior context).
Telegram, Teams, and Slack return empty strings — they're stubs to be
filled in Phases 2/3/4.

Exports:
- `ChannelCode` — type union: `"whatsapp" | "telegram" | "teams" | "slack"`
- `GenerationMode` — type union: `"prospector" | "followuper"`
- `isChannelCode(value)` — type guard
- `buildWriterRegisterBlock(channel, mode)` — rules for the writer prompt
- `buildCriticRegisterBlock(channel, mode)` — rules for the critic prompt

### `services/messageSummarizer.ts` (~270 lines)

Adapted from email Followuper's `emailSummarizer.ts`. Takes a chat thread
or context-notes blob, returns `{ summary, language, cost }`. Uses Haiku
4.5 (cheap). Same meta-language sanitizer as the email tool — strips
`Pitched X, citing Y` style meta-clauses, detects when the LLM echoed the
conversation back as prose, returns clean noun-phrase summaries suitable
for "following up on the ___" references.

Exports:
- `summarizeChatContext(text)` — main entry point
- `summaryLooksMeta(summary)` — runtime self-heal check
- `resanitizeStoredSummary(summary)` — runtime self-heal action
- `SummarizeResult` — interface

### `services/messagePrompts.ts` (~590 lines)

The doctrine. Two distinct prompt sets sharing the same machinery:

- **Prospector mode** — first cold message. Carries the full doctrine
  compressed for chat: prospect-led WHY, specific-number VALIDATION+HOW,
  vertical-native terminology, country-matched references, soft CTA.
  5-7 sentences total.
- **Followuper mode** — every subsequent message. 2-3 sentences. Must
  reference prior thread by specific topic. Every claim must trace to
  prior conversation (no fabrication).

Includes:
- Chat-softer per-language greeting table (~37 languages). Soft default
  for most ("Hi {Name},", "Hola {Name},", "שלום {Name},"). Formal
  preserved for JP/KR/ZH/VI/TH where chat-soft would be culturally wrong.
- Native voice identity block for non-English ("You are a NATIVE SPEAKER...
  You think, reason, and compose in this language natively.").
- Mode-specific critic prompts with different score sets:
  - Prospector: `no_self_referential_why`, `country_matched_references`,
    `vertical_native_terminology`, plus shared scores
  - Followuper: `context_grounding`, `followup_ack`, plus shared scores
- Shared scores both modes use: `no_meta_language`, `language_match`,
  `language_naturalness`, `channel_register_match`, `no_machine_artifacts`,
  `no_meta_commentary`, `no_bracketed_notes`, `tone`, `conciseness`

Exports:
- `MessageContext` — interface
- `ConversationRow` — interface
- `PreviousFollowup` — interface
- `getProspectorSystemPrompt(ctx)`
- `getProspectorUserPrompt(ctx)`
- `getFollowuperSystemPrompt(ctx)`
- `getFollowuperUserPrompt(ctx)`
- `getCriticSystemPrompt(mode, channel)`
- `getCriticUserPrompt(ctx, draft)`
- `getRewriterSystemPrompt(mode, channel)`
- `getRewriterUserPrompt(ctx, draft, critique)`

### `services/messageGenerator.ts` (~840 lines)

The orchestrator. Three-stage pipeline (Sonnet draft → Opus critic →
Sonnet rewrite), self-healing loop max 3 iterations, `bestOverall`
tracking so a regression doesn't lose the good draft.

Sanitizers (5 separate ones, all ported verbatim from Followuper +
Prospector):

1. `humanizeText` — strip em dashes, smart quotes, AI phrases ("delve",
   "leverage", "synergy", "I hope this finds you well", etc.).
2. `applyDeterministicFixes` — snake_case dictionary, `%` symbol enforcement
   across 10+ languages, em dash → comma, en dash → hyphen, bold markdown
   removal, placeholder leak removal (`{event}`, `[volume]`, `NOT AVAILABLE`).
3. `detectMetaCommentary` — catches "this message cannot be salvaged",
   "no patched version should be sent" etc. If detected in rewriter output,
   keeps the prior draft instead of failing.
4. `stripBracketedNotes` — removes "[Verify X before sending]" paragraphs
   that rewriters sometimes leak.
5. `detectMetaLanguage` — catches "citing X", "as urgency", "the ability
   to drive Y" stacked-meta-verb patterns INSIDE the message body.

Mode auto-derivation: `stage === 0` → prospector mode, `stage >= 1` →
followuper mode (override with explicit `mode` option for testing).

**Hard rule:** followuper mode REQUIRES non-empty `conversation`. Throws
`MissingContextError` otherwise. No template fallback. Failure surfaces
to the SDR.

Cost rollup: every LLM call's input/output tokens are tracked, multiplied
by `ANTHROPIC_PRICING` rates from `lib/pricing.ts`, summed across draft +
all critic iterations + all rewrite iterations. Returned as part of
`GeneratedMessage.costEstimate`.

Exports:
- `generateChatMessage(opts)` — main entry point (async)
- `MissingContextError` — class extending Error
- `GeneratedMessage` — interface (subject, message, modelMetadata, costEstimate)
- `GenerateChatMessageOptions` — interface
- `ProspectInput` — interface

## Structural verification

I ran TypeScript syntax check against this code with stubs for the Group A
modules it depends on. Zero errors. The actual workspace typecheck against
your real `lib/` and Group A files should also pass — the imports match
the actual export shapes.

## After pasting all files

Run the agent command provided separately by Claude:

1. Typecheck the workspace
2. Sync to source-code/

If typecheck passes, Group B is done. Group B.5 (the ~180-sub-vertical
taxonomy + 22 firewall maps) follows.

## What's NOT in this group (coming in Group B.5)

- `lib/verticalTaxonomy.ts` — the ~180 sub-vertical enum + display labels
- `lib/verticalFirewall.ts` — the 22 blocked-terms maps
- Wiring of taxonomy + firewall into `messagePrompts.ts` (vertical-specific
  vocabulary blocks injected into the system prompt) and into
  `messageGenerator.ts` (firewall pass before final cleanup)

The current Group B prompts already tell the LLM "use vertical-native
terminology" generically. Group B.5 makes that concrete with explicit
per-sub-vertical vocabulary. Group B is shippable as-is for English-language
testing of basic doctrine; Group B.5 is required for production-grade
vertical-aware messages.
