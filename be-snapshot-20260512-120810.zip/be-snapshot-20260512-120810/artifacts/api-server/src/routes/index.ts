import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import googleAuthRouter from "./google-auth";
import whatsappLinkRouter from "./whatsappLink";
import apolloRouter from "./apollo";
import prospectorRouter from "./prospector";
import prospectsRouter from "./prospects";
import campaignsRouter from "./campaigns";
import generateMessageRouter from "./generateMessage";
import followupsRouter from "./followups";
import sequenceConfigRouter from "./sequenceConfig";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(googleAuthRouter);
router.use(whatsappLinkRouter);
router.use(apolloRouter);
router.use(prospectorRouter);
router.use(prospectsRouter);
router.use(campaignsRouter);
router.use(generateMessageRouter);
router.use(followupsRouter);
router.use(sequenceConfigRouter);

// NOTE: the apollo webhook router is NOT mounted here. It is mounted
// directly in app.ts BEFORE express.json() so that express.raw can
// capture the original request bytes for HMAC verification. Mounting
// it here would put it behind the global JSON parser, which would
// destroy the raw body required for signature verification.

export default router;